/*--------------------------------------------------------------------
 *    The MB-system:  mbr_kemkmall.c  5/25/2018
 *
 *    Copyright (c) 2018-2019 by
 *    David W. Caress (caress@mbari.org)
 *      Monterey Bay Aquarium Research Institute
 *      Moss Landing, CA 95039
 *    and Dale N. Chayes (dale@ldeo.columbia.edu)
 *      Lamont-Doherty Earth Observatory
 *      Palisades, NY 10964
 *
 *    See README file for copying and redistribution conditions.
 *--------------------------------------------------------------------*/
/*
 * mbr_kemkmall.c contains the functions for reading and writing
 * multibeam data in the KEMKMALL format.
 * These functions include:
 *   mbr_alm_kemkmall  - allocate read/write memory
 *   mbr_dem_kemkmall   - deallocate read/write memory
 *   mbr_rt_kemkmall     - read and translate data
 *   mbr_wt_kemkmall     - translate and write data
 *
 * Author:  B. Y. Raanan
 * Date:  May 25, 2018
 *
 */

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "mb_define.h"
#include "mb_format.h"
#include "mb_io.h"
#include "mb_status.h"
#include "mbsys_kmbes.h"

/* turn on debug statements here */
//#define MBR_KEMKMALL_DEBUG 1

int mbr_register_kemkmall(int verbose, void *mbio_ptr, int *error);
int mbr_info_kemkmall(int verbose, int *system, int *beams_bath_max, int *beams_amp_max, int *pixels_ss_max, char *format_name,
           char *system_name, char *format_description, int *numfile, int *filetype, int *variable_beams,
           int *traveltime, int *beam_flagging, int *platform_source, int *nav_source, int *sensordepth_source,
           int *heading_source, int *attitude_source, int *svp_source, double *beamwidth_xtrack,
           double *beamwidth_ltrack, int *error);
int mbr_alm_kemkmall(int verbose, void *mbio_ptr, int *error);
int mbr_dem_kemkmall(int verbose, void *mbio_ptr, int *error);
int mbr_rt_kemkmall(int verbose, void *mbio_ptr, void *store_ptr, int *error);
int mbr_wt_kemkmall(int verbose, void *mbio_ptr, void *store_ptr, int *error);
int mbr_kemkmall_index_data(int verbose, void *mbio_ptr, void *store_ptr, int *error);
int mbr_kemkmall_create_dgm_index_table(int verbose, void *mbio_ptr, void *store_ptr, int *error);    //size_t block_size
int mbr_kemkmall_add_dgm_to_dgm_index_table(int verbose, void *index_table_ptr, void *new_index_ptr, int *error);
int mbr_kemkmall_indextable_compare(const void *a, const void *b);
int mbr_kemkmall_rd_data(int verbose, void *mbio_ptr, void *store_ptr, int *error);
int mbr_kemkmall_wr_data(int verbose, void *mbio_ptr, void *store_ptr, int *error);
int mbr_kemkmall_rd_hdr(int verbose, char *buffer, void *header_ptr, void *emdgm_type_ptr, int *error);
int mbr_kemkmall_rd_spo(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_skm(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_svp(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_svt(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_scl(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_sde(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_shi(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_sha(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_iip(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_iop(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_mrz(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_mwc(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_cpo(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_che(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_xmb(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_xmc(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_xms(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_rd_unknown(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error);
int mbr_kemkmall_wr_header(int verbose, char **bufferptr, void *header_ptr, int *error);
int mbr_kemkmall_wr_spo(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_skm(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_svp(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_svt(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_scl(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_sde(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_shi(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_sha(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_iip(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_iop(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_mrz(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, int imrz, size_t *size, int *error);
int mbr_kemkmall_wr_mwc(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, int imwc, size_t *size, int *error);
int mbr_kemkmall_wr_cpo(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_che(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_xmb(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_xmc(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_xms(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);
int mbr_kemkmall_wr_unknown(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error);

/*--------------------------------------------------------------------*/
int mbr_register_kemkmall(int verbose, void *mbio_ptr, int *error) {
  char *function_name = "mbr_register_kemkmall";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
  }

  /* get mb_io_ptr */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* set format info parameters */
  status = mbr_info_kemkmall(
      verbose, &mb_io_ptr->system, &mb_io_ptr->beams_bath_max, &mb_io_ptr->beams_amp_max, &mb_io_ptr->pixels_ss_max,
      mb_io_ptr->format_name, mb_io_ptr->system_name, mb_io_ptr->format_description, &mb_io_ptr->numfile, &mb_io_ptr->filetype,
      &mb_io_ptr->variable_beams, &mb_io_ptr->traveltime, &mb_io_ptr->beam_flagging, &mb_io_ptr->platform_source,
      &mb_io_ptr->nav_source, &mb_io_ptr->sensordepth_source, &mb_io_ptr->heading_source, &mb_io_ptr->attitude_source,
      &mb_io_ptr->svp_source, &mb_io_ptr->beamwidth_xtrack, &mb_io_ptr->beamwidth_ltrack, error);

  /* set format and system specific function pointers */
  mb_io_ptr->mb_io_format_alloc = &mbr_alm_kemkmall;
  mb_io_ptr->mb_io_format_free = &mbr_dem_kemkmall;
  mb_io_ptr->mb_io_store_alloc = &mbsys_kmbes_alloc;
  mb_io_ptr->mb_io_store_free = &mbsys_kmbes_deall;
  mb_io_ptr->mb_io_read_ping = &mbr_rt_kemkmall;
  mb_io_ptr->mb_io_write_ping = &mbr_wt_kemkmall;
  mb_io_ptr->mb_io_dimensions = &mbsys_kmbes_dimensions;
  mb_io_ptr->mb_io_pingnumber = &mbsys_kmbes_pingnumber;
  mb_io_ptr->mb_io_sonartype = &mbsys_kmbes_sonartype;
  mb_io_ptr->mb_io_sidescantype = NULL;
  mb_io_ptr->mb_io_extract = &mbsys_kmbes_extract;
  mb_io_ptr->mb_io_insert = &mbsys_kmbes_insert;
  mb_io_ptr->mb_io_extract_nav = &mbsys_kmbes_extract_nav;
//  mb_io_ptr->mb_io_extract_nnav = &mbsys_kmbes_extract_nnav;
  mb_io_ptr->mb_io_insert_nav = &mbsys_kmbes_insert_nav;
  mb_io_ptr->mb_io_extract_altitude = &mbsys_kmbes_extract_altitude;
  mb_io_ptr->mb_io_insert_altitude = NULL;
  mb_io_ptr->mb_io_extract_svp = &mbsys_kmbes_extract_svp;
  mb_io_ptr->mb_io_insert_svp = &mbsys_kmbes_insert_svp;
  mb_io_ptr->mb_io_ttimes = &mbsys_kmbes_ttimes;
  mb_io_ptr->mb_io_detects = &mbsys_kmbes_detects;
  mb_io_ptr->mb_io_pulses = &mbsys_kmbes_pulses;
  mb_io_ptr->mb_io_gains = &mbsys_kmbes_gains;
  mb_io_ptr->mb_io_copyrecord = &mbsys_kmbes_copy;
  mb_io_ptr->mb_io_extract_rawss = NULL;
  mb_io_ptr->mb_io_insert_rawss = NULL;
  mb_io_ptr->mb_io_extract_segytraceheader = NULL;
  mb_io_ptr->mb_io_extract_segy = NULL;
  mb_io_ptr->mb_io_insert_segy = NULL;
  mb_io_ptr->mb_io_ctd = NULL;
  mb_io_ptr->mb_io_ancilliarysensor = NULL;

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       system:             %d\n", mb_io_ptr->system);
    fprintf(stderr, "dbg2       beams_bath_max:     %d\n", mb_io_ptr->beams_bath_max);
    fprintf(stderr, "dbg2       beams_amp_max:      %d\n", mb_io_ptr->beams_amp_max);
    fprintf(stderr, "dbg2       pixels_ss_max:      %d\n", mb_io_ptr->pixels_ss_max);
    fprintf(stderr, "dbg2       format_name:        %s\n", mb_io_ptr->format_name);
    fprintf(stderr, "dbg2       system_name:        %s\n", mb_io_ptr->system_name);
    fprintf(stderr, "dbg2       format_description: %s\n", mb_io_ptr->format_description);
    fprintf(stderr, "dbg2       numfile:            %d\n", mb_io_ptr->numfile);
    fprintf(stderr, "dbg2       filetype:           %d\n", mb_io_ptr->filetype);
    fprintf(stderr, "dbg2       variable_beams:     %d\n", mb_io_ptr->variable_beams);
    fprintf(stderr, "dbg2       traveltime:         %d\n", mb_io_ptr->traveltime);
    fprintf(stderr, "dbg2       beam_flagging:      %d\n", mb_io_ptr->beam_flagging);
    fprintf(stderr, "dbg2       platform_source:    %d\n", mb_io_ptr->platform_source);
    fprintf(stderr, "dbg2       nav_source:         %d\n", mb_io_ptr->nav_source);
    fprintf(stderr, "dbg2       sensordepth_source: %d\n", mb_io_ptr->nav_source);
    fprintf(stderr, "dbg2       heading_source:     %d\n", mb_io_ptr->heading_source);
    fprintf(stderr, "dbg2       attitude_source:    %d\n", mb_io_ptr->attitude_source);
    fprintf(stderr, "dbg2       svp_source:         %d\n", mb_io_ptr->svp_source);
    fprintf(stderr, "dbg2       beamwidth_xtrack:   %f\n", mb_io_ptr->beamwidth_xtrack);
    fprintf(stderr, "dbg2       beamwidth_ltrack:   %f\n", mb_io_ptr->beamwidth_ltrack);
    fprintf(stderr, "dbg2       format_alloc:       %p\n", (void *)mb_io_ptr->mb_io_format_alloc);
    fprintf(stderr, "dbg2       format_free:        %p\n", (void *)mb_io_ptr->mb_io_format_free);
    fprintf(stderr, "dbg2       store_alloc:        %p\n", (void *)mb_io_ptr->mb_io_store_alloc);
    fprintf(stderr, "dbg2       store_free:         %p\n", (void *)mb_io_ptr->mb_io_store_free);
    fprintf(stderr, "dbg2       read_ping:          %p\n", (void *)mb_io_ptr->mb_io_read_ping);
    fprintf(stderr, "dbg2       write_ping:         %p\n", (void *)mb_io_ptr->mb_io_write_ping);
    fprintf(stderr, "dbg2       extract:            %p\n", (void *)mb_io_ptr->mb_io_extract);
    fprintf(stderr, "dbg2       insert:             %p\n", (void *)mb_io_ptr->mb_io_insert);
    fprintf(stderr, "dbg2       extract_nav:        %p\n", (void *)mb_io_ptr->mb_io_extract_nav);
    fprintf(stderr, "dbg2       insert_nav:         %p\n", (void *)mb_io_ptr->mb_io_insert_nav);
    fprintf(stderr, "dbg2       extract_altitude:   %p\n", (void *)mb_io_ptr->mb_io_extract_altitude);
    fprintf(stderr, "dbg2       insert_altitude:    %p\n", (void *)mb_io_ptr->mb_io_insert_altitude);
    fprintf(stderr, "dbg2       extract_svp:        %p\n", (void *)mb_io_ptr->mb_io_extract_svp);
    fprintf(stderr, "dbg2       insert_svp:         %p\n", (void *)mb_io_ptr->mb_io_insert_svp);
    fprintf(stderr, "dbg2       ttimes:             %p\n", (void *)mb_io_ptr->mb_io_ttimes);
    fprintf(stderr, "dbg2       detects:            %p\n", (void *)mb_io_ptr->mb_io_detects);
    fprintf(stderr, "dbg2       extract_rawss:      %p\n", (void *)mb_io_ptr->mb_io_extract_rawss);
    fprintf(stderr, "dbg2       insert_rawss:       %p\n", (void *)mb_io_ptr->mb_io_insert_rawss);
    fprintf(stderr, "dbg2       extract_segytraceheader: %p\n", (void *)mb_io_ptr->mb_io_extract_segytraceheader);
    fprintf(stderr, "dbg2       extract_segy:       %p\n", (void *)mb_io_ptr->mb_io_extract_segy);
    fprintf(stderr, "dbg2       insert_segy:        %p\n", (void *)mb_io_ptr->mb_io_insert_segy);
    fprintf(stderr, "dbg2       copyrecord:         %p\n", (void *)mb_io_ptr->mb_io_copyrecord);
    fprintf(stderr, "dbg2       error:              %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:         %d\n", status);
  }

  /* return status */
  return (status);
}

/*--------------------------------------------------------------------*/
int mbr_info_kemkmall(int verbose, int *system, int *beams_bath_max, int *beams_amp_max, int *pixels_ss_max, char *format_name,
           char *system_name, char *format_description, int *numfile, int *filetype, int *variable_beams,
           int *traveltime, int *beam_flagging, int *platform_source, int *nav_source, int *sensordepth_source,
           int *heading_source, int *attitude_source, int *svp_source, double *beamwidth_xtrack,
           double *beamwidth_ltrack, int *error) {
  char *function_name = "mbr_info_kemkmall";
  int status = MB_SUCCESS;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
  }

  /* set format info parameters */
  status = MB_SUCCESS;
  *error = MB_ERROR_NO_ERROR;
  *system = MB_SYS_KMBES;
  *beams_bath_max = MBSYS_KMBES_MAX_NUM_BEAMS;
  *beams_amp_max = MBSYS_KMBES_MAX_NUM_BEAMS;
  *pixels_ss_max = MBSYS_KMBES_MAX_PIXELS;
  strncpy(format_name, "KEMKMALL", MB_NAME_LENGTH);
  strncpy(system_name, "KMBES", MB_NAME_LENGTH);
  strncpy(format_description, "Format name:          MBF_KEMKMALL\n"
          "Informal Description: Kongsberg multibeam echosounder system kmall datagram format\n"
          "Attributes:           Kongsberg fourth generation multibeam sonars (EM2040, EM712, \n"
          "                      EM304, EM124), bathymetry, amplitude, backscatter, variable beams, \n"
          "                      binary datagrams, Kongsberg.\n", MB_DESCRIPTION_LENGTH);
  *numfile = 1;
  *filetype = MB_FILETYPE_SINGLE;
  *variable_beams = MB_YES;
  *traveltime = MB_YES;
  *beam_flagging = MB_YES;
  *platform_source = MB_DATA_NONE;
  *nav_source = MB_DATA_DATA;
  *sensordepth_source = MB_DATA_DATA;
  *heading_source = MB_DATA_DATA;
  *attitude_source = MB_DATA_DATA;
  *svp_source = MB_DATA_VELOCITY_PROFILE;
  *beamwidth_xtrack = 1.0;
  *beamwidth_ltrack = 1.0;

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       system:             %d\n", *system);
    fprintf(stderr, "dbg2       beams_bath_max:     %d\n", *beams_bath_max);
    fprintf(stderr, "dbg2       beams_amp_max:      %d\n", *beams_amp_max);
    fprintf(stderr, "dbg2       pixels_ss_max:      %d\n", *pixels_ss_max);
    fprintf(stderr, "dbg2       format_name:        %s\n", format_name);
    fprintf(stderr, "dbg2       system_name:        %s\n", system_name);
    fprintf(stderr, "dbg2       format_description: %s\n", format_description);
    fprintf(stderr, "dbg2       numfile:            %d\n", *numfile);
    fprintf(stderr, "dbg2       filetype:           %d\n", *filetype);
    fprintf(stderr, "dbg2       variable_beams:     %d\n", *variable_beams);
    fprintf(stderr, "dbg2       traveltime:         %d\n", *traveltime);
    fprintf(stderr, "dbg2       beam_flagging:      %d\n", *beam_flagging);
    fprintf(stderr, "dbg2       platform_source:    %d\n", *platform_source);
    fprintf(stderr, "dbg2       nav_source:         %d\n", *nav_source);
    fprintf(stderr, "dbg2       sensordepth_source: %d\n", *sensordepth_source);
    fprintf(stderr, "dbg2       heading_source:     %d\n", *heading_source);
    fprintf(stderr, "dbg2       attitude_source:      %d\n", *attitude_source);
    fprintf(stderr, "dbg2       svp_source:         %d\n", *svp_source);
    fprintf(stderr, "dbg2       beamwidth_xtrack:   %f\n", *beamwidth_xtrack);
    fprintf(stderr, "dbg2       beamwidth_ltrack:   %f\n", *beamwidth_ltrack);
    fprintf(stderr, "dbg2       error:              %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:         %d\n", status);
  }

  /* return status */
  return (status);
}
/*--------------------------------------------------------------------*/
int mbr_alm_kemkmall(int verbose, void *mbio_ptr, int *error) {
  char *function_name = "mbr_alm_kemkmall";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;
    char **bufferptr = NULL;
    int *bufferalloc = NULL;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
  }

    /* check for non-null pointers */
    assert(mbio_ptr != NULL);

  /* get pointer to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* set initial status */
  status = MB_SUCCESS;

  /* allocate memory for data structure */
  mb_io_ptr->structure_size = 0;
  mb_io_ptr->data_structure_size = 0;
  status = mbsys_kmbes_alloc(verbose, mbio_ptr, &mb_io_ptr->store_data, error);

    /* allocate starting memory for data record buffer */
    bufferptr = (char **)&mb_io_ptr->raw_data;
    bufferalloc = (int *)&mb_io_ptr->structure_size;

  *bufferptr = NULL;
  *bufferalloc = 0;
    if (status == MB_SUCCESS) {
        status = mb_reallocd(verbose, __FILE__, __LINE__, MBSYS_KMBES_START_BUFFER_SIZE, (void **)bufferptr, error);
        if (status == MB_SUCCESS)
            *bufferalloc = MBSYS_KMBES_START_BUFFER_SIZE;
    }

  /* prep memory for data datagram index table */
  mb_io_ptr->saveptr1 = NULL;
  mb_io_ptr->save1 = 0;

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
}
/*--------------------------------------------------------------------*/
int mbr_dem_kemkmall(int verbose, void *mbio_ptr, int *error) {
  char *function_name = "mbr_dem_kemkmall";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;
  struct mbsys_kmbes_index_table *dgm_index_table = NULL;
  int *dgm_count = NULL;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
  }

  /* get pointers to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* deallocate reading/writing buffer */
  if (mb_io_ptr->raw_data != NULL && mb_io_ptr->structure_size > 0) {
    status = mb_freed(verbose, __FILE__, __LINE__, (void **)(&mb_io_ptr->raw_data), error);
    mb_io_ptr->raw_data = NULL;
    mb_io_ptr->data_structure_size = 0;
  }

  /* deallocate file indexing array */
  if (mb_io_ptr->saveptr1 != NULL) {

    /* get pointers to datagram index table */
    dgm_index_table = (struct mbsys_kmbes_index_table *)mb_io_ptr->saveptr1;
    dgm_count = (int *)&mb_io_ptr->save1;

    if (dgm_index_table->num_alloc > 0) {
      status = mb_freed(verbose, __FILE__, __LINE__, (void **)(&dgm_index_table->indextable), error);
    }
    status = mb_freed(verbose, __FILE__, __LINE__, (void **)(&dgm_index_table), error);
    dgm_index_table = NULL;
    *dgm_count = 0;
  }

  /* deallocate memory for data descriptor */
  status = mbsys_kmbes_deall(verbose, mbio_ptr, &mb_io_ptr->store_data, error);

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
}
/*--------------------------------------------------------------------*/
int mbr_rt_kemkmall(int verbose, void *mbio_ptr, void *store_ptr, int *error) {
  char *function_name = "mbr_rt_kemkmall";
  int status = MB_SUCCESS;
  int interp_error = MB_ERROR_NO_ERROR;
  struct mb_io_struct *mb_io_ptr = NULL;
  struct mbsys_kmbes_struct *store = NULL;
  int *file_indexed = NULL;
  double *pixel_size, *swath_width;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointers to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* get saved values */
  file_indexed = (int *)&mb_io_ptr->save2;
	pixel_size = (double *)&mb_io_ptr->saved1;
	swath_width = (double *)&mb_io_ptr->saved2;

  /* if needed index the file */
  if (*file_indexed == MB_NO) {
#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "About to call mbr_kemkmall_index_data...\n");
#endif
    status = mbr_kemkmall_index_data(verbose, mbio_ptr, store_ptr, error);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "\nAbout to call mbr_kemkmall_rd_data...\n");
#endif

  /* read next data from file */
  status = mbr_kemkmall_rd_data(verbose, mbio_ptr, store_ptr, error);

  /* get pointers to data structures */
  store = (struct mbsys_kmbes_struct *)store_ptr;

  /* if this is a ping and the first time read by MB-System generate pseudosidescan */
  if (status == MB_SUCCESS && store->kind == MB_DATA_DATA
    && store->xmb.pseudosidescan_enabled == MB_NO) {
		status = mbsys_kmbes_makess(verbose, mbio_ptr, store_ptr, MB_NO, pixel_size, MB_NO, swath_width, 0, error);
  }

  /* set error and kind in mb_io_ptr */
  mb_io_ptr->new_error = *error;
  mb_io_ptr->new_kind = store->kind;

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "Done with mbr_kemkmall_rd_data: status:%d error:%d kind:%d\n", status, *error, store->kind);
#endif

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
}
/*--------------------------------------------------------------------*/
int mbr_wt_kemkmall(int verbose, void *mbio_ptr, void *store_ptr, int *error) {
  char *function_name = "mbr_wt_kemkmall";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;
  struct mbsys_kmbes_struct *store = NULL;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

    /* check for non-null pointers */
    assert(mbio_ptr != NULL);
    assert(store_ptr != NULL);

  /* get pointer to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "\nAbout to call mbr_kemkmall_wr_data record kind:%d\n", store->kind);
#endif

  /* write next data to file */
  status = mbr_kemkmall_wr_data(verbose, mbio_ptr, store_ptr, error);

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "Done with mbr_kemkmall_wr_data: status:%d error:%d\n", status, *error);
#endif

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
}

/*--------------------------------------------------------------------*/

int mbr_kemkmall_index_data(int verbose, void *mbio_ptr, void *store_ptr, int *error) {
  char *function_name = "mbr_kemkmall_index_data";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_index_table *dgm_index_table = NULL;
  struct mbsys_kmbes_index dgm_index;
  struct mbsys_kmbes_header header;
  struct mbsys_kmbes_m_body cmnPart;
  mbsys_kmbes_emdgm_type emdgm_type;
  int *file_indexed = NULL;
  int *dgm_id = NULL;
  char buffer[256];
  size_t read_len, offset;
  int index, skip, valid_id, num_bytes_dgm_end;
  int iip_location = -1;
  const int HEADER_SKIP = 8;
  unsigned short pingCnt;
  int time_i[7];
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* check for non-null pointers */
  assert(mbio_ptr != NULL);
  assert(store_ptr != NULL);

  /* create a datagram index table in mbio descriptor */
  mbr_kemkmall_create_dgm_index_table(verbose, mbio_ptr, store_ptr, error);

  /* get pointer to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;

  /* now get the index table from the mbio descriptor field saveptr1 */
  dgm_index_table = (struct mbsys_kmbes_index_table *)mb_io_ptr->saveptr1;
  dgm_index_table->dgm_count = 0;
  dgm_id = (int *)&mb_io_ptr->save1;
  *dgm_id = 0;
  file_indexed = (int *)&mb_io_ptr->save2;
  *file_indexed = MB_NO;

  /* set file position to the start */
  fseek(mb_io_ptr->mbfp, 0, SEEK_SET);
  mb_io_ptr->file_pos = ftell(mb_io_ptr->mbfp);

  /* set status */
  status = MB_SUCCESS;
  *error = MB_ERROR_NO_ERROR;
  valid_id = MB_YES;

  while (*error <= MB_ERROR_NO_ERROR) {

    /* find the next valid datagram header */
    memset(&buffer, 0, sizeof(buffer));
    read_len = (size_t)MBSYS_KMBES_HEADER_SIZE;
    skip = 0;
    status = mb_fileio_get(verbose, mbio_ptr, (void *)&buffer[0], &read_len, error);
    status = mbr_kemkmall_rd_hdr(verbose, buffer, (void *)&header, (void *)&emdgm_type, error);
    while (status == MB_SUCCESS && emdgm_type == UNKNOWN) {
      for (i=0;i<MBSYS_KMBES_HEADER_SIZE-1;i++) {
        buffer[i] = buffer[i+1];
      }
      read_len = 1;
      status = mb_fileio_get(verbose, mbio_ptr, (void *)&buffer[MBSYS_KMBES_HEADER_SIZE-1], &read_len, error);
      skip++;
      if (status == MB_SUCCESS) {
        status = mbr_kemkmall_rd_hdr(verbose, buffer, (void *)&header, (void *)&emdgm_type, error);
      }
    }

    /* report problem */
    if (status == MB_SUCCESS && skip > 0 && verbose >= 0) {
      fprintf(stderr, "\nThe MBF_KEMKMALL module skipped data between identified\n"
              "data records. Something is broken, most likely the data...\n"
              "However, the data may include a data record type that we\n"
              "haven't seen yet, or there could be an error in the code.\n"
              "If skipped data are reported multiple times, we recommend \n"
              "you post a problem description through the discussion list \n"
              "available at https://listserver.mbari.org/sympa/arc/mbsystem \n"
              "and make a data sample available. \n"
              "Have a nice day...\n");
      fprintf(stderr, "MBF_KEMKMALL skipped %d bytes before record %.4s at file pos %ld\n",
                      skip, header.dgmType, ftell(mb_io_ptr->mbfp));
    }

    /* now parse the header and index the datagram */
    if (status == MB_SUCCESS && emdgm_type != UNKNOWN) {

      /* verify datagram is intact - seek to end of the datagram and read last int
         - make survey mb_io_ptr->file_pos records the position of the start of the datagram */
      mb_io_ptr->file_pos = ftell(mb_io_ptr->mbfp) - MBSYS_KMBES_HEADER_SIZE;
      offset = (header.numBytesDgm - MBSYS_KMBES_HEADER_SIZE - sizeof(int));
      fseek(mb_io_ptr->mbfp, offset, SEEK_CUR);

      read_len = sizeof(int);
      status = mb_fileio_get(verbose, mbio_ptr, (void *)&buffer[0], &read_len, error);

      if (status == MB_SUCCESS) {
        /* Confirm that that byte count in the last int matches start int */
        mb_get_binary_int(MB_YES, &buffer[0], &num_bytes_dgm_end);

        if (header.numBytesDgm != num_bytes_dgm_end) {
          /* No match. Assume packet header was really corrupt, so reset
            file pointer past corrupted packet header and set datagram type to unknown. */
#ifdef MBR_KEMKMALL_DEBUG
          fprintf(stderr, "\nError in record %.4s at file pointer position %ld.\n"
                "Expected a dgm with %u bytes, but dgm closing byte indicated %u.\n"
                "Skipping past the corrupted packet header and setting datagram type to unknown.\n",
                header.dgmType, mb_io_ptr->file_pos, header.numBytesDgm, num_bytes_dgm_end);
#endif
          mb_io_ptr->file_pos += HEADER_SKIP;
          fseek(mb_io_ptr->mbfp, mb_io_ptr->file_pos, SEEK_SET);
          emdgm_type = UNKNOWN;
          valid_id = MB_NO;
        }
      }

      /* handle a valid datagram */
      if (status == MB_SUCCESS && emdgm_type != UNKNOWN) {

        /* populate the index entry structure. */
        memset(&dgm_index, 0, sizeof(struct mbsys_kmbes_index));
        switch (emdgm_type) {

          case MWC:
          case MRZ:
            /* Valid multibeam datagram: */
            /* parse the dgm to get additional info about ping. */
            /* this is necessary to insure multi-TX/RX and dual-swath modes are handled correctly. */

            /* get ping info */
            /* skip past the header and the 2 shorts that make up the dgm partition part */
            offset = (mb_io_ptr->file_pos + MBSYS_KMBES_HEADER_SIZE + sizeof(int));
            fseek(mb_io_ptr->mbfp, offset, SEEK_SET);

            read_len = 12;
            status = mb_fileio_get(verbose, mbio_ptr, (void *)&buffer[0], &read_len, error);

            if (status == MB_SUCCESS) {

              /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
              index = 0;
              mb_get_binary_short(MB_YES, &buffer[index], &(cmnPart.numBytesCmnPart));
              index += 2;
              mb_get_binary_short(MB_YES, &buffer[index], &(cmnPart.pingCnt));
              index += 2;
              cmnPart.rxFansPerPing = buffer[index];
              index++;
              cmnPart.rxFanIndex = buffer[index];
              index++;
              cmnPart.swathsPerPing = buffer[index];
              index++;
              cmnPart.swathAlongPosition = buffer[index];
              index++;
              cmnPart.txTransducerInd = buffer[index];
              index++;
              cmnPart.rxTransducerInd = buffer[index];
              index++;
              cmnPart.numRxTransducers = buffer[index];
              index++;
              cmnPart.algorithmType = buffer[index];
              index++;

              /* populate the datagram index entry */
              dgm_index.time_d = ((double)header.time_sec) + MBSYS_KMBES_NANO * header.time_nanosec;
              dgm_index.emdgm_type = emdgm_type;
              memcpy(&dgm_index.header, &header, sizeof(struct mbsys_kmbes_header));
              dgm_index.file_pos = mb_io_ptr->file_pos;
              dgm_index.ping_num = cmnPart.pingCnt;
              dgm_index.rx_per_ping = cmnPart.rxFansPerPing;
              dgm_index.rx_index = cmnPart.rxFanIndex;
              dgm_index.swaths_per_ping = cmnPart.swathsPerPing;
#ifdef MBR_KEMKMALL_DEBUG
              mb_get_date(verbose, dgm_index.time_d, time_i);
              fprintf(stderr,"%.4s:%d pos:%ld nbytes:%u Cnt:%d rxFans:%d:%d swaths:%d along:%d tx:%d rx:%d numrx:%d alg:%d  %4.4d/%2.2d/%2.2d %2.2d:%2.2d:%2.2d.%6.6d\n",
                      header.dgmType,emdgm_type,dgm_index.file_pos,header.numBytesDgm,cmnPart.pingCnt, cmnPart.rxFansPerPing, cmnPart.rxFanIndex,
                      cmnPart.swathsPerPing, cmnPart.swathAlongPosition, cmnPart.txTransducerInd,
                      cmnPart.rxTransducerInd, cmnPart.numRxTransducers, cmnPart.algorithmType,
                      time_i[0],time_i[1],time_i[2],time_i[3],time_i[4],time_i[5],time_i[6]);
#endif

              status = mbr_kemkmall_add_dgm_to_dgm_index_table(verbose, dgm_index_table, &dgm_index, error);
            }

            if (status == MB_SUCCESS) {
              offset = (size_t) (mb_io_ptr->file_pos + header.numBytesDgm);
              fseek(mb_io_ptr->mbfp, offset, SEEK_SET);
            }
            // TODO: what happens if alloc fails - while condition?
            break;

          case XMS:
            /* Valid multibeam pseudosidescan datagram: */
            /* parse the dgm to get additional info about ping. */
            /* this is necessary to insure multi-TX/RX and dual-swath modes are handled correctly. */

            /* get ping info */
            /* skip past the header and the 2 shorts that make up the dgm partition part */
            offset = (mb_io_ptr->file_pos + MBSYS_KMBES_HEADER_SIZE + sizeof(int));
            fseek(mb_io_ptr->mbfp, offset, SEEK_SET);

            read_len = 12;
            status = mb_fileio_get(verbose, mbio_ptr, (void *)&buffer[0], &read_len, error);

            if (status == MB_SUCCESS) {

              /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
              index = 0;
              mb_get_binary_short(MB_YES, &buffer[index], &(pingCnt));

              /* populate the datagram index entry */
              dgm_index.time_d = ((double)header.time_sec) + MBSYS_KMBES_NANO * header.time_nanosec;
              dgm_index.emdgm_type = emdgm_type;
              memcpy(&dgm_index.header, &header, sizeof(struct mbsys_kmbes_header));
              dgm_index.file_pos = mb_io_ptr->file_pos;
              dgm_index.ping_num = cmnPart.pingCnt;
              dgm_index.rx_per_ping = 0;
              dgm_index.rx_index = 0;
              dgm_index.swaths_per_ping = 0;
#ifdef MBR_KEMKMALL_DEBUG
              mb_get_date(verbose, dgm_index.time_d, time_i);
              fprintf(stderr,"%.4s:%d pos:%ld nbytes:%u Cnt:%d rxFans:%d:%d swaths:%d along:%d tx:%d rx:%d numrx:%d alg:%d  %4.4d/%2.2d/%2.2d %2.2d:%2.2d:%2.2d.%6.6d\n",
                      header.dgmType,emdgm_type,dgm_index.file_pos,header.numBytesDgm,cmnPart.pingCnt, cmnPart.rxFansPerPing, cmnPart.rxFanIndex,
                      cmnPart.swathsPerPing, cmnPart.swathAlongPosition, cmnPart.txTransducerInd,
                      cmnPart.rxTransducerInd, cmnPart.numRxTransducers, cmnPart.algorithmType,
                      time_i[0],time_i[1],time_i[2],time_i[3],time_i[4],time_i[5],time_i[6]);
#endif

              status = mbr_kemkmall_add_dgm_to_dgm_index_table(verbose, dgm_index_table, &dgm_index, error);
            }

            if (status == MB_SUCCESS) {
              offset = (size_t) (mb_io_ptr->file_pos + header.numBytesDgm);
              fseek(mb_io_ptr->mbfp, offset, SEEK_SET);
            }
            // TODO: what happens if alloc fails - while condition?
            break;

          default:
            /* Other valid datagram: */

            /* save index of first #IIP datagram */
            if (iip_location < 0 && emdgm_type == IIP) {
              iip_location = dgm_index_table->dgm_count;
            }

            /* populate the datagram index entry */
            dgm_index.time_d = ((double)header.time_sec) + MBSYS_KMBES_NANO * header.time_nanosec;
            dgm_index.emdgm_type = emdgm_type;
            memcpy(&dgm_index.header, &header, sizeof(struct mbsys_kmbes_header));
            dgm_index.file_pos = mb_io_ptr->file_pos;
            dgm_index.ping_num = 0;
            dgm_index.rx_per_ping = 0;
            dgm_index.rx_index = 0;
            dgm_index.swaths_per_ping = 0;
#ifdef MBR_KEMKMALL_DEBUG
            mb_get_date(verbose, dgm_index.time_d, time_i);
            fprintf(stderr,"%.4s:%d pos:%ld nbytes:%u %4.4d/%2.2d/%2.2d %2.2d:%2.2d:%2.2d.%6.6d\n",
                    header.dgmType,emdgm_type,dgm_index.file_pos,header.numBytesDgm,time_i[0],time_i[1],time_i[2],time_i[3],time_i[4],time_i[5],time_i[6]);
#endif

            status = mbr_kemkmall_add_dgm_to_dgm_index_table(verbose, dgm_index_table, &dgm_index, error);

            if (status == MB_SUCCESS) {
              offset = (size_t) (mb_io_ptr->file_pos + header.numBytesDgm);
              fseek(mb_io_ptr->mbfp, offset, SEEK_SET);
            }
            break;
        }

        /* update file position */
        mb_io_ptr->file_pos = ftell(mb_io_ptr->mbfp);
      }
    }
  }

  /* set indexed flag */
  *file_indexed = MB_YES;
  *dgm_id = 0;
  if ((dgm_index_table->dgm_count > 0) && (*error = MB_ERROR_EOF)) {
    status = MB_SUCCESS;
    *error = MB_ERROR_NO_ERROR;
  }

  /* sort the index table into the order to be read */
  if (status == MB_SUCCESS && dgm_index_table->dgm_count > 0) {

    /* each ping can have multiple MRZ and MWC datagrams - the ping timestamp is
        the timestamp of the first MRZ datagram - add ping timestamp to index entries
        for all MRZ and MWC datagrams */
    /* start by sorting the index table on ping number alone, and then looping
          over all datagrams in ping order setting the ping timestamp */
    //qsort((void *)dgm_index_table->indextable, dgm_index_table->dgm_count,
    //    sizeof(struct mbsys_kmbes_index), (void *)mbr_kemkmall_indextable_compare_pings);


    /* sort the datagram index table, leaving the datagrams up through the
       #IIP datagram in place at the start of the file - in practice this means
       any comment datagrams stay at the start of the file */

    qsort((void *)dgm_index_table->indextable, dgm_index_table->dgm_count,
        sizeof(struct mbsys_kmbes_index), (void *)mbr_kemkmall_indextable_compare);
//    qsort((void *)&(dgm_index_table->indextable[iip_location+2]), dgm_index_table->dgm_count-iip_location-2,
//        sizeof(struct mbsys_kmbes_index), (void *)mbr_kemkmall_indextable_compare);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "\n\nIndexed %ld valid EM datagrams:\n", dgm_index_table->dgm_count);
  for (i=0; i<dgm_index_table->dgm_count; i++)
  {
    fprintf(stderr, "ID: %4d, ", i);
    fprintf(stderr, "file_pos: %8.zu, ", dgm_index_table->indextable[i].file_pos);
    fprintf(stderr, "dgm: %.4s, ", dgm_index_table->indextable[i].header.dgmType);
    fprintf(stderr, "type: %2d, ", dgm_index_table->indextable[i].emdgm_type);
    fprintf(stderr, "size: %6u, ", dgm_index_table->indextable[i].header.numBytesDgm);
    fprintf(stderr, "time: %9.3f, ", dgm_index_table->indextable[i].time_d);
    fprintf(stderr, "ping: %5d, ", dgm_index_table->indextable[i].ping_num);
    fprintf(stderr, "rxIndex: %u/%u.\n", dgm_index_table->indextable[i].rx_index,
                                dgm_index_table->indextable[i].rx_per_ping);
  }
  fprintf(stderr, "\n");
#endif

  /* set file position back to the start */
  fseek(mb_io_ptr->mbfp, 0, SEEK_SET);

    /* print output debug statements */
    if (verbose >= 2) {
        fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
        fprintf(stderr, "dbg2  Return values:\n");
        fprintf(stderr, "dbg2       error:      %d\n", *error);
        fprintf(stderr, "dbg2  Return status:\n");
        fprintf(stderr, "dbg2       status:  %d\n", status);
    }

  /* return status */
  return (status);

};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_create_dgm_index_table(int verbose, void *mbio_ptr, void *store_ptr, int *error) {
  char *function_name = "mbr_kemkmall_create_dgm_index_table";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_index_table *dgm_index_table = NULL;
  size_t size_bytes = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* we will store the datagram index table in mbio descriptor field saveptr1 */
  dgm_index_table = (struct mbsys_kmbes_index_table *)mb_io_ptr->saveptr1;

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;

  /* allocate the datagram index table struct (vector struct) */
  status = mb_mallocd(verbose, __FILE__, __LINE__,
             sizeof(struct mbsys_kmbes_index_table), (void **)(&dgm_index_table), error);

  if (status == MB_SUCCESS) {
    dgm_index_table->dgm_count = 0;

    /* allocate the datagram index table array */
    size_bytes = MBSYS_KMBES_INDEX_TABLE_BLOCK_SIZE * sizeof(struct mbsys_kmbes_index);
    status = mb_mallocd(verbose, __FILE__, __LINE__, size_bytes,
               (void **)(&dgm_index_table->indextable), error);
    if (status == MB_SUCCESS) {
      dgm_index_table->num_alloc = MBSYS_KMBES_INDEX_TABLE_BLOCK_SIZE;
    } else {
      dgm_index_table->num_alloc = 0;

    }
  }

  /* init internal data structure variables */
  mb_io_ptr->saveptr1 = (void *)dgm_index_table;
  mb_io_ptr->save1 = 0;     // most recently read entry in index table, after indexing
  mb_io_ptr->save2 = MB_NO; // file has been indexed

    /* print output debug statements */
    if (verbose >= 2) {
        fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
        fprintf(stderr, "dbg2  Return values:\n");
        fprintf(stderr, "dbg2       error:      %d\n", *error);
        fprintf(stderr, "dbg2  Return status:\n");
        fprintf(stderr, "dbg2       status:  %d\n", status);
    }

  /* return status */
  return(status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_add_dgm_to_dgm_index_table(int verbose, void *index_table_ptr, void *new_index_ptr, int *error) {
  char *function_name = "mbr_kemkmall_add_dgm_to_dgm_index_table";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_index_table *dgm_index_table = NULL;
  struct mbsys_kmbes_index *new_dgm_index = NULL;
  size_t dgm_count = 0;
  size_t new_num_alloc = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:         %d\n", verbose);
    fprintf(stderr, "dbg2       index_table_ptr: %p\n", (void *)index_table_ptr);
    fprintf(stderr, "dbg2       new_index_ptr:   %p\n", (void *)new_index_ptr);
  }

  /* get pointer to datagram index table */
  dgm_index_table = (struct mbsys_kmbes_index_table *)index_table_ptr;

  /* get pointer to the new datagram index structure */
  new_dgm_index = (struct mbsys_kmbes_index *)new_index_ptr;

  /* reallocate the datagram index table array if needed */
  dgm_count = dgm_index_table->dgm_count;
  if (dgm_count >= (dgm_index_table->num_alloc-1)) {
    new_num_alloc = dgm_index_table->num_alloc + MBSYS_KMBES_INDEX_TABLE_BLOCK_SIZE;

    /* reallocate the datagram index table array */
    status = mb_reallocd(verbose, __FILE__, __LINE__,
               sizeof(struct mbsys_kmbes_index) * new_num_alloc,
               (void **)(&dgm_index_table->indextable), error);

    if (status == MB_SUCCESS) {
      dgm_index_table->num_alloc = new_num_alloc;
    } else {
      dgm_index_table->num_alloc = 0;
      dgm_index_table->dgm_count = 0;
    }
  }

  if (status == MB_SUCCESS) {
    dgm_index_table->indextable[dgm_count] = *new_dgm_index;
    dgm_index_table->dgm_count++;
  }

    /* print output debug statements */
    if (verbose >= 2) {
        fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
        fprintf(stderr, "dbg2  Return values:\n");
        fprintf(stderr, "dbg2       error:      %d\n", *error);
        fprintf(stderr, "dbg2  Return status:\n");
        fprintf(stderr, "dbg2       status:  %d\n", status);
    }

  /* return status */
  return(status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_indextable_compare(const void *a, const void *b) {
  struct mbsys_kmbes_index *aa = NULL;
  struct mbsys_kmbes_index *bb = NULL;
  int result = 0;

  aa = (struct mbsys_kmbes_index*) a;
  bb = (struct mbsys_kmbes_index*) b;

  /* compare so that index table of datagrams is ordered correctly
      - Any comment datagrams should be at the beginning in time order
      - The first datagram after any comments should be the IIP (installation parameters)
      - The first datagram after the IIP should be the first IOP (runtime parameters)
      - All other datagrams should be in time order, excepting that all datagrams
        associated with a ping should be grouped together (MRZ, XMS, MWC)
      - Within a ping datagram group, the MRZ datagrams should be first, then
        the XMS datagram, then the MWC datagrams.
      - The MRZ datagrams in a ping should be grouped by receiver index
      - The MWC datagrams in a ping should be grouped by reciever index
      */

  /* deal with comment datagrams */
  if (aa->emdgm_type == XMC || bb->emdgm_type == XMC) {
    if (aa->emdgm_type == bb->emdgm_type) {
      if (aa->time_d < bb->time_d)
        result = -1;
      else if (aa->time_d > bb->time_d)
        result = 1;
      else
        result = 0;
    }
    else if (aa->emdgm_type == XMC)
      result = -1;
    else // if (bb->emdgm_type == XMC)
      result = 1;
  }

  /* deal with IIP datagram */
  else if (aa->emdgm_type == IIP) {
    result = -1;
  }
  else if (bb->emdgm_type == IIP) {
  result = 1;
  }

  /* deal with XMB datagram */
  else if (aa->emdgm_type == XMB) {
    result = -1;
  }
  else if (bb->emdgm_type == XMB) {
  result = 1;
  }

  /* deal with both datagrams being ping datagrams (MRZ, XMS, MWC) */
  else if ((aa->emdgm_type == MRZ || aa->emdgm_type == XMS || bb->emdgm_type == MWC)
      && (bb->emdgm_type == MRZ || bb->emdgm_type == XMS || bb->emdgm_type == MWC)) {

    /* if ping numbers are different order by time stamp */
    if (aa->ping_num != bb->ping_num) {
      if (aa->time_d < bb->time_d)
        result = -1;
      else if (aa->time_d > bb->time_d)
        result = 1;
      else
        result = 0;
    }

    /* if ping numbers match */
    else { /* if (aa->ping_num == bb->ping_num) */

      /* if ping numbers match and datagram types are different order by MRZ < XMS < MWC */
      if ((aa->emdgm_type == MRZ && bb->emdgm_type == XMS)
          || (aa->emdgm_type == MRZ && bb->emdgm_type == MWC)
          || (aa->emdgm_type == XMS && bb->emdgm_type == MWC))
        result = -1;
      else if ((bb->emdgm_type == MRZ && aa->emdgm_type == XMS)
          || (bb->emdgm_type == MRZ && aa->emdgm_type == MWC)
          || (bb->emdgm_type == XMS && aa->emdgm_type == MWC))
        result = 1;

      /* if ping numbers match and datagram types match order by receiver index
          - set ping timestamp for later datagrams within the ping if possible */
      else { //if (aa->emdgm_type == bb->emdgm_type)
        if (aa->rx_index < bb->rx_index)
          result = -1;
        else if (aa->rx_index > bb->rx_index)
          result = 1;
        else // if (aa->rx_index == bb->rx_index) ==> this shouldn't happen
          result = 0;
      }
    }
  }

  /* deal with all other pairs of datagrams - order by timestamp */
  else if (aa->time_d < bb->time_d)
    result = -1;
  else if (aa->time_d > bb->time_d)
    result = 1;
  else
    result = 0;

  return(result);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_data(int verbose, void *mbio_ptr, void *store_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_data";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_index_table *dgm_index_table = NULL;
  struct mbsys_kmbes_index *dgm_index = NULL;
  size_t read_len = 0;
  char **bufferptr = NULL;
  char *buffer = NULL;
  int *bufferalloc = NULL;
  int *dgm_id = NULL;
  int done = MB_NO;
  int imrz, imwc, isounding;
  int numSoundings, numBackscatterSamples;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* get buffer and related vars from mbio saved values */
  bufferptr = (char **)&mb_io_ptr->raw_data;
  bufferalloc = (int *)&mb_io_ptr->structure_size;
  buffer = (char *)*bufferptr;

  /* get the datagram index table */
  dgm_index_table = (struct mbsys_kmbes_index_table *)mb_io_ptr->saveptr1;
  dgm_id = (int *)&mb_io_ptr->save1;

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;

  /* check index to see if more datagrams can be read */
  if (*dgm_id < dgm_index_table->dgm_count) {
    done = MB_NO;
    *error = MB_ERROR_NO_ERROR;
  }
  else {
    done = MB_YES;
    *error = MB_ERROR_EOF;
    status = MB_FAILURE;
  }

  /* if not done loop over reading data until a record is ready for return */
  while (done == MB_NO) {
    /* identify the next record in the index */
    dgm_index = &(dgm_index_table->indextable[*dgm_id]);
    store->time_d = dgm_index->time_d;
    mb_get_date(verbose, store->time_d, store->time_i);

    /* allocate memory to read the record if necessary */
    read_len = (size_t)dgm_index->header.numBytesDgm;
//fprintf(stderr, "\n----------->%s:%d READ dgm_index->header.numBytesDgm:%d\n", __FILE__, __LINE__, dgm_index->header.numBytesDgm);
    if (*bufferalloc <= read_len) {
      *bufferalloc = ((read_len / MBSYS_KMBES_START_BUFFER_SIZE) + 1) * MBSYS_KMBES_START_BUFFER_SIZE;
//fprintf(stderr, "\nAlloc more buffer: *bufferalloc:%d bufferptr:%p buffer:%p status:%d\n",
//*bufferalloc, bufferptr, buffer, status);
      status = mb_reallocd(verbose, __FILE__, __LINE__, *bufferalloc, (void **)bufferptr, error);
      if (status != MB_SUCCESS) {
        *bufferalloc = 0;
        done = MB_YES;
      }
      else {
        buffer = (char *)*bufferptr;
      }
//fprintf(stderr, "Realloc done: *bufferalloc:%d bufferptr:%p buffer:%p status:%d\n",
//*bufferalloc, bufferptr, buffer, status);
    }

    /* read the next datagram */
    if (status == MB_SUCCESS) {
//fprintf(stderr, "Reading datagram %c%c%c%c size:%d *bufferalloc:%d bufferptr:%p buffer:%p\n",
//dgm_index->header.dgmType[0], dgm_index->header.dgmType[1],
//dgm_index->header.dgmType[2], dgm_index->header.dgmType[3],
//dgm_index->header.numBytesDgm, *bufferalloc, bufferptr, buffer);
      fseek(mb_io_ptr->mbfp, dgm_index->file_pos, SEEK_SET);
      status = mb_fileio_get(verbose, mbio_ptr, (void *)&buffer[0], &read_len, error);
      mb_io_ptr->file_pos = ftell(mb_io_ptr->mbfp);
//fprintf(stderr, "Read %zu bytes status:%d\n", read_len, status);
    }

    /* if valid read the record type */
    if (status == MB_SUCCESS) {

      switch (dgm_index->emdgm_type) {

        case IIP:
            /* #IIP - Info Installation PU */
          status = mbr_kemkmall_rd_iip(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case IOP:
            /* #IOP -  Runtime datagram */
          status = mbr_kemkmall_rd_iop(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SPO:
            /* #SPO - Sensor POsition data */
          status = mbr_kemkmall_rd_spo(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SKM:
            /* #SKM - KM binary sensor data */
          status = mbr_kemkmall_rd_skm(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SVP:
            /* #SVP - Sound Velocity Profile */
          status = mbr_kemkmall_rd_svp(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SVT:
          /* #SVP - Sensor sound Velocity measured at Transducer */
          status = mbr_kemkmall_rd_svt(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SCL:
            /* #SCL - Sensor CLock datagram */
          status = mbr_kemkmall_rd_scl(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SDE:
          /* #SDE - Sensor DEpth data */
          status = mbr_kemkmall_rd_sde(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SHI:
          /* #SHI - Sensor HeIght data */
          status = mbr_kemkmall_rd_shi(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case SHA:
          /* #SHA - Sensor HeAding */
          status = mbr_kemkmall_rd_sha(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case MRZ:
          /* #MRZ - multibeam data for raw range, depth, reflectivity, seabed image(SI) etc. */
          /*        not done until all MRZ datagrams for a ping are read */
          status = mbr_kemkmall_rd_mrz(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
//store = (struct mbsys_kmbes_struct *)store_ptr;
//fprintf(stderr, "----------->%s:%d READ dgm_index->header.numBytesDgm:%d store->mrz[0].header.numBytesDgm:%d store->mrz[1].header.numBytesDgm:%d \n",
//__FILE__, __LINE__, dgm_index->header.numBytesDgm, store->mrz[0].header.numBytesDgm, store->mrz[0].header.numBytesDgm);

          /* check to see if done */
          if (status != MB_SUCCESS) {
            done = MB_NO;
          } else {
            done = MB_YES;
            store->n_mrz_read = 0;
            store->n_mrz_needed = dgm_index->rx_per_ping;
            for (imrz=0;imrz<dgm_index->rx_per_ping;imrz++) {
              if (dgm_index->ping_num != store->mrz[imrz].cmnPart.pingCnt) {
                done = MB_NO;
              } else {
                store->n_mrz_read++;
              }
            }
            store->num_soundings = 0;
            store->num_backscatter_samples = 0;
            store->num_pixels = 0;
            if (done == MB_YES) {
              for (imrz=0;imrz<dgm_index->rx_per_ping;imrz++) {
                numSoundings = store->mrz[imrz].rxInfo.numSoundingsMaxMain + store->mrz[imrz].rxInfo.numExtraDetections;
                numBackscatterSamples = 0;
                for (isounding=0;isounding<numSoundings;isounding++) {
                  numBackscatterSamples += store->mrz[imrz].sounding[isounding].SInumSamples;
                }
                store->num_soundings += numSoundings;
                store->num_backscatter_samples += numBackscatterSamples;
              }
            }
          }

          /* if pseudosidescan is expected and XMS datagram not read, then not done yet */
          if (done == MB_YES && store->xmb.pseudosidescan_enabled == MB_YES
              && dgm_index->ping_num != store->xms.pingCnt) {
            done = MB_NO;
          }
          break;

        case MWC:
          /* #MWC - multibeam water column datagram */
          /*        not done until all MRZ datagrams for a ping are read */
          status = mbr_kemkmall_rd_mwc(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);

          /* check to see if done */
          //done = MB_YES;
          store->n_mwc_read = 0;
          store->n_mwc_needed = dgm_index->rx_per_ping;
          for (imwc=0;imwc<dgm_index->rx_per_ping;imwc++) {
            if (dgm_index->ping_num != store->mwc[imwc].cmnPart.pingCnt) {
              done = MB_NO;
            } else {
              store->n_mwc_read++;
            }
          }
          break;

        case CPO:
          /* #CPO - Compatibility position sensor data */
          status = mbr_kemkmall_rd_cpo(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case CHE:
          /* #CHE - Compatibility heave data */
          status = mbr_kemkmall_rd_che(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case XMB:
          /* #XMB - Indicates these data were written by MB-System (MB-System only) */
          status = mbr_kemkmall_rd_xmb(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case XMC:
          /* #XMC - Comment datagram (MB-System only) */
          status = mbr_kemkmall_rd_xmc(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        case XMS:
          /* #XMS - MB-System multibeam pseudosidescan */
          status = mbr_kemkmall_rd_xms(verbose, buffer, store_ptr, (void *)&dgm_index->header, error);
          if (status != MB_SUCCESS) {
            done = MB_NO;
          } else {
            if (store->n_mrz_read > 0 && store->n_mrz_read == store->n_mrz_needed
                && store->mrz[0].cmnPart.pingCnt == store->xms.pingCnt) {
              done = MB_YES;
            } else {
              done = MB_NO;
            }
          }
          break;

        case UNKNOWN:
          /* Unknown datagram format */
          status = mbr_kemkmall_rd_unknown(verbose, buffer, store_ptr, (void *)&dgm_index->header, error); // TODO: implement!
          if (status == MB_SUCCESS)
            done = MB_YES;
          break;

        default:
          /* should never get here */
          status = MB_FAILURE;
          done = MB_YES;
          break;

      }
    }

    /* set done if read failure */
    else {
      done = MB_YES;
    }

    /* increment the index counter */
    (*dgm_id)++;

    /* if not done but no more data in index then done with error */
    if (done == MB_NO && *dgm_id >= dgm_index_table->dgm_count) {
      done = MB_YES;
      *error = MB_ERROR_EOF;
      status = MB_FAILURE;
    }

  }

  /* get file position */
  mb_io_ptr->file_bytes = ftell(mb_io_ptr->mbfp);

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
}

/*--------------------------------------------------------------------*/
int mbr_kemkmall_wr_data(int verbose, void *mbio_ptr, void *store_ptr, int *error) {
  char *function_name = "mbr_kemkmall_wr_data";
  int status = MB_SUCCESS;
  struct mb_io_struct *mb_io_ptr = NULL;
  struct mbsys_kmbes_struct *store = NULL;
  size_t write_len = 0;
  char **bufferptr = NULL;
  char *buffer = NULL;
  int *bufferalloc = NULL;
  int imrz, imwc = 0;
  size_t size = 0;


  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       mbio_ptr:   %p\n", (void *)mbio_ptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to mbio descriptor */
  mb_io_ptr = (struct mb_io_struct *)mbio_ptr;

  /* get buffer and related vars from mbio saved values */
  bufferptr = (char **)&mb_io_ptr->raw_data;
  bufferalloc = (int *)&mb_io_ptr->structure_size;
  buffer = (char *)*bufferptr;

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;

  /* write the current data record type */
  switch (store->kind) {

    case MB_DATA_INSTALLATION:
      /* #IIP - Info Installation PU */
      status = mbr_kemkmall_wr_iip(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      status = mbr_kemkmall_wr_xmb(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_RUN_PARAMETER:
      /* #IOP -  Runtime datagram */
      status = mbr_kemkmall_wr_iop(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_NAV:
      /* #SPO - Sensor POsition data */
      status = mbr_kemkmall_wr_spo(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_NAV1:
      /* #SKM - KM binary sensor data */
      status = mbr_kemkmall_wr_skm(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_VELOCITY_PROFILE:
      /* #SVP - Sound Velocity Profile */
      status = mbr_kemkmall_wr_svp(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_SSV:
      /* #SVT - Sensor sound Velocity measured at Transducer */
      status = mbr_kemkmall_wr_svt(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_CLOCK:
      /* #SCL - Sensor CLock datagram */
      status = mbr_kemkmall_wr_scl(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_SONARDEPTH:
      /* #SDE - Sensor DEpth data */
      status = mbr_kemkmall_wr_sde(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_HEIGHT:
      /* #SHI - Sensor HeIght data */
      status = mbr_kemkmall_wr_shi(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_HEADING:
      /* #SHA - Sensor HeAding */
      status = mbr_kemkmall_wr_sha(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_DATA:
      /* #MRZ - multibeam data for raw range,
      depth, reflectivity, seabed image(SI) etc. */
      for (imrz=0;imrz<store->n_mrz_read;imrz++) {
////fprintf(stderr, "************>%s:%d WRITE mbr_kemkmall_wr_data imrz:%d mrz->header.numBytesDgm:%d\n", __FILE__, __LINE__, imrz, store->mrz[imrz].header.numBytesDgm);
        status = mbr_kemkmall_wr_mrz(verbose, bufferalloc, bufferptr, store_ptr, imrz, &size, error);
        if (status == MB_SUCCESS)
          status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      }
      /* #XMS - multibeam pseudosidescan (MB-System only) */
      status = mbr_kemkmall_wr_xms(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_WATER_COLUMN:
      /* #MWC - multibeam water column datagram */
      for (imwc=0;imwc< store->n_mwc_read;imwc++) {
        status = mbr_kemkmall_wr_mwc(verbose, bufferalloc, bufferptr, store_ptr, imwc, &size, error);
        if (status == MB_SUCCESS)
          status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      }
      break;

    case MB_DATA_NAV2:
      /* #CPO - Compatibility position sensor data */
      status = mbr_kemkmall_wr_cpo(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_HEAVE:
      /* #CHE - Compatibility heave data */
      status = mbr_kemkmall_wr_che(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_MBSYSTEM:
      /* #XMB - Indicates these data were written by MB-System (MB-System only) */
      /* Always written immediately after the #IIP datagram */
      //status = mbr_kemkmall_wr_xmb(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      //if (status == MB_SUCCESS)
      //  status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case MB_DATA_COMMENT:
      /* #XMC - Comment datagram (MB-System only) */
      status = mbr_kemkmall_wr_xmc(verbose, bufferalloc, bufferptr, store_ptr, &size, error);
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    case UNKNOWN:
      /* Unknown datagram format */
      status = mbr_kemkmall_wr_unknown(verbose, bufferalloc, bufferptr, store_ptr, &size, error); // TODO: implement!
      if (status == MB_SUCCESS)
        status = mb_fileio_put(verbose, mbio_ptr, (char *)(*bufferptr), &size, error);
      break;

    default:
        /* should never get here */
        status = MB_FAILURE;
        break;
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "Data record written: type:%d status:%d error:%d\n", store->kind, status, *error);
#endif

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
}

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_hdr(int verbose, char *buffer, void *header_ptr, void *emdgm_type_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_hdr";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_header *header = NULL;
  mbsys_kmbes_emdgm_type *emdgm_type = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:        %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:         %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       header_ptr:     %p\n", (void *)header_ptr);
    fprintf(stderr, "dbg2       emdgm_type_ptr: %p\n", (void *)emdgm_type_ptr);
  }

  /* get pointer to header structure */
  header = (struct mbsys_kmbes_header *)header_ptr;
  emdgm_type = (mbsys_kmbes_emdgm_type *)emdgm_type_ptr;

  /* extract the data */
  index = 0;
  mb_get_binary_int(MB_YES, &buffer[index], &(header->numBytesDgm));
  index += 4;
  memcpy(&(header->dgmType), &buffer[index], sizeof(header->dgmType));
  index += 4;
  header->dgmVersion = buffer[index];
  index++;
  header->systemID = buffer[index];
  index++;
  mb_get_binary_short(MB_YES, &buffer[index], &(header->echoSounderID));
  index += 2;
  mb_get_binary_int(MB_YES, &buffer[index], &(header->time_sec));
  index += 4;
  mb_get_binary_int(MB_YES, &buffer[index], &(header->time_nanosec));

  /* identify the datagram type */
  if (strncmp((const char *)header->dgmType, MBSYS_KMBES_I_INSTALLATION_PARAM, 4) == 0 ) {
    *emdgm_type = IIP;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_I_OP_RUNTIME, 4) == 0) {
    *emdgm_type = IOP;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_POSITION, 4) == 0) {
    *emdgm_type = SPO;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_KM_BINARY, 4) == 0) {
    *emdgm_type = SKM;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_SOUND_VELOCITY_PROFILE, 4) == 0) {
    *emdgm_type = SVP;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_SOUND_VELOCITY_TRANSDUCER, 4) == 0) {
    *emdgm_type = SVT;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_CLOCK, 4) == 0) {
    *emdgm_type = SCL;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_DEPTH, 4) == 0) {
    *emdgm_type = SDE;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_HEIGHT, 4) == 0) {
    *emdgm_type = SHI;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_S_HEADING, 4) == 0) {
    *emdgm_type = SHA;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_M_RANGE_AND_DEPTH, 4) == 0) {
    *emdgm_type = MRZ;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_M_WATER_COLUMN, 4) == 0) {
    *emdgm_type = MWC;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_C_POSITION, 4) == 0) {
    *emdgm_type = CPO;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_C_HEAVE, 4) == 0) {
    *emdgm_type = CHE;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_X_MBSYSTEM, 4) == 0) {
    *emdgm_type = XMB;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_X_COMMENT, 4) == 0) {
    *emdgm_type = XMC;
  }
  else if (strncmp((const char *)header->dgmType, MBSYS_KMBES_X_PSEUDOSIDESCAN, 4) == 0) {
    *emdgm_type = XMS;
  }
  else {
    *emdgm_type = UNKNOWN;
  }

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", header->numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %.4s\n", header->dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", header->dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", header->systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", header->echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", header->time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", header->time_nanosec);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       dgmType:    %.4s\n", header->dgmType);
    fprintf(stderr, "dbg2       emdgm_type: %d\n", *emdgm_type);
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_spo(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_spo";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_spo *spo = NULL;
  size_t numBytesRawSensorData = 0;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  spo = &(store->spo);

  /* copy the header */
  spo->header = *header;

  /* calc number of bytes for raw sensor data */
  numBytesRawSensorData = spo->header.numBytesDgm - MBSYS_KMBES_SPO_VAR_OFFSET;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  /* common part */
  mb_get_binary_short(MB_YES, &buffer[index], &(spo->cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(spo->cmnPart.sensorSystem));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(spo->cmnPart.sensorStatus));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(spo->cmnPart.padding));
  index += 2;

  /* sensor data block */
  mb_get_binary_int(MB_YES, &buffer[index], &(spo->sensorData.timeFromSensor_sec));
  index += 4;
  mb_get_binary_int(MB_YES, &buffer[index], &(spo->sensorData.timeFromSensor_nanosec));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(spo->sensorData.posFixQuality_m));
  index += 4;
  mb_get_binary_double(MB_YES, &buffer[index], &(spo->sensorData.correctedLat_deg));
  index += 8;
  mb_get_binary_double(MB_YES, &buffer[index], &(spo->sensorData.correctedLong_deg));
  index += 8;
  mb_get_binary_float(MB_YES, &buffer[index], &(spo->sensorData.speedOverGround_mPerSec));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(spo->sensorData.courseOverGround_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(spo->sensorData.ellipsoidHeightReRefPoint_m));
  index += 4;
  memcpy(&(spo->sensorData.posDataFromSensor), &buffer[index], numBytesRawSensorData);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:                 %u\n", spo->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                     %s\n", spo->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:                  %u\n", spo->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                    %u\n", spo->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:               %u\n", spo->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                    %u\n", spo->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:                %u\n", spo->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:             %u\n", spo->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:                %u\n", spo->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:                %u\n", spo->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:                     %u\n", spo->cmnPart.padding);

    fprintf(stderr, "dbg5       timeFromSensor_sec:          %u\n", spo->sensorData.timeFromSensor_sec);
    fprintf(stderr, "dbg5       timeFromSensor_nanosec:      %u\n", spo->sensorData.timeFromSensor_nanosec);
    fprintf(stderr, "dbg5       posFixQuality_m:             %f\n", spo->sensorData.posFixQuality_m);
    fprintf(stderr, "dbg5       correctedLat_deg:            %f\n", spo->sensorData.correctedLat_deg);
    fprintf(stderr, "dbg5       correctedLong_deg:           %f\n", spo->sensorData.correctedLong_deg);
    fprintf(stderr, "dbg5       speedOverGround_mPerSec:     %f\n", spo->sensorData.speedOverGround_mPerSec);
    fprintf(stderr, "dbg5       courseOverGround_deg:        %f\n", spo->sensorData.courseOverGround_deg);
    fprintf(stderr, "dbg5       ellipsoidHeightReRefPoint_m: %f\n", spo->sensorData.ellipsoidHeightReRefPoint_m);
    fprintf(stderr, "dbg5       posDataFromSensor:           %s\n", spo->sensorData.posDataFromSensor);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_NAV;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType,header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/


int mbr_kemkmall_rd_skm(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_skm";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_skm *skm = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  skm = &(store->skm);

  /* copy the header */
  skm->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  /* info part */
  mb_get_binary_short(MB_YES, &buffer[index], &(skm->infoPart.numBytesInfoPart));
  index += 2;
  skm->infoPart.sensorSystem = buffer[index];
  index++;
  skm->infoPart.sensorStatus = buffer[index];
  index++;
  mb_get_binary_short(MB_YES, &buffer[index], &(skm->infoPart.sensorInputFormat));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(skm->infoPart.numSamplesArray));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(skm->infoPart.numBytesPerSample));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(skm->infoPart.sensorDataContents));
  index += 2;

  for (i=0; i<(skm->infoPart.numSamplesArray); i++ ) {

    /* KMbinary */
    memcpy(&(skm->sample[i].KMdefault.dgmType), &buffer[index], 4);
    index += 4;
    mb_get_binary_short(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.numBytesDgm));
    index += 2;
    mb_get_binary_short(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.dgmVersion));
    index += 2;
    mb_get_binary_int(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.time_sec));
    index += 4;
    mb_get_binary_int(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.time_nanosec));
    index += 4;
    mb_get_binary_int(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.status));
    index += 4;
    mb_get_binary_double(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.latitude_deg));
    index += 8;
    mb_get_binary_double(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.longitude_deg));
    index += 8;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.ellipsoidHeight_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.roll_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.pitch_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.heading_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.heave_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.rollRate));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.pitchRate));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.yawRate));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.velNorth));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.velEast));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.velDown));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.latitudeError_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.longitudeError_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.ellipsoidHeightError_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.rollError_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.pitchError_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.headingError_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.heaveError_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.northAcceleration));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.eastAcceleration));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].KMdefault.downAcceleration));
    index += 4;

    /* KMdelayedHeave */
    mb_get_binary_int(MB_YES, &buffer[index], &(skm->sample[i].delayedHeave.time_sec));
    index += 4;
    mb_get_binary_int(MB_YES, &buffer[index], &(skm->sample[i].delayedHeave.time_nanosec));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(skm->sample[i].delayedHeave.delayedHeave_m));
    index += 4;
  }

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:                %u\n", skm->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                    %s\n", skm->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:                 %u\n", skm->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                   %u\n", skm->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:              %u\n", skm->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                   %u\n", skm->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:               %u\n", skm->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesInfoPart:           %u\n", skm->infoPart.numBytesInfoPart);
    fprintf(stderr, "dbg5       sensorSystem:               %u\n", skm->infoPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:               %u\n", skm->infoPart.sensorStatus);
    fprintf(stderr, "dbg5       sensorInputFormat:          %u\n", skm->infoPart.sensorInputFormat);
    fprintf(stderr, "dbg5       numSamplesArray:            %u\n", skm->infoPart.numSamplesArray);
    fprintf(stderr, "dbg5       numBytesPerSample:          %u\n", skm->infoPart.numBytesPerSample);
    fprintf(stderr, "dbg5       sensorDataContents:         %u\n", skm->infoPart.sensorDataContents);

    for (i=0; i<(skm->infoPart.numSamplesArray); i++ ) {
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.dgmType:                %s\n", i, skm->sample[i].KMdefault.dgmType);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.numBytesDgm:            %u\n", i, skm->sample[i].KMdefault.numBytesDgm);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.dgmVersion:             %u\n", i, skm->sample[i].KMdefault.dgmVersion);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.time_sec:               %u\n", i, skm->sample[i].KMdefault.time_sec);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.time_nanosec:           %u\n", i, skm->sample[i].KMdefault.time_nanosec);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.status:                 %u\n", i, skm->sample[i].KMdefault.status);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.latitude_deg:           %f\n", i, skm->sample[i].KMdefault.latitude_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.longitude_deg:          %f\n", i, skm->sample[i].KMdefault.longitude_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.ellipsoidHeight_m:      %f\n", i, skm->sample[i].KMdefault.ellipsoidHeight_m);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.roll_deg:               %f\n", i, skm->sample[i].KMdefault.roll_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.pitch_deg:              %f\n", i, skm->sample[i].KMdefault.pitch_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.heading_deg:            %f\n", i, skm->sample[i].KMdefault.heading_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.heave_m:                %f\n", i, skm->sample[i].KMdefault.heave_m);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.rollRate:               %f\n", i, skm->sample[i].KMdefault.rollRate);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.pitchRate:              %f\n", i, skm->sample[i].KMdefault.pitchRate);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.yawRate:                %f\n", i, skm->sample[i].KMdefault.yawRate);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.velNorth:               %f\n", i, skm->sample[i].KMdefault.velNorth);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.velEast:                %f\n", i, skm->sample[i].KMdefault.velEast);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.velDown:                %f\n", i, skm->sample[i].KMdefault.velDown);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.latitudeError_m:        %f\n", i, skm->sample[i].KMdefault.latitudeError_m);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.longitudeError_m:       %f\n", i, skm->sample[i].KMdefault.longitudeError_m);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.ellipsoidHeightError_m: %f\n", i, skm->sample[i].KMdefault.ellipsoidHeightError_m);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.rollError_deg:          %f\n", i, skm->sample[i].KMdefault.rollError_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.pitchError_deg:         %f\n", i, skm->sample[i].KMdefault.pitchError_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.headingError_deg:       %f\n", i, skm->sample[i].KMdefault.headingError_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.heaveError_m:           %f\n", i, skm->sample[i].KMdefault.heaveError_m);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.northAcceleration:      %f\n", i, skm->sample[i].KMdefault.northAcceleration);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.eastAcceleration:       %f\n", i, skm->sample[i].KMdefault.eastAcceleration);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.downAcceleration:       %f\n", i, skm->sample[i].KMdefault.downAcceleration);

      //
      fprintf(stderr, "dbg5       sample[%3d].delayedHeave.time_sec:            %u\n", i, skm->sample[i].delayedHeave.time_sec);
      fprintf(stderr, "dbg5       sample[%3d].delayedHeave.time_nanosec:        %u\n", i, skm->sample[i].delayedHeave.time_nanosec);
      fprintf(stderr, "dbg5       sample[%3d].delayedHeave.delayedHeave_m:      %f\n", i, skm->sample[i].delayedHeave.delayedHeave_m);
    }

  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_NAV1;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_svp(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error){
  char *function_name = "mbr_kemkmall_rd_svp";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_svp *svp = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  svp = &(store->svp);

  /* copy the header */
  svp->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  /* svp common part */
  mb_get_binary_short(MB_YES, &buffer[index], &(svp->numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(svp->numSamples));
  index += 2;
  memcpy(&svp->sensorFormat, &buffer[index], 4);
  index += 4;
  mb_get_binary_int(MB_YES, &buffer[index], &(svp->time_sec));
  index += 4;
  mb_get_binary_double(MB_YES, &buffer[index], &(svp->latitude_deg));
  index += 8;
  mb_get_binary_double(MB_YES, &buffer[index], &(svp->longitude_deg));
  index += 8;

  /* svp data block */
  for (i=0; i<(svp->numSamples); i++ ) {
    mb_get_binary_float(MB_YES, &buffer[index], &(svp->sensorData[i].depth_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(svp->sensorData[i].soundVelocity_mPerSec));
    index += 4;
    mb_get_binary_int(MB_YES, &buffer[index], &(svp->sensorData[i].padding));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(svp->sensorData[i].temp_C));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(svp->sensorData[i].salinity));
    index += 4;
  }

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, " dbg5       numBytesDgm:     %u\n", svp->header.numBytesDgm);
    fprintf(stderr, " dbg5       dgmType:         %s\n", svp->header.dgmType);
    fprintf(stderr, " dbg5       dgmVersion:      %u\n", svp->header.dgmVersion);
    fprintf(stderr, " dbg5       systemID:        %u\n", svp->header.systemID);
    fprintf(stderr, " dbg5       echoSounderID:   %u\n", svp->header.echoSounderID);
    fprintf(stderr, " dbg5       time_sec:        %u\n", svp->header.time_sec);
    fprintf(stderr, " dbg5       time_nanosec:    %u\n", svp->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", svp->numBytesCmnPart);
    fprintf(stderr, "dbg5       numSamples:       %u\n", svp->numSamples);
    fprintf(stderr, "dbg5       sensorFormat:     %s\n", svp->sensorFormat);
    fprintf(stderr, "dbg5       time_sec:         %u\n", svp->time_sec);
    fprintf(stderr, "dbg5       latitude_deg:     %f\n", svp->latitude_deg);
    fprintf(stderr, "dbg5       longitude_deg:    %f\n", svp->longitude_deg);

    for (i = 0; i < (svp->numSamples); i++) {
      fprintf(stderr, "dbg5       sensorData[%3d].depth_m:                %f\n", i, svp->sensorData[i].depth_m);
      fprintf(stderr, "dbg5       sensorData[%3d].soundVelocity_mPerSec:  %f\n", i, svp->sensorData[i].soundVelocity_mPerSec);
      fprintf(stderr, "dbg5       sensorData[%3d].padding:                %d\n", i, svp->sensorData[i].padding);
      fprintf(stderr, "dbg5       sensorData[%3d].temp_C:                 %f\n", i, svp->sensorData[i].temp_C);
      fprintf(stderr, "dbg5       sensorData[%3d].salinity:               %f\n", i, svp->sensorData[i].salinity);
    }
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_VELOCITY_PROFILE;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_svt(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error){
  char *function_name = "mbr_kemkmall_rd_svt";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_svt *svt = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  svt = &(store->svt);

  /* copy the header */
  svt->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  /* svp info */
  mb_get_binary_short(MB_YES, &buffer[index], &(svt->infoPart.numBytesInfoPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(svt->infoPart.sensorStatus));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(svt->infoPart.sensorInputFormat));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(svt->infoPart.numSamplesArray));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(svt->infoPart.numBytesPerSample));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(svt->infoPart.sensorDataContents));
  index += 2;
  mb_get_binary_float(MB_YES, &buffer[index], &(svt->infoPart.filterTime_sec));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(svt->infoPart.soundVelocity_mPerSec_offset));
  index += 4;

  /* svt data blocks */
  for (i=0; i<(svt->infoPart.numSamplesArray); i++ ) {
    mb_get_binary_int(MB_YES, &buffer[index], &(svt->sensorData[i].time_sec));
    index += 4;
    mb_get_binary_int(MB_YES, &buffer[index], &(svt->sensorData[i].time_nanosec));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(svt->sensorData[i].soundVelocity_mPerSec));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(svt->sensorData[i].temp_C));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(svt->sensorData[i].pressure_Pa));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(svt->sensorData[i].salinity));
    index += 4;
  }

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:             %u\n", svt->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                 %s\n", svt->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:              %u\n", svt->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                %u\n", svt->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:           %u\n", svt->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                %u\n", svt->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:            %u\n", svt->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesInfoPart:         %u\n", svt->infoPart.numBytesInfoPart);
    fprintf(stderr, "dbg5       sensorStatus:             %u\n", svt->infoPart.sensorStatus);
    fprintf(stderr, "dbg5       sensorInputFormat:        %u\n", svt->infoPart.sensorInputFormat);
    fprintf(stderr, "dbg5       numSamplesArray:          %u\n", svt->infoPart.numSamplesArray);
    fprintf(stderr, "dbg5       sensorDataContents:       %u\n", svt->infoPart.sensorDataContents);
    fprintf(stderr, "dbg5       filterTime_sec:           %f\n", svt->infoPart.filterTime_sec);
    fprintf(stderr, "dbg5       soundVelocity_mPerSec_offset: %f\n", svt->infoPart.soundVelocity_mPerSec_offset);

    for (i = 0; i < (svt->infoPart.numSamplesArray); i++) {
      fprintf(stderr, "dbg5       sensorData[%3d].time_sec:                     %u\n", i, svt->sensorData[i].time_sec);
      fprintf(stderr, "dbg5       sensorData[%3d].time_nanosec:                 %u\n", i, svt->sensorData[i].time_nanosec);
      fprintf(stderr, "dbg5       sensorData[%3d].soundVelocity_mPerSec:        %f\n", i, svt->sensorData[i].soundVelocity_mPerSec);
      fprintf(stderr, "dbg5       sensorData[%3d].temp_C:                       %f\n", i, svt->sensorData[i].temp_C);
      fprintf(stderr, "dbg5       sensorData[%3d].pressure_Pa:                  %f\n", i, svt->sensorData[i].pressure_Pa);
      fprintf(stderr, "dbg5       sensorData[%3d].salinity:                     %f\n", i, svt->sensorData[i].salinity);
    }
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_SSV;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_scl(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_scl";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_scl *scl = NULL;
  size_t numBytesRawSensorData = 0;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  scl = &(store->scl);

  /* copy the header */
  scl->header = *header;

  /* calc number of bytes for raw sensor data */
  numBytesRawSensorData = scl->header.numBytesDgm - MBSYS_KMBES_SCL_VAR_OFFSET;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  // common part
  mb_get_binary_short(MB_YES, &buffer[index], &(scl->cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(scl->cmnPart.sensorSystem));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(scl->cmnPart.sensorStatus));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(scl->cmnPart.padding));
  index += 2;

  // sensor data block
  mb_get_binary_float(MB_YES, &buffer[index], &(scl->sensorData.offset_sec));
  index += 4;
  mb_get_binary_int(MB_YES, &buffer[index], &(scl->sensorData.clockDevPU_nanosec));
  index += 4;
  memcpy(&(scl->sensorData.dataFromSensor), &buffer[index], numBytesRawSensorData);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:         %u\n", scl->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:             %s\n", scl->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:          %u\n", scl->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:            %u\n", scl->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:       %u\n", scl->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:            %u\n", scl->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:        %u\n", scl->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:     %u\n", scl->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:        %u\n", scl->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:        %u\n", scl->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:             %u\n", scl->cmnPart.padding);

    fprintf(stderr, "dbg5       offset_sec:          %f\n", scl->sensorData.offset_sec);
    fprintf(stderr, "dbg5       clockDevPU_nanosec:  %d\n", scl->sensorData.clockDevPU_nanosec);
    fprintf(stderr, "dbg5       dataFromSensor:      %s\n", scl->sensorData.dataFromSensor);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_CLOCK;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_sde(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_sde";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_sde *sde = NULL;
  size_t numBytesRawSensorData = 0;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  sde = &(store->sde);

  /* copy the header */
  sde->header = *header;

  /* calc number of bytes for raw sensor data */
  numBytesRawSensorData = sde->header.numBytesDgm - MBSYS_KMBES_SDE_VAR_OFFSET;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  // common part
  mb_get_binary_short(MB_YES, &buffer[index], &(sde->cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sde->cmnPart.sensorSystem));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sde->cmnPart.sensorStatus));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sde->cmnPart.padding));
  index += 2;

  // sensor data block
  mb_get_binary_float(MB_YES, &buffer[index], &(sde->sensorData.depthUsed_m));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(sde->sensorData.offset));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(sde->sensorData.scale));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(sde->sensorData.latitude_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(sde->sensorData.longitude_deg));
  index += 4;
  memcpy(&(sde->sensorData.dataFromSensor), &buffer[index], numBytesRawSensorData);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:      %u\n", sde->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:          %s\n", sde->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:       %u\n", sde->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:         %u\n", sde->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:    %u\n", sde->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:         %u\n", sde->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:     %u\n", sde->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", sde->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:     %u\n", sde->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:     %u\n", sde->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:          %u\n", sde->cmnPart.padding);

    fprintf(stderr, "dbg5       depthUsed_m:      %f\n", sde->sensorData.depthUsed_m);
    fprintf(stderr, "dbg5       offset:           %f\n", sde->sensorData.offset);
    fprintf(stderr, "dbg5       scale:            %f\n", sde->sensorData.scale);
    fprintf(stderr, "dbg5       latitude_deg:     %f\n", sde->sensorData.latitude_deg);
    fprintf(stderr, "dbg5       longitude_deg:    %f\n", sde->sensorData.longitude_deg);
    fprintf(stderr, "dbg5       dataFromSensor:   %s\n", sde->sensorData.dataFromSensor);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_SONARDEPTH;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %c%c%c%c read - time: %d.%9.9d status:%d error:%d\n",
  header->dgmType[0], header->dgmType[1], header->dgmType[2], header->dgmType[3],
  header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_shi(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_shi";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_shi *shi = NULL;
  size_t numBytesRawSensorData = 0;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  shi = &(store->shi);

  /* copy the header */
  shi->header = *header;

  /* calc number of bytes for raw sensor data */
  numBytesRawSensorData = shi->header.numBytesDgm - MBSYS_KMBES_SHI_VAR_OFFSET;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  // common part
  mb_get_binary_short(MB_YES, &buffer[index], &(shi->cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(shi->cmnPart.sensorSystem));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(shi->cmnPart.sensorStatus));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(shi->cmnPart.padding));
  index += 2;

  // sensor data block
  mb_get_binary_short(MB_YES, &buffer[index], &(shi->sensorData.sensorType));
  index += 2;
  mb_get_binary_float(MB_YES, &buffer[index], &(shi->sensorData.heigthUsed_m));
  index += 4;
  memcpy(&(shi->sensorData.dataFromSensor), &buffer[index], numBytesRawSensorData);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:      %u\n", shi->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:          %s\n", shi->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:       %u\n", shi->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:         %u\n", shi->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:    %u\n", shi->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:         %u\n", shi->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:     %u\n", shi->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", shi->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:     %u\n", shi->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:     %u\n", shi->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:          %u\n", shi->cmnPart.padding);

    fprintf(stderr, "dbg5       sensorType:       %u\n", shi->sensorData.sensorType);
    fprintf(stderr, "dbg5       heigthUsed_m:     %f\n", shi->sensorData.heigthUsed_m);
    fprintf(stderr, "dbg5       dataFromSensor:   %s\n", shi->sensorData.dataFromSensor);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_HEIGHT;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_sha(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_sha";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_sha *sha = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  sha = &(store->sha);

  /* get header */
  sha->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  // common part
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->cmnPart.sensorSystem));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->cmnPart.sensorStatus));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->cmnPart.padding));
  index += 2;

  // sensor info
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->dataInfo.numBytesInfoPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->dataInfo.numSamplesArray));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->dataInfo.numBytesPerSample));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(sha->dataInfo.numBytesRawSensorData));
  index += 2;

  // sensor data blocks
  for (i = 0; i<(sha->dataInfo.numSamplesArray); i++) {
    mb_get_binary_int(MB_YES, &buffer[index], &(sha->sensorData[i].timeSinceRecStart_nanosec));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(sha->sensorData[i].headingCorrected_deg));
    index += 4;
    memcpy(&(sha->sensorData[i].dataFromSensor), &buffer[index], sha->dataInfo.numBytesRawSensorData);
    index += sha->dataInfo.numBytesRawSensorData;
  }

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:            %u\n", sha->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                %s\n", sha->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:             %u\n", sha->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:               %u\n", sha->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:          %u\n", sha->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:               %u\n", sha->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:           %u\n", sha->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:        %u\n", sha->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:           %u\n", sha->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:           %u\n", sha->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:                %u\n", sha->cmnPart.padding);

    fprintf(stderr, "dbg5       numBytesInfoPart:       %u\n", sha->dataInfo.numBytesInfoPart);
    fprintf(stderr, "dbg5       numSamplesArray:        %u\n", sha->dataInfo.numSamplesArray);
    fprintf(stderr, "dbg5       numBytesPerSample:      %u\n", sha->dataInfo.numBytesPerSample);
    fprintf(stderr, "dbg5       numBytesRawSensorData:  %u\n", sha->dataInfo.numBytesRawSensorData);

    for (i = 0; i<(sha->dataInfo.numSamplesArray); i++) {
      fprintf(stderr, "dbg5       sensorData[%3d].timeSinceRecStart_nanosec: %u\n", i, sha->sensorData[i].timeSinceRecStart_nanosec);
      fprintf(stderr, "dbg5       sensorData[%3d].headingCorrected_deg:      %f\n", i, sha->sensorData[i].headingCorrected_deg);
      fprintf(stderr, "dbg5       sensorData[%3d].dataFromSensor:            %s\n", i, sha->sensorData[i].dataFromSensor);
    }
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_HEADING;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_mrz(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_mrz";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_mrz *mrz = NULL;
  struct mbsys_kmbes_m_partition partition;
  struct mbsys_kmbes_m_body cmnPart;
  int index = 0;
  int index_EMdgmMbody, index_pingInfo, index_txSectorInfo = 0;
  int index_rxInfo, index_extraDetClassInfo, index_sounding, index_SIsample = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *) buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *) store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;

  /* get the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  /* EMdgmMpartition - data partition information */
  mb_get_binary_short(MB_YES, &buffer[index], &(partition.numOfDgms));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(partition.dgmNum));
  index += 2;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr,"dbg5       numOfDgms = %d\n", partition.numOfDgms);
    fprintf(stderr,"dbg5       dgmNum    = %d\n", partition.dgmNum);
  }

  /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
  mb_get_binary_short(MB_YES, &buffer[index], &(cmnPart.numBytesCmnPart));
  index_EMdgmMbody = index;
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(cmnPart.pingCnt));
  index += 2;
  cmnPart.rxFansPerPing = buffer[index];
  index++;
  cmnPart.rxFanIndex = buffer[index];
  index++;
  cmnPart.swathsPerPing = buffer[index];
  index++;
  cmnPart.swathAlongPosition = buffer[index];
  index++;
  cmnPart.txTransducerInd = buffer[index];
  index++;
  cmnPart.rxTransducerInd = buffer[index];
  index++;
  cmnPart.numRxTransducers = buffer[index];
  index++;
  cmnPart.algorithmType = buffer[index];
  index++;

  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr,"dbg5       numBytesCmnPart:     %d\n", cmnPart.numBytesCmnPart);
    fprintf(stderr,"dbg5       pingCnt:             %d\n", cmnPart.pingCnt);
    fprintf(stderr,"dbg5       rxFansPerPing:       %d\n", cmnPart.rxFansPerPing);
    fprintf(stderr,"dbg5       rxFanIndex:          %d\n", cmnPart.rxFanIndex);
    fprintf(stderr,"dbg5       swathsPerPing:       %d\n", cmnPart.swathsPerPing);
    fprintf(stderr,"dbg5       swathAlongPosition:  %d\n", cmnPart.swathAlongPosition);
    fprintf(stderr,"dbg5       txTransducerInd:     %d\n", cmnPart.txTransducerInd);
    fprintf(stderr,"dbg5       rxTransducerInd:     %d\n", cmnPart.rxTransducerInd);
    fprintf(stderr,"dbg5       numRxTransducers:    %d\n", cmnPart.numRxTransducers);
    fprintf(stderr,"dbg5       algorithmType:       %d\n", cmnPart.algorithmType);
  }

  /* now figure out which of the MRZ datagrams for this ping we are reading
    (cmnPart.rxFanIndex out of cmnPart.rxFansPerPing) */
  mrz = &store->mrz[cmnPart.rxFanIndex];
  mrz->header = *header;
  mrz->partition = partition;
  mrz->cmnPart = cmnPart;

  /* reset index to start of EMdgmMRZ_pingInfo using cmnPart.numBytesCmnPart
      - this avoids breaking the decoding if fields have been added to cmnPart */
  index_pingInfo = index_EMdgmMbody + cmnPart.numBytesCmnPart;
  index = index_pingInfo;

  /* EMdgmMRZ_pingInfo - ping info */
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.numBytesInfoData));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.padding0));
  index += 2;

  /* Ping info */
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.pingRate_Hz));
  index += 4;

  mrz->pingInfo.beamSpacing = buffer[index];
  index++;
  mrz->pingInfo.depthMode = buffer[index];
  index++;
  mrz->pingInfo.subDepthMode = buffer[index];
  index++;
  mrz->pingInfo.distanceBtwSwath = buffer[index];
  index++;
  mrz->pingInfo.detectionMode = buffer[index];
  index++;
  mrz->pingInfo.pulseForm = buffer[index];
  index++;

  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.padding1));
  index += 2;

  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.frequencyMode_Hz));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.freqRangeLowLim_Hz));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.freqRangeHighLim_Hz));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.maxTotalTxPulseLength_sec));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.maxEffTxPulseLength_sec));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.maxEffTxBandWidth_Hz));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.absCoeff_dBPerkm));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.portSectorEdge_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.starbSectorEdge_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.portMeanCov_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.starbMeanCov_deg));
  index += 4;

  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.portMeanCov_m));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.starbMeanCov_m));
  index += 2;

  mrz->pingInfo.modeAndStabilisation = buffer[index];
  index++;
  mrz->pingInfo.runtimeFilter1 = buffer[index];
  index++;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.runtimeFilter2));
  index += 2;
  mb_get_binary_int(MB_YES, &buffer[index], &(mrz->pingInfo.pipeTrackingStatus));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.transmitArraySizeUsed_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.receiveArraySizeUsed_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.transmitPower_dB));
  index += 4;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.SLrampUpTimeRemaining));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.padding2));
  index += 2;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.yawAngle_deg));
  index += 4;

  /* Info of tx sector data block, EMdgmMRZ_txSectorInfo */
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.numTxSectors));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->pingInfo.numBytesPerTxSector));
  index += 2;

  /* Info at time of midpoint of first tx pulse */
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.headingVessel_deg));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.soundSpeedAtTxDepth_mPerSec));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.txTransducerDepth_m));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.z_waterLevelReRefPoint_m));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.x_kmallToall_m));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.y_kmallToall_m));
  index += 4;

  mrz->pingInfo.latLongInfo = buffer[index];
  index++;
  mrz->pingInfo.posSensorStatus = buffer[index];
  index++;
  mrz->pingInfo.attitudeSensorStatus = buffer[index];
  index++;
  mrz->pingInfo.padding2 = buffer[index];
  index++;

  mb_get_binary_double(MB_YES, &buffer[index], &(mrz->pingInfo.latitude_deg));
  index += 8;
  mb_get_binary_double(MB_YES, &buffer[index], &(mrz->pingInfo.longitude_deg));
  index += 8;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->pingInfo.ellipsoidHeightReRefPoint_m));
  index += 4;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr,"dbg5       numBytesInfoData:             %d\n", mrz->pingInfo.numBytesInfoData);
    fprintf(stderr,"dbg5       padding0:                     %d\n", mrz->pingInfo.padding0);
    fprintf(stderr,"dbg5       pingRate_Hz:                  %f\n", mrz->pingInfo.pingRate_Hz);
    fprintf(stderr,"dbg5       beamSpacing:                  %d\n", mrz->pingInfo.beamSpacing);
    fprintf(stderr,"dbg5       depthMode:                    %d\n", mrz->pingInfo.depthMode);
    fprintf(stderr,"dbg5       subDepthMode:                 %d\n", mrz->pingInfo.subDepthMode);
    fprintf(stderr,"dbg5       distanceBtwSwath:             %d\n", mrz->pingInfo.distanceBtwSwath);
    fprintf(stderr,"dbg5       detectionMode:                %d\n", mrz->pingInfo.detectionMode);
    fprintf(stderr,"dbg5       pulseForm:                    %d\n", mrz->pingInfo.pulseForm);
    fprintf(stderr,"dbg5       padding1:                     %d\n", mrz->pingInfo.padding1);
    fprintf(stderr,"dbg5       frequencyMode_Hz:             %f\n", mrz->pingInfo.frequencyMode_Hz);
    fprintf(stderr,"dbg5       freqRangeLowLim_Hz:           %f\n", mrz->pingInfo.freqRangeLowLim_Hz);
    fprintf(stderr,"dbg5       freqRangeHighLim_Hz:          %f\n", mrz->pingInfo.freqRangeHighLim_Hz);
    fprintf(stderr,"dbg5       maxEffTxPulseLength_sec:      %f\n", mrz->pingInfo.maxEffTxPulseLength_sec);
    fprintf(stderr,"dbg5       maxTotalTxPulseLength_sec:    %f\n", mrz->pingInfo.maxTotalTxPulseLength_sec);
    fprintf(stderr,"dbg5       maxEffTxBandWidth_Hz:         %f\n", mrz->pingInfo.maxEffTxBandWidth_Hz);
    fprintf(stderr,"dbg5       absCoeff_dBPerkm:             %f\n", mrz->pingInfo.absCoeff_dBPerkm);
    fprintf(stderr,"dbg5       portSectorEdge_deg:           %f\n", mrz->pingInfo.portSectorEdge_deg);
    fprintf(stderr,"dbg5       starbSectorEdge_deg:          %f\n", mrz->pingInfo.starbSectorEdge_deg);
    fprintf(stderr,"dbg5       portMeanCov_m:                %d\n", mrz->pingInfo.portMeanCov_m);
    fprintf(stderr,"dbg5       starbMeanCov_m:               %d\n", mrz->pingInfo.starbMeanCov_m);
    fprintf(stderr,"dbg5       modeAndStabilisation:         %d\n", mrz->pingInfo.modeAndStabilisation);
    fprintf(stderr,"dbg5       runtimeFilter1:               %d\n", mrz->pingInfo.runtimeFilter1);
    fprintf(stderr,"dbg5       runtimeFilter2:               %d\n", mrz->pingInfo.runtimeFilter2);
    fprintf(stderr,"dbg5       pipeTrackingStatus:           %d\n", mrz->pingInfo.pipeTrackingStatus);
    fprintf(stderr,"dbg5       transmitArraySizeUsed_deg:    %f\n", mrz->pingInfo.transmitArraySizeUsed_deg);
    fprintf(stderr,"dbg5       receiveArraySizeUsed_deg:     %f\n", mrz->pingInfo.receiveArraySizeUsed_deg);
    fprintf(stderr,"dbg5       transmitPower_dB:             %f\n", mrz->pingInfo.transmitPower_dB);
    fprintf(stderr,"dbg5       SLrampUpTimeRemaining:        %d\n", mrz->pingInfo.SLrampUpTimeRemaining);
    fprintf(stderr,"dbg5       padding2:                     %d\n", mrz->pingInfo.padding2);
    fprintf(stderr,"dbg5       yawAngle_deg:                 %f\n", mrz->pingInfo.yawAngle_deg);
    fprintf(stderr,"dbg5       numTxSectors:                 %d\n", mrz->pingInfo.numTxSectors);
    fprintf(stderr,"dbg5       numBytesPerTxSector:          %d\n", mrz->pingInfo.numBytesPerTxSector);
    fprintf(stderr,"dbg5       headingVessel_deg:            %f\n", mrz->pingInfo.headingVessel_deg);
    fprintf(stderr,"dbg5       soundSpeedAtTxDepth_mPerSec:  %f\n", mrz->pingInfo.soundSpeedAtTxDepth_mPerSec);
    fprintf(stderr,"dbg5       txTransducerDepth_m:          %f\n", mrz->pingInfo.txTransducerDepth_m);
    fprintf(stderr,"dbg5       z_waterLevelReRefPoint_m:     %f\n", mrz->pingInfo.z_waterLevelReRefPoint_m);
    fprintf(stderr,"dbg5       x_kmallToall_m:               %f\n", mrz->pingInfo.x_kmallToall_m);
    fprintf(stderr,"dbg5       y_kmallToall_m:               %f\n", mrz->pingInfo.y_kmallToall_m);
    fprintf(stderr,"dbg5       latLongInfo:                  %d\n", mrz->pingInfo.latLongInfo);
    fprintf(stderr,"dbg5       posSensorStatus:              %d\n", mrz->pingInfo.posSensorStatus);
    fprintf(stderr,"dbg5       attitudeSensorStatus:         %d\n", mrz->pingInfo.attitudeSensorStatus);
    fprintf(stderr,"dbg5       padding3:                     %d\n", mrz->pingInfo.padding3);
    fprintf(stderr,"dbg5       latitude_deg:                 %f\n", mrz->pingInfo.latitude_deg);
    fprintf(stderr,"dbg5       longitude_deg:                %f\n", mrz->pingInfo.longitude_deg);
    fprintf(stderr,"dbg5       ellipsoidHeightReRefPoint_m:  %f\n", mrz->pingInfo.ellipsoidHeightReRefPoint_m);
  }

  /* calculate index at start of txSectorInfo structures using pingInfo.numBytesInfoData
      - this avoids breaking the decoding if fields have been added to pingInfo */
  index_txSectorInfo = index_pingInfo + mrz->pingInfo.numBytesInfoData;

  /* EMdgmMRZ_txSectorInfo - sector information */
  for (int i = 0; i<(mrz->pingInfo.numTxSectors); i++)
  {
  /* calculate index at start of of each txSectorInfo using pingInfo.numBytesPerTxSector
      - this avoids breaking the decoding if fields have been added to txSectorInfo */
    index = index_txSectorInfo + i * mrz->pingInfo.numBytesPerTxSector;

    mrz->sectorInfo[i].txSectorNumb = buffer[index];
    index++;
    mrz->sectorInfo[i].txArrNumber = buffer[index];
    index++;
    mrz->sectorInfo[i].txSubArray = buffer[index];
    index++;
    mrz->sectorInfo[i].padding0 = buffer[index];
    index++;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sectorInfo[i].sectorTransmitDelay_sec));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sectorInfo[i].tiltAngleReTx_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sectorInfo[i].txNominalSourceLevel_dB));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sectorInfo[i].txFocusRange_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sectorInfo[i].centreFreq_Hz));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sectorInfo[i].signalBandWidth_Hz));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sectorInfo[i].totalSignalLength_sec));
    index += 4;
    mrz->sectorInfo[i].pulseShading = buffer[index];
    index++;
    mrz->sectorInfo[i].signalWaveForm = buffer[index];
    index++;
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sectorInfo[i].padding1));
    index += 2;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       #MWC transmit sector %d/%d:\n", i + 1, mrz->pingInfo.numTxSectors);
      fprintf(stderr, "dbg5       txSectorNumb:             %d\n", mrz->sectorInfo[i].txSectorNumb);
      fprintf(stderr, "dbg5       txArrNumber:              %d\n", mrz->sectorInfo[i].txArrNumber);
      fprintf(stderr, "dbg5       txSubArray:               %d\n", mrz->sectorInfo[i].txSubArray);
      fprintf(stderr, "dbg5       padding0:                 %d\n", mrz->sectorInfo[i].padding0);
      fprintf(stderr, "dbg5       sectorTransmitDelay_sec:  %f\n", mrz->sectorInfo[i].sectorTransmitDelay_sec);
      fprintf(stderr, "dbg5       tiltAngleReTx_deg:        %f\n", mrz->sectorInfo[i].tiltAngleReTx_deg);
      fprintf(stderr, "dbg5       txNominalSourceLevel_dB:  %f\n", mrz->sectorInfo[i].txNominalSourceLevel_dB);
      fprintf(stderr, "dbg5       txFocusRange_m:           %f\n", mrz->sectorInfo[i].txFocusRange_m);
      fprintf(stderr, "dbg5       centreFreq_Hz:            %f\n", mrz->sectorInfo[i].centreFreq_Hz);
      fprintf(stderr, "dbg5       signalBandWidth_Hz:       %f\n", mrz->sectorInfo[i].signalBandWidth_Hz);
      fprintf(stderr, "dbg5       totalSignalLength_sec:    %f\n", mrz->sectorInfo[i].totalSignalLength_sec);
      fprintf(stderr, "dbg5       pulseShading:             %d\n", mrz->sectorInfo[i].pulseShading);
      fprintf(stderr, "dbg5       signalWaveForm:           %d\n", mrz->sectorInfo[i].signalWaveForm);
      fprintf(stderr, "dbg5       padding1:                 %d\n", mrz->sectorInfo[i].padding1);
    }
  }

  /* calculate index at start of rxInfo using pingInfo.numTxSectors & mrz->pingInfo.numBytesPerTxSector
      - this avoids breaking the decoding if fields have been added to txSectorInfo */
  index_rxInfo = index_txSectorInfo + mrz->pingInfo.numTxSectors * mrz->pingInfo.numBytesPerTxSector;
  index = index_rxInfo;

  /* EMdgmMRZ_rxInfo - receiver specific info */
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.numBytesRxInfo));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.numSoundingsMaxMain));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.numSoundingsValidMain));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.numBytesPerSounding));
  index += 2;

  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->rxInfo.WCSampleRate));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->rxInfo.seabedImageSampleRate));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->rxInfo.BSnormal_dB));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mrz->rxInfo.BSoblique_dB));
  index += 4;

  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.extraDetectionAlarmFlag));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.numExtraDetections));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.numExtraDetectionClasses));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mrz->rxInfo.numBytesPerClass));
  index += 2;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesInfoData:           %d\n", mrz->rxInfo.numBytesRxInfo);
    fprintf(stderr, "dbg5       numSoundingsMaxMain:        %d\n", mrz->rxInfo.numSoundingsMaxMain);
    fprintf(stderr, "dbg5       numSoundingsValidMain:      %d\n", mrz->rxInfo.numSoundingsValidMain);
    fprintf(stderr, "dbg5       numBytesPerSounding:        %d\n", mrz->rxInfo.numBytesPerSounding);
    fprintf(stderr, "dbg5       WCSampleRate:               %f\n", mrz->rxInfo.WCSampleRate);
    fprintf(stderr, "dbg5       seabedImageSampleRate:      %f\n", mrz->rxInfo.seabedImageSampleRate);
    fprintf(stderr, "dbg5       BSnormal_dB:                %f\n", mrz->rxInfo.BSnormal_dB);
    fprintf(stderr, "dbg5       BSoblique_dB:               %f\n", mrz->rxInfo.BSoblique_dB);
    fprintf(stderr, "dbg5       extraDetectionAlarmFlag:    %d\n", mrz->rxInfo.extraDetectionAlarmFlag);
    fprintf(stderr, "dbg5       numExtraDetections:         %d\n", mrz->rxInfo.numExtraDetections);
    fprintf(stderr, "dbg5       numExtraDetectionClasses:   %d\n", mrz->rxInfo.numExtraDetectionClasses);
    fprintf(stderr, "dbg5       numBytesPerClass:           %d\n", mrz->rxInfo.numBytesPerClass);
  }

  /* calculate index at start of rxInfo using rxInfo.numExtraDetectionClasses & rxInfo.numBytesPerClass
      - this avoids breaking the decoding if fields have been added to extraDetClassInfo */
  index_extraDetClassInfo = index_rxInfo + mrz->rxInfo.numBytesRxInfo;

  /* EMdgmMRZ_extraDetClassInfo -  Extra detection class info */
  for (int i = 0; i<(mrz->rxInfo.numExtraDetectionClasses); i++)
  {
  /* calculate index at start of of each extraDetClassInfo using pingInfo.numBytesPerTxSector
      - this avoids breaking the decoding if fields have been added to txSectorInfo */
    index = index_extraDetClassInfo + i * mrz->rxInfo.numBytesPerClass;

    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->extraDetClassInfo[i].numExtraDetInClass));
    index += 2;
    mrz->extraDetClassInfo[i].padding = buffer[index];
    index++;
    mrz->extraDetClassInfo[i].alarmFlag = buffer[index];
    index++;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numExtraDetInClass:  %d\n", mrz->extraDetClassInfo[i].numExtraDetInClass);
      fprintf(stderr, "dbg5       padding:             %d\n", mrz->extraDetClassInfo[i].padding);
      fprintf(stderr, "dbg5       alarmFlag:           %d\n", mrz->extraDetClassInfo[i].alarmFlag);
    }
  }

  /* calculate index at start of sounding using rxInfo.numExtraDetectionClasses & rxInfo.numBytesPerClass
      - this avoids breaking the decoding if fields have been added to extraDetClassInfo */
  index_sounding = index_extraDetClassInfo + mrz->rxInfo.numExtraDetectionClasses * mrz->rxInfo.numBytesPerClass;

  /* EMdgmMRZ_sounding - Data for each sounding */
  int numSidescanSamples = 0;
  int numSoundings = mrz->rxInfo.numSoundingsMaxMain + mrz->rxInfo.numExtraDetections;
  for (int i = 0; i<numSoundings; i++)
  {
  /* calculate index at start of of each sounding using pingInfo.numBytesPerTxSector
      - this avoids breaking the decoding if fields have been added to sounding */
    index = index_sounding + i * mrz->rxInfo.numBytesPerSounding;

    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].soundingIndex));
    index += 2;
    mrz->sounding[i].txSectorNumb = buffer[index];
    index++;

    /* Detection info. */
    mrz->sounding[i].detectionType = buffer[index];
    index++;
    mrz->sounding[i].detectionMethod = buffer[index];
    index++;
    mrz->sounding[i].rejectionInfo1 = buffer[index];
    index++;
    mrz->sounding[i].rejectionInfo2 = buffer[index];
    index++;
    mrz->sounding[i].postProcessingInfo = buffer[index];
    index++;
    mrz->sounding[i].detectionClass = buffer[index];
    index++;
    mrz->sounding[i].detectionConfidenceLevel = buffer[index];
    index++;
    /* These two bytes specified as padding in the Kongsberg specification but are
       here used for the MB-System beam flag - if the first mb_u_char == 1 then the
       second byte is an MB-System beamflag */
    // mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].padding));
    // index += 2;
    mrz->sounding[i].beamflag_enabled = buffer[index];
    index++;
    mrz->sounding[i].beamflag = buffer[index];
    index++;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].rangeFactor));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].qualityFactor));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].detectionUncertaintyVer_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].detectionUncertaintyHor_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].detectionWindowLength_sec));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].echoLength_sec));
    index += 4;

    /* Water column paramters. */
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].WCBeamNumb));
    index += 2;
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].WCrange_samples));
    index += 2;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].WCNomBeamAngleAcross_deg));
    index += 4;

    /* Reflectivity data (backscatter (BS) data). */
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].meanAbsCoeff_dBPerkm));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].reflectivity1_dB));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].reflectivity2_dB));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].receiverSensitivityApplied_dB));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].sourceLevelApplied_dB));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].BScalibration_dB));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].TVG_dB));
    index += 4;

    /* Range and angle data. */
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].beamAngleReRx_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].beamAngleCorrection_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].twoWayTravelTime_sec));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].twoWayTravelTimeCorrection_sec));
    index += 4;

    /* Georeferenced depth points. */
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].deltaLatitude_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].deltaLongitude_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].z_reRefPoint_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].y_reRefPoint_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].x_reRefPoint_m));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mrz->sounding[i].beamIncAngleAdj_deg));
    index += 4;
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].realTimeCleanInfo));
    index += 2;

    /* Seabed image. */
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].SIstartRange_samples));
    index += 2;
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].SIcentreSample));
    index += 2;
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->sounding[i].SInumSamples));
    index += 2;

    numSidescanSamples += mrz->sounding[i].SInumSamples;

    /* calculate beamflag */
    if (mrz->sounding[i].beamflag_enabled != 1) {
      if (mrz->sounding[i].detectionType >= 2) {
        mrz->sounding[i].beamflag = MB_FLAG_NULL;
      }
      else if (mrz->sounding[i].detectionType == 1) {
        mrz->sounding[i].beamflag = (char)(MB_FLAG_FLAG + MB_FLAG_SONAR);
      }
      else if (mrz->sounding[i].qualityFactor > MBSYS_KMBES_QUAL_FACTOR_THRESHOLD) {
          mrz->sounding[i].beamflag = (char)(MB_FLAG_FLAG + MB_FLAG_SONAR);
      }
      else {
          mrz->sounding[i].beamflag = MB_FLAG_NONE;
      }
      mrz->sounding[i].beamflag_enabled = 1;
    }

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       soundingIndex:                   %d\n", mrz->sounding[i].soundingIndex);
      fprintf(stderr, "dbg5       txSectorNumb:                    %d\n", mrz->sounding[i].txSectorNumb);
      fprintf(stderr, "dbg5       detectionType:                   %d\n", mrz->sounding[i].detectionType);
      fprintf(stderr, "dbg5       detectionMethod:                 %d\n", mrz->sounding[i].detectionMethod);
      fprintf(stderr, "dbg5       rejectionInfo1:                  %d\n", mrz->sounding[i].rejectionInfo1);
      fprintf(stderr, "dbg5       rejectionInfo2:                  %d\n", mrz->sounding[i].rejectionInfo2);
      fprintf(stderr, "dbg5       postProcessingInfo:              %d\n", mrz->sounding[i].postProcessingInfo);
      fprintf(stderr, "dbg5       detectionClass:                  %d\n", mrz->sounding[i].detectionClass);
      fprintf(stderr, "dbg5       detectionConfidenceLevel:        %d\n", mrz->sounding[i].detectionConfidenceLevel);
      // fprintf(stderr, "dbg5       padding:                        %d\n", mrz->sounding[i].padding);
      fprintf(stderr, "dbg5       beamflag_enabled:                %d\n", mrz->sounding[i].beamflag_enabled);
      fprintf(stderr, "dbg5       beamflag:                        %d\n", mrz->sounding[i].beamflag);
      fprintf(stderr, "dbg5       rangeFactor:                     %f\n", mrz->sounding[i].rangeFactor);
      fprintf(stderr, "dbg5       qualityFactor:                   %f\n", mrz->sounding[i].qualityFactor);
      fprintf(stderr, "dbg5       detectionUncertaintyVer_m:       %f\n", mrz->sounding[i].detectionUncertaintyVer_m);
      fprintf(stderr, "dbg5       detectionUncertaintyHor_m:       %f\n", mrz->sounding[i].detectionUncertaintyHor_m);
      fprintf(stderr, "dbg5       detectionWindowLength_sec:       %f\n", mrz->sounding[i].detectionWindowLength_sec);
      fprintf(stderr, "dbg5       echoLength_sec:                  %f\n", mrz->sounding[i].echoLength_sec);
      fprintf(stderr, "dbg5       WCBeamNumb:                      %d\n", mrz->sounding[i].WCBeamNumb);
      fprintf(stderr, "dbg5       WCrange_samples:                 %d\n", mrz->sounding[i].WCrange_samples);
      fprintf(stderr, "dbg5       WCNomBeamAngleAcross_deg:        %f\n", mrz->sounding[i].WCNomBeamAngleAcross_deg);
      fprintf(stderr, "dbg5       meanAbsCoeff_dBPerkm:            %f\n", mrz->sounding[i].meanAbsCoeff_dBPerkm);
      fprintf(stderr, "dbg5       reflectivity1_dB:                %f\n", mrz->sounding[i].reflectivity1_dB);
      fprintf(stderr, "dbg5       reflectivity2_dB:                %f\n", mrz->sounding[i].reflectivity2_dB);
      fprintf(stderr, "dbg5       receiverSensitivityApplied_dB:   %f\n", mrz->sounding[i].receiverSensitivityApplied_dB);
      fprintf(stderr, "dbg5       sourceLevelApplied_dB:           %f\n", mrz->sounding[i].sourceLevelApplied_dB);
      fprintf(stderr, "dbg5       BScalibration_dB:                %f\n", mrz->sounding[i].BScalibration_dB);
      fprintf(stderr, "dbg5       TVG_dB:                          %f\n", mrz->sounding[i].TVG_dB);
      fprintf(stderr, "dbg5       beamAngleReRx_deg:               %f\n", mrz->sounding[i].beamAngleReRx_deg);
      fprintf(stderr, "dbg5       beamAngleCorrection_deg:         %f\n", mrz->sounding[i].beamAngleCorrection_deg);
      fprintf(stderr, "dbg5       twoWayTravelTime_sec:            %f\n", mrz->sounding[i].twoWayTravelTime_sec);
      fprintf(stderr, "dbg5       twoWayTravelTimeCorrection_sec:  %f\n", mrz->sounding[i].twoWayTravelTimeCorrection_sec);
      fprintf(stderr, "dbg5       deltaLatitude_deg:               %f\n", mrz->sounding[i].deltaLatitude_deg);
      fprintf(stderr, "dbg5       deltaLongitude_deg:              %f\n", mrz->sounding[i].deltaLongitude_deg);
      fprintf(stderr, "dbg5       z_reRefPoint_m:                  %f\n", mrz->sounding[i].z_reRefPoint_m);
      fprintf(stderr, "dbg5       y_reRefPoint_m:                  %f\n", mrz->sounding[i].y_reRefPoint_m);
      fprintf(stderr, "dbg5       x_reRefPoint_m:                  %f\n", mrz->sounding[i].x_reRefPoint_m);
      fprintf(stderr, "dbg5       beamIncAngleAdj_deg:             %f\n", mrz->sounding[i].beamIncAngleAdj_deg);
      fprintf(stderr, "dbg5       realTimeCleanInfo:               %d\n", mrz->sounding[i].realTimeCleanInfo);
      fprintf(stderr, "dbg5       SIstartRange_samples:            %d\n", mrz->sounding[i].SIstartRange_samples);
      fprintf(stderr, "dbg5       SIcentreSample:                  %d\n", mrz->sounding[i].SIcentreSample);
      fprintf(stderr, "dbg5       SInumSamples:                    %d\n", mrz->sounding[i].SInumSamples);
    }
  }

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numSidescanSamples:  %d\n", numSidescanSamples);
  }

  /* calculate index at start of SIsample_desidB using numSoundings and mrz->rxInfo.numBytesPerSounding
      - this avoids breaking the decoding if fields have been added to sounding */
  index_SIsample = index_sounding + numSoundings * mrz->rxInfo.numBytesPerSounding;
  index = index_SIsample;

  for (int i = 0; i<numSidescanSamples; i++)
  {
    mb_get_binary_short(MB_YES, &buffer[index], &(mrz->SIsample_desidB[i]));
    index += 2;
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_DATA;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - index:%d time: %d.%9.9d ping:%d rx:%d/%d xms expected:%d status:%d error:%d\n",
          header->dgmType, index, header->time_sec, header->time_nanosec, cmnPart.pingCnt, cmnPart.rxFanIndex, cmnPart.rxFansPerPing,
          store->xmb.pseudosidescan_enabled, status, *error);
#endif

  /* return status */
  return (status);
}

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_mwc(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_mwc";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_mwc *mwc = NULL;
  struct mbsys_kmbes_m_partition partition;
  struct mbsys_kmbes_m_body cmnPart;
  size_t alloc_size = 0;
  int index = 0;
  int i, j, k;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;

  /* get the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  /* EMdgmMpartition - data partition information */
  mb_get_binary_short(MB_YES, &buffer[index], &(partition.numOfDgms));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(partition.dgmNum));
  index += 2;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numOfDgms:  %d\n", partition.numOfDgms);
    fprintf(stderr, "dbg5       dgmNum:     %d\n", partition.dgmNum);
  }

  /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
  mb_get_binary_short(MB_YES, &buffer[index], &(cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(cmnPart.pingCnt));
  index += 2;
  cmnPart.rxFansPerPing = buffer[index];
  index++;
  cmnPart.rxFanIndex = buffer[index];
  index++;
  cmnPart.swathsPerPing = buffer[index];
  index++;
  cmnPart.swathAlongPosition = buffer[index];
  index++;
  cmnPart.txTransducerInd = buffer[index];
  index++;
  cmnPart.rxTransducerInd = buffer[index];
  index++;
  cmnPart.numRxTransducers = buffer[index];
  index++;
  cmnPart.algorithmType = buffer[index];
  index++;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesCmnPart:     %d\n", cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       pingCnt:             %d\n", cmnPart.pingCnt);
    fprintf(stderr, "dbg5       rxFansPerPing:       %d\n", cmnPart.rxFansPerPing);
    fprintf(stderr, "dbg5       rxFanIndex:          %d\n", cmnPart.rxFanIndex);
    fprintf(stderr, "dbg5       swathsPerPing:       %d\n", cmnPart.swathsPerPing);
    fprintf(stderr, "dbg5       swathAlongPosition:  %d\n", cmnPart.swathAlongPosition);
    fprintf(stderr, "dbg5       txTransducerInd:     %d\n", cmnPart.txTransducerInd);
    fprintf(stderr, "dbg5       rxTransducerInd:     %d\n", cmnPart.rxTransducerInd);
    fprintf(stderr, "dbg5       numRxTransducers:    %d\n", cmnPart.numRxTransducers);
    fprintf(stderr, "dbg5       algorithmType:       %d\n", cmnPart.algorithmType);
  }

  /* now figure out which of the MWC datagrams for this ping we are reading
    (cmnPart.rxFanIndex out of cmnPart.rxFansPerPing) */
  mwc = &store->mwc[cmnPart.rxFanIndex];
  mwc->header = *header;
  mwc->partition = partition;
  mwc->cmnPart = cmnPart;

  /* EMdgmMWCtxInfo - transmit sectors, general info for all sectors */
  mb_get_binary_short(MB_YES, &buffer[index], &(mwc->txInfo.numBytesTxInfo));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mwc->txInfo.numTxSectors));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mwc->txInfo.numBytesPerTxSector));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mwc->txInfo.padding));
  index += 2;
  mb_get_binary_float(MB_YES, &buffer[index], &(mwc->txInfo.heave_m));
  index += 4;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesTxInfo:       %d\n", mwc->txInfo.numBytesTxInfo);
    fprintf(stderr, "dbg5       numTxSectors:         %d\n", mwc->txInfo.numTxSectors);
    fprintf(stderr, "dbg5       numBytesPerTxSector:  %d\n", mwc->txInfo.numBytesPerTxSector);
    fprintf(stderr, "dbg5       padding:              %d\n", mwc->txInfo.padding);
    fprintf(stderr, "dbg5       heave_m:              %f\n", mwc->txInfo.heave_m);
  }

  /* EMdgmMWCtxSectorData - transmit sector data, loop for all i = numTxSectors */
  for (i=0; i<(mwc->txInfo.numTxSectors); i++) {
    mb_get_binary_float(MB_YES, &buffer[index], &(mwc->sectorData[i].tiltAngleReTx_deg));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mwc->sectorData[i].centreFreq_Hz));
    index += 4;
    mb_get_binary_float(MB_YES, &buffer[index], &(mwc->sectorData[i].txBeamWidthAlong_deg));
    index += 4;
    mb_get_binary_short(MB_YES, &buffer[index], &(mwc->sectorData[i].txSectorNum));
    index += 2;
    mb_get_binary_short(MB_YES, &buffer[index], &(mwc->sectorData[i].padding));
    index += 2;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       #MWC transmit sector %d/%d:\n", i + 1, mwc->txInfo.numTxSectors);
      fprintf(stderr, "dbg5       tiltAngleReTx_deg:     %f\n", mwc->sectorData[i].tiltAngleReTx_deg);
      fprintf(stderr, "dbg5       centreFreq_Hz:         %f\n", mwc->sectorData[i].centreFreq_Hz);
      fprintf(stderr, "dbg5       txBeamWidthAlong_deg:  %f\n", mwc->sectorData[i].txBeamWidthAlong_deg);
      fprintf(stderr, "dbg5       txSectorNum:           %d\n", mwc->sectorData[i].txSectorNum);
      fprintf(stderr, "dbg5       padding:               %d\n", mwc->sectorData[i].padding);
    }
  }

  /* EMdgmMWCrxInfo - receiver, general info */
  mb_get_binary_short(MB_YES, &buffer[index], &(mwc->rxInfo.numBytesRxInfo));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(mwc->rxInfo.numBeams));
  index += 2;
  mwc->rxInfo.numBytesPerBeamEntry = buffer[index];
  index ++;
  mwc->rxInfo.phaseFlag = buffer[index];
  index ++;
  mwc->rxInfo.TVGfunctionApplied = buffer[index];
  index ++;
  mwc->rxInfo.TVGoffset_dB = buffer[index];
  index ++;
  mb_get_binary_float(MB_YES, &buffer[index], &(mwc->rxInfo.sampleFreq_Hz));
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &(mwc->rxInfo.soundVelocity_mPerSec));
  index += 4;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesRxInfo:         %d\n", mwc->rxInfo.numBytesRxInfo);
    fprintf(stderr, "dbg5       numBeams:               %d\n", mwc->rxInfo.numBeams);
    fprintf(stderr, "dbg5       numBytesPerBeamEntry:   %d\n", mwc->rxInfo.numBytesPerBeamEntry);
    fprintf(stderr, "dbg5       phaseFlag:              %d\n", mwc->rxInfo.phaseFlag);
    fprintf(stderr, "dbg5       TVGfunctionApplied:     %d\n", mwc->rxInfo.TVGfunctionApplied);
    fprintf(stderr, "dbg5       TVGoffset_dB:           %d\n", mwc->rxInfo.TVGoffset_dB);
    fprintf(stderr, "dbg5       sampleFreq_Hz:          %f\n", mwc->rxInfo.sampleFreq_Hz);
    fprintf(stderr, "dbg5       soundVelocity_mPerSec:  %f\n", mwc->rxInfo.soundVelocity_mPerSec);
  }

  /* EMdgmMWCrxBeamData - receiver, specific info for each beam */
  alloc_size = (size_t)(mwc->rxInfo.numBeams * sizeof(struct mbsys_kmbes_mwc_rx_beam_data));
  if (mwc->beamData_p_alloc_size < alloc_size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, alloc_size, (void **)&(mwc->beamData_p), error);
    if (status == MB_SUCCESS) {
      mwc->beamData_p_alloc_size = alloc_size;
      memset(mwc->beamData_p, 0, alloc_size);
    } else {
      mwc->beamData_p_alloc_size = 0;
    }
  }

  if (status == MB_SUCCESS) {
    for (i=0; i<(mwc->rxInfo.numBeams) && status == MB_SUCCESS; i++) {
      mb_get_binary_float(MB_YES, &buffer[index], &(mwc->beamData_p[i].beamPointAngReVertical_deg));
      index += 4;
      mb_get_binary_short(MB_YES, &buffer[index], &(mwc->beamData_p[i].startRangeSampleNum));
      index += 2;
      mb_get_binary_short(MB_YES, &buffer[index], &(mwc->beamData_p[i].detectedRangeInSamples));
      index += 2;
      mb_get_binary_short(MB_YES, &buffer[index], &(mwc->beamData_p[i].beamTxSectorNum));
      index += 2;
      mb_get_binary_short(MB_YES, &buffer[index], &(mwc->beamData_p[i].numSampleData));
      index += 2;

      /* Allocate sample amplitude array. Sample amplitudes are in 0.5 dB resolution */
      alloc_size = (size_t)(mwc->beamData_p[i].numSampleData);
      if (mwc->beamData_p[i].sampleAmplitude05dB_p_alloc_size < alloc_size) {
        alloc_size = (1 + (int)(alloc_size / 1024)) * 1024;
        status = mb_reallocd(verbose, __FILE__, __LINE__, alloc_size,
                            (void **)&(mwc->beamData_p[i].sampleAmplitude05dB_p), error);
        if (status == MB_SUCCESS) {
          mwc->beamData_p[i].sampleAmplitude05dB_p_alloc_size = alloc_size;
        } else {
          mwc->beamData_p[i].sampleAmplitude05dB_p_alloc_size = 0;
        }
      }

      /* Now get the amplitude samples */
      if (status == MB_SUCCESS) {
        memcpy(mwc->beamData_p[i].sampleAmplitude05dB_p, &buffer[index], mwc->beamData_p[i].numSampleData);
        index += mwc->beamData_p[i].numSampleData;

        /* Allocate for and get phase data, if available, according to mwc->rxInfo.phaseFlag */
        switch (mwc->rxInfo.phaseFlag) {
          /* no phase data included */
          case 0:
            break;

          /* 8-bit phase data */
          case 1:
            /* Rx beam phase in 180/128 degree resolution. */
            alloc_size = (size_t)(mwc->beamData_p[i].numSampleData);
            if (mwc->beamData_p[i].samplePhase8bit_alloc_size < alloc_size) {
              alloc_size = (1 + (int)(alloc_size / 1024)) * 1024;
              status = mb_reallocd(verbose, __FILE__, __LINE__, alloc_size,
                                  (void **)&(mwc->beamData_p[i].samplePhase8bit), error);
              if (status == MB_SUCCESS)
                mwc->beamData_p[i].samplePhase8bit_alloc_size = alloc_size;
              else
                mwc->beamData_p[i].samplePhase8bit_alloc_size = 0;
            }
            if (status == MB_SUCCESS) {
              memcpy(mwc->beamData_p[i].samplePhase8bit, &buffer[index], mwc->beamData_p[i].numSampleData);
              index += mwc->beamData_p[i].numSampleData;
            }
            break;

          /* 16 bit phase data */
          case 2:
            /* Rx beam phase in 0.01 degree resolution */
            alloc_size = (size_t)(2 * mwc->beamData_p[i].numSampleData);
            if (mwc->beamData_p[i].samplePhase16bit_alloc_size < alloc_size) {
              alloc_size = (1 + (int)(alloc_size / 1024)) * 1024;
              status = mb_reallocd(verbose, __FILE__, __LINE__, alloc_size,
                                  (void **)&(mwc->beamData_p[i].samplePhase16bit), error);
              if (status == MB_SUCCESS)
                mwc->beamData_p[i].samplePhase16bit_alloc_size = alloc_size;
              else
                mwc->beamData_p[i].samplePhase16bit_alloc_size = 0;
            }
            if (status == MB_SUCCESS) {
              for (k=0;k<mwc->beamData_p[i].numSampleData;k++) {
                mb_get_binary_short(MB_YES, &buffer[index], &(mwc->beamData_p[i].samplePhase16bit[k]));
                index += 2;
              }
            }
            break;
        }

        /* print debug statements */
        if (status == MB_SUCCESS && verbose >= 5) {
          fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
          fprintf(stderr, "dbg5       #MWC receiver beam data %d/%d:\n", i, mwc->rxInfo.numBeams);
          fprintf(stderr, "dbg5       tiltAngleReTx_deg:       %f\n", mwc->beamData_p[i].beamPointAngReVertical_deg);
          fprintf(stderr, "dbg5       startRangeSampleNum:     %d\n", mwc->beamData_p[i].startRangeSampleNum);
          fprintf(stderr, "dbg5       detectedRangeInSamples:  %d\n", mwc->beamData_p[i].detectedRangeInSamples);
          fprintf(stderr, "dbg5       beamTxSectorNum:         %d\n", mwc->beamData_p[i].beamTxSectorNum);
          fprintf(stderr, "dbg5       numSampleData:           %d\n", mwc->beamData_p[i].numSampleData);
          fprintf(stderr, "dbg5       (amplitude phase):       [\n");
          for (k = 0; k < (mwc->beamData_p[i].numSampleData); k++) {
            if (k % 10 == 0)
              fprintf(stderr, "dbg5             ");
            if (mwc->rxInfo.phaseFlag == 1)
              fprintf(stderr, " (%d %d),", mwc->beamData_p[i].sampleAmplitude05dB_p[k], mwc->beamData_p[i].samplePhase8bit[k]);
            else if (mwc->rxInfo.phaseFlag == 2)
              fprintf(stderr, " (%d %d),", mwc->beamData_p[i].sampleAmplitude05dB_p[k], mwc->beamData_p[i].samplePhase16bit[k]);
            else
              fprintf(stderr, " (%d),", mwc->beamData_p[i].sampleAmplitude05dB_p[k]);
            if ((k+1) % 10 == 0)
              fprintf(stderr, "\n");
          }
        }
      }
    }
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_WATER_COLUMN;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);

}

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_cpo(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_cpo";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_cpo *cpo = NULL;
  size_t numBytesRawSensorData = 0;
  int index = 0;


  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  cpo = &(store->cpo);

  /* copy the header */
  cpo->header = *header;

  /* calc number of bytes for raw sensor data */
  numBytesRawSensorData = cpo->header.numBytesDgm - MBSYS_KMBES_CPO_VAR_OFFSET;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  // common part
  mb_get_binary_short(MB_YES, &buffer[index], &(cpo->cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(cpo->cmnPart.sensorSystem));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(cpo->cmnPart.sensorStatus));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(cpo->cmnPart.padding));
  index += 2;

  // sensor data block
  mb_get_binary_int(MB_YES, &buffer[index], &cpo->sensorData.timeFromSensor_sec);
  index += 4;
  mb_get_binary_int(MB_YES, &buffer[index], &cpo->sensorData.timeFromSensor_nanosec);
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &cpo->sensorData.posFixQuality_m);
  index += 4;
  mb_get_binary_double(MB_YES, &buffer[index], &cpo->sensorData.correctedLat_deg);
  index += 8;
  mb_get_binary_double(MB_YES, &buffer[index], &cpo->sensorData.correctedLong_deg);
  index += 8;
  mb_get_binary_float(MB_YES, &buffer[index], &cpo->sensorData.speedOverGround_mPerSec);
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &cpo->sensorData.courseOverGround_deg);
  index += 4;
  mb_get_binary_float(MB_YES, &buffer[index], &cpo->sensorData.ellipsoidHeightReRefPoint_m);
  index += 4;
  memcpy(&cpo->sensorData.posDataFromSensor, &buffer[index], numBytesRawSensorData);
  index += numBytesRawSensorData;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:                  %u\n", cpo->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                      %s\n", cpo->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:                   %u\n", cpo->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                     %u\n", cpo->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:                %u\n", cpo->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                     %u\n", cpo->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:                 %u\n", cpo->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:              %u\n", cpo->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:                 %u\n", cpo->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:                 %u\n", cpo->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:                      %u\n", cpo->cmnPart.padding);

    fprintf(stderr, "dbg5       timeFromSensor_sec:           %u\n", cpo->sensorData.timeFromSensor_sec);
    fprintf(stderr, "dbg5       timeFromSensor_nanosec:       %u\n", cpo->sensorData.timeFromSensor_nanosec);
    fprintf(stderr, "dbg5       posFixQuality_m:              %f\n", cpo->sensorData.posFixQuality_m);
    fprintf(stderr, "dbg5       correctedLat_deg:             %f\n", cpo->sensorData.correctedLat_deg);
    fprintf(stderr, "dbg5       correctedLong_deg:            %f\n", cpo->sensorData.correctedLong_deg);
    fprintf(stderr, "dbg5       speedOverGround_mPerSec:      %f\n", cpo->sensorData.speedOverGround_mPerSec);
    fprintf(stderr, "dbg5       courseOverGround_deg:         %f\n", cpo->sensorData.courseOverGround_deg);
    fprintf(stderr, "dbg5       ellipsoidHeightReRefPoint_m:  %f\n", cpo->sensorData.ellipsoidHeightReRefPoint_m);
    fprintf(stderr, "dbg5       posDataFromSensor:            %s\n", cpo->sensorData.posDataFromSensor);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_NAV2;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_che(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_che";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_che *che = NULL;
  int index = 0;


  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  che = &(store->che);

  /* copy the header */
  che->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;


  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", che->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %s\n", che->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", che->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", che->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", che->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", che->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", che->header.time_nanosec);
  }

  /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
  mb_get_binary_short(MB_YES, &buffer[index], &(che->cmnPart.numBytesCmnPart));
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &(che->cmnPart.pingCnt));
  index += 2;
  che->cmnPart.rxFansPerPing = buffer[index];
  index++;
  che->cmnPart.rxFanIndex = buffer[index];
  index++;
  che->cmnPart.swathsPerPing = buffer[index];
  index++;
  che->cmnPart.swathAlongPosition = buffer[index];
  index++;
  che->cmnPart.txTransducerInd = buffer[index];
  index++;
  che->cmnPart.rxTransducerInd = buffer[index];
  index++;
  che->cmnPart.numRxTransducers = buffer[index];
  index++;
  che->cmnPart.algorithmType = buffer[index];
  index++;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesCmnPart:      %d\n", che->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       pingCnt:              %d\n", che->cmnPart.pingCnt);
    fprintf(stderr, "dbg5       rxFansPerPing:        %d\n", che->cmnPart.rxFansPerPing);
    fprintf(stderr, "dbg5       rxFanIndex:           %d\n", che->cmnPart.rxFanIndex);
    fprintf(stderr, "dbg5       swathsPerPing:        %d\n", che->cmnPart.swathsPerPing);
    fprintf(stderr, "dbg5       swathAlongPosition:   %d\n", che->cmnPart.swathAlongPosition);
    fprintf(stderr, "dbg5       txTransducerInd:      %d\n", che->cmnPart.txTransducerInd);
    fprintf(stderr, "dbg5       rxTransducerInd:      %d\n", che->cmnPart.rxTransducerInd);
    fprintf(stderr, "dbg5       numRxTransducers:     %d\n", che->cmnPart.numRxTransducers);
    fprintf(stderr, "dbg5       algorithmType:        %d\n", che->cmnPart.algorithmType);
  }

  mb_get_binary_float(MB_YES, &buffer[index], &che->data.heave_m);
  index += 4;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       heave_m                         = %f\n", che->data.heave_m);
  }


  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_HEAVE;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_iip(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_iip";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_iip *iip = NULL;
  size_t numBytesRawSensorData = 0;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  iip = &(store->iip);

  /* copy the header */
  iip->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  mb_get_binary_short(MB_YES, &buffer[index], &iip->numBytesCmnPart);
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &iip->info);
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &iip->status);
  index += 2;
  numBytesRawSensorData = iip->header.numBytesDgm - MBSYS_KMBES_IIP_VAR_OFFSET;
  memcpy(&iip->install_txt, &buffer[index], numBytesRawSensorData);
//fprintf(stderr, "\niip->install_txt:\n%s\n", iip->install_txt);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:      %u\n", iip->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:          %s\n", iip->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:       %u\n", iip->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:         %u\n", iip->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:    %u\n", iip->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:         %u\n", iip->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:     %u\n", iip->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", iip->numBytesCmnPart);
    fprintf(stderr, "dbg5       info:             %u\n", iip->info);
    fprintf(stderr, "dbg5       status:           %u\n", iip->status);
    fprintf(stderr, "dbg5       install_txt:      %s\n", iip->install_txt);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_INSTALLATION;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_iop(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error){
  char *function_name = "mbr_kemkmall_rd_iop";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_iop *iop = NULL;
  size_t numBytesRawSensorData = 0;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  iop = &(store->iop);

  /* copy the header */
  iop->header = *header;

  numBytesRawSensorData = iop->header.numBytesDgm - MBSYS_KMBES_IOP_VAR_OFFSET;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  mb_get_binary_short(MB_YES, &buffer[index], &iop->numBytesCmnPart);
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &iop->info);
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &iop->status);
  index += 2;
  memcpy(&iop->runtime_txt, &buffer[index], numBytesRawSensorData);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:                %u\n", iop->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                    %s\n", iop->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:                 %u\n", iop->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                   %u\n", iop->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:              %u\n", iop->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                   %u\n", iop->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:               %u\n", iop->header.time_nanosec);

    fprintf(stderr, "dbg5       iop->iop->numBytesCmnPart:  %u\n", iop->numBytesCmnPart);
    fprintf(stderr, "dbg5       iop->info:                  %u\n", iop->info);
    fprintf(stderr, "dbg5       iop->status:                %u\n", iop->status);
    fprintf(stderr, "dbg5       iop->runtime_txt:           %s\n", iop->runtime_txt);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_RUN_PARAMETER; // TODO: check data kind
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_xmb(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_xmb";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_xmb *xmb = NULL;
  size_t numBytesVersion = 0;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  xmb = &(store->xmb);

  /* copy the header */
  xmb->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  mb_get_binary_int(MB_YES, &buffer[index], &xmb->pseudosidescan_enabled);
  index += 4;
  for (i=0;i<28;i++) {
    xmb->unused[i] = buffer[index];
    index++;
  }
  numBytesVersion = xmb->header.numBytesDgm - MBSYS_KMBES_HEADER_SIZE - 36;
  memcpy(xmb->version, &buffer[index], numBytesVersion);
  index += numBytesVersion;
  memset(&xmb->version[numBytesVersion], 0, MB_COMMENT_MAXLINE - numBytesVersion);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", xmb->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %s\n", xmb->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", xmb->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", xmb->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", xmb->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", xmb->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", xmb->header.time_nanosec);

    fprintf(stderr, "dbg5       pseudosidescan_enabled:  %d\n", xmb->pseudosidescan_enabled);
    for (i=0;i<28;i++)
      fprintf(stderr, "dbg5       unused[%2d]:    %u\n", i, xmb->unused[i]);
    fprintf(stderr, "dbg5       version:        %s\n", xmb->version);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_MBSYSTEM;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_xmc(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_xmc";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_xmc *xmc = NULL;
  size_t numBytesComment = 0;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  xmc = &(store->xmc);

  /* copy the header */
  xmc->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  for (i=0;i<32;i++) {
    xmc->unused[i] = buffer[index];
    index++;
  }
  numBytesComment = xmc->header.numBytesDgm - MBSYS_KMBES_HEADER_SIZE - 36;
  memcpy(xmc->comment, &buffer[index], numBytesComment);
  index += numBytesComment;
  memset(&xmc->comment[numBytesComment], 0, MB_COMMENT_MAXLINE - numBytesComment);

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", xmc->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %s\n", xmc->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", xmc->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", xmc->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", xmc->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", xmc->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", xmc->header.time_nanosec);

    for (i=0;i<32;i++)
      fprintf(stderr, "dbg5       xmc->unused[%2d]:                        %u\n", i, xmc->unused[i]);
    fprintf(stderr, "dbg5       xmc->comment:                           %s\n", xmc->comment);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_COMMENT;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_xms(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_xms";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;
  struct mbsys_kmbes_xms *xms = NULL;
  size_t numBytes = 0;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;
  xms = &(store->xms);

  /* copy the header */
  xms->header = *header;

  /* extract the data */
  index = MBSYS_KMBES_HEADER_SIZE;

  mb_get_binary_short(MB_YES, &buffer[index], &xms->pingCnt);
  index += 2;
  mb_get_binary_short(MB_YES, &buffer[index], &xms->spare);
  index += 2;
  mb_get_binary_float(MB_YES, &buffer[index], &xms->pixel_size);
  index += 4;
  mb_get_binary_int(MB_YES, &buffer[index], &xms->pixels_ss);
  index += 4;
  for (i=0;i<32;i++) {
    xms->unused[i] = buffer[index];
    index++;
  }
  for (i=0;i<xms->pixels_ss;i++) {
    mb_get_binary_float(MB_YES, &buffer[index], &xms->ss[i]);
    index += 4;
  }
  for (i=0;i<xms->pixels_ss;i++) {
    mb_get_binary_float(MB_YES, &buffer[index], &xms->ss_alongtrack[i]);
    index += 4;
  }

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values read in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", xms->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %s\n", xms->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", xms->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", xms->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", xms->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", xms->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", xms->header.time_nanosec);

    fprintf(stderr, "dbg5       pingCnt:        %u\n", xms->pingCnt);
    fprintf(stderr, "dbg5       spare:          %d\n", xms->spare);
    fprintf(stderr, "dbg5       pixel_size:     %f\n", xms->pixel_size);
    fprintf(stderr, "dbg5       pixels_ss:      %d\n", xms->pixels_ss);
    for (i=0;i<32;i++)
      fprintf(stderr, "dbg5       unused[%2d]:    %u\n", i, xms->unused[i]);
    for (i=0;i<xms->pixels_ss;i++)
      fprintf(stderr, "dbg5       ss[%2d]:        %f %f\n",
                      i, xms->ss[i], xms->ss_alongtrack[i]);
  }

  /* set kind */
  if (status == MB_SUCCESS) {
    /* set kind */
    store->kind = MB_DATA_DATA;
  }
  else {
    store->kind = MB_DATA_NONE;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_rd_unknown(int verbose, char *buffer, void *store_ptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_rd_unknown";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_header *header = NULL;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       buffer:     %p\n", (void *)buffer);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  header = (struct mbsys_kmbes_header *)header_ptr;

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_header(int verbose, char **bufferptr, void *header_ptr, int *error) {
  char *function_name = "mbr_kemkmall_wr_header";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_header *header = NULL;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       header_ptr: %p\n", (void *)header_ptr);
  }

  /* get pointer to raw data structure */
  header = (struct mbsys_kmbes_header *)header_ptr;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", header->numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %s\n", header->dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", header->dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", header->systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", header->echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", header->time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", header->time_nanosec);
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the data */
    index = 0;

    mb_put_binary_int(MB_YES, header->numBytesDgm, &buffer[index]);
    index += 4;
    memcpy(&buffer[index], &(header->dgmType), sizeof(header->dgmType));
    index += 4;
    buffer[index] = header->dgmVersion;
    index++;
    buffer[index] = header->systemID;
    index++;
    mb_put_binary_short(MB_YES, header->echoSounderID, &buffer[index]);
    index += 2;
    mb_put_binary_int(MB_YES, header->time_sec, &buffer[index]);
    index += 4;
    mb_put_binary_int(MB_YES, header->time_nanosec, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_spo(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error){
  char *function_name = "mbr_kemkmall_wr_spo";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_spo *spo = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  spo = &(store->spo);
  header = &store->spo.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:                 %u\n", spo->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                     %s\n", spo->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:                  %u\n", spo->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                    %u\n", spo->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:               %u\n", spo->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                    %u\n", spo->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:                %u\n", spo->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:             %u\n", spo->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:                %u\n", spo->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:                %u\n", spo->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:                     %u\n", spo->cmnPart.padding);

    fprintf(stderr, "dbg5       timeFromSensor_sec:          %u\n", spo->sensorData.timeFromSensor_sec);
    fprintf(stderr, "dbg5       timeFromSensor_nanosec:      %u\n", spo->sensorData.timeFromSensor_nanosec);
    fprintf(stderr, "dbg5       posFixQuality_m:             %f\n", spo->sensorData.posFixQuality_m);
    fprintf(stderr, "dbg5       correctedLat_deg:            %f\n", spo->sensorData.correctedLat_deg);
    fprintf(stderr, "dbg5       correctedLong_deg:           %f\n", spo->sensorData.correctedLong_deg);
    fprintf(stderr, "dbg5       speedOverGround_mPerSec:     %f\n", spo->sensorData.speedOverGround_mPerSec);
    fprintf(stderr, "dbg5       courseOverGround_deg:        %f\n", spo->sensorData.courseOverGround_deg);
    fprintf(stderr, "dbg5       ellipsoidHeightReRefPoint_m: %f\n", spo->sensorData.ellipsoidHeightReRefPoint_m);
    fprintf(stderr, "dbg5       posDataFromSensor:           %s\n", spo->sensorData.posDataFromSensor);
  }

  /* size of output record */
  *size = (size_t) spo->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *)*bufferptr;

    /* calc number of bytes for raw sensor data */
    numBytesRawSensorData = spo->header.numBytesDgm - MBSYS_KMBES_SPO_VAR_OFFSET;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&(spo->header), error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* common part */
    mb_put_binary_short(MB_YES, spo->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, spo->cmnPart.sensorSystem, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, spo->cmnPart.sensorStatus, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, spo->cmnPart.padding, &buffer[index]);
    index += 2;

    /* sensor data block */
    mb_put_binary_int(MB_YES, spo->sensorData.timeFromSensor_sec, &buffer[index]);
    index += 4;
    mb_put_binary_int(MB_YES, spo->sensorData.timeFromSensor_nanosec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, spo->sensorData.posFixQuality_m, &buffer[index]);
    index += 4;
    mb_put_binary_double(MB_YES, spo->sensorData.correctedLat_deg, &buffer[index]);
    index += 8;
    mb_put_binary_double(MB_YES, spo->sensorData.correctedLong_deg, &buffer[index]);
    index += 8;
    mb_put_binary_float(MB_YES, spo->sensorData.speedOverGround_mPerSec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, spo->sensorData.courseOverGround_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, spo->sensorData.ellipsoidHeightReRefPoint_m, &buffer[index]);
    index += 4;

    /* raw data msg from sensor */
    memcpy(&buffer[index], &(spo->sensorData.posDataFromSensor), numBytesRawSensorData);
    index += numBytesRawSensorData;

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, spo->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_skm(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error){
  char *function_name = "mbr_kemkmall_wr_skm";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_skm *skm = NULL;
  struct mbsys_kmbes_header *header = NULL;
  char *buffer = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  skm = &(store->skm);
  header = &store->skm.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:                %u\n", skm->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                    %s\n", skm->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:                 %u\n", skm->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                   %u\n", skm->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:              %u\n", skm->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                   %u\n", skm->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:               %u\n", skm->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesInfoPart:           %u\n", skm->infoPart.numBytesInfoPart);
    fprintf(stderr, "dbg5       sensorSystem:               %u\n", skm->infoPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:               %u\n", skm->infoPart.sensorStatus);
    fprintf(stderr, "dbg5       sensorInputFormat:          %u\n", skm->infoPart.sensorInputFormat);
    fprintf(stderr, "dbg5       numSamplesArray:            %u\n", skm->infoPart.numSamplesArray);
    fprintf(stderr, "dbg5       numBytesPerSample:          %u\n", skm->infoPart.numBytesPerSample);
    fprintf(stderr, "dbg5       sensorDataContents:         %u\n", skm->infoPart.sensorDataContents);

    for (i=0; i<(skm->infoPart.numSamplesArray); i++ ) {
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.dgmType:                %s\n", i, skm->sample[i].KMdefault.dgmType);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.numBytesDgm:            %u\n", i, skm->sample[i].KMdefault.numBytesDgm);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.dgmVersion:             %u\n", i, skm->sample[i].KMdefault.dgmVersion);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.time_sec:               %u\n", i, skm->sample[i].KMdefault.time_sec);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.time_nanosec:           %u\n", i, skm->sample[i].KMdefault.time_nanosec);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.status:                 %u\n", i, skm->sample[i].KMdefault.status);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.latitude_deg:           %f\n", i, skm->sample[i].KMdefault.latitude_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.longitude_deg:          %f\n", i, skm->sample[i].KMdefault.longitude_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.ellipsoidHeight_m:      %f\n", i, skm->sample[i].KMdefault.ellipsoidHeight_m);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.roll_deg:               %f\n", i, skm->sample[i].KMdefault.roll_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.pitch_deg:              %f\n", i, skm->sample[i].KMdefault.pitch_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.heading_deg:            %f\n", i, skm->sample[i].KMdefault.heading_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.heave_m:                %f\n", i, skm->sample[i].KMdefault.heave_m);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.rollRate:               %f\n", i, skm->sample[i].KMdefault.rollRate);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.pitchRate:              %f\n", i, skm->sample[i].KMdefault.pitchRate);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.yawRate:                %f\n", i, skm->sample[i].KMdefault.yawRate);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.velNorth:               %f\n", i, skm->sample[i].KMdefault.velNorth);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.velEast:                %f\n", i, skm->sample[i].KMdefault.velEast);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.velDown:                %f\n", i, skm->sample[i].KMdefault.velDown);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.latitudeError_m:        %f\n", i, skm->sample[i].KMdefault.latitudeError_m);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.longitudeError_m:       %f\n", i, skm->sample[i].KMdefault.longitudeError_m);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.ellipsoidHeightError_m: %f\n", i, skm->sample[i].KMdefault.ellipsoidHeightError_m);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.rollError_deg:          %f\n", i, skm->sample[i].KMdefault.rollError_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.pitchError_deg:         %f\n", i, skm->sample[i].KMdefault.pitchError_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.headingError_deg:       %f\n", i, skm->sample[i].KMdefault.headingError_deg);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.heaveError_m:           %f\n", i, skm->sample[i].KMdefault.heaveError_m);

      fprintf(stderr, "dbg5       sample[%3d].KMdefault.northAcceleration:      %f\n", i, skm->sample[i].KMdefault.northAcceleration);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.eastAcceleration:       %f\n", i, skm->sample[i].KMdefault.eastAcceleration);
      fprintf(stderr, "dbg5       sample[%3d].KMdefault.downAcceleration:       %f\n", i, skm->sample[i].KMdefault.downAcceleration);

      //
      fprintf(stderr, "dbg5       sample[%3d].delayedHeave.time_sec:            %u\n", i, skm->sample[i].delayedHeave.time_sec);
      fprintf(stderr, "dbg5       sample[%3d].delayedHeave.time_nanosec:        %u\n", i, skm->sample[i].delayedHeave.time_nanosec);
      fprintf(stderr, "dbg5       sample[%3d].delayedHeave.delayedHeave_m:      %f\n", i, skm->sample[i].delayedHeave.delayedHeave_m);
    }

  }

  /* size of output record */
  *size = (size_t) skm->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&skm->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* info part */
    mb_put_binary_short(MB_YES, skm->infoPart.numBytesInfoPart, &buffer[index]);
    index += 2;
    buffer[index] = skm->infoPart.sensorSystem;
    index++;
    buffer[index] = skm->infoPart.sensorStatus;
    index++;
    mb_put_binary_short(MB_YES, skm->infoPart.sensorInputFormat, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, skm->infoPart.numSamplesArray, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, skm->infoPart.numBytesPerSample, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, skm->infoPart.sensorDataContents, &buffer[index]);
    index += 2;

    for (i=0; i<(skm->infoPart.numSamplesArray); i++ ) {

      /* KMbinary */
      memcpy(&buffer[index], &(skm->sample[i].KMdefault.dgmType), 4);
      index += 4;
      mb_put_binary_short(MB_YES, skm->sample[i].KMdefault.numBytesDgm, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, skm->sample[i].KMdefault.dgmVersion, &buffer[index]);
      index += 2;
      mb_put_binary_int(MB_YES, skm->sample[i].KMdefault.time_sec, &buffer[index]);
      index += 4;
      mb_put_binary_int(MB_YES, skm->sample[i].KMdefault.time_nanosec, &buffer[index]);
      index += 4;
      mb_put_binary_int(MB_YES, skm->sample[i].KMdefault.status, &buffer[index]);
      index += 4;
      mb_put_binary_double(MB_YES, skm->sample[i].KMdefault.latitude_deg, &buffer[index]);
      index += 8;
      mb_put_binary_double(MB_YES, skm->sample[i].KMdefault.longitude_deg, &buffer[index]);
      index += 8;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.ellipsoidHeight_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.roll_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.pitch_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.heading_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.heave_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.rollRate, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.pitchRate, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.yawRate, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.velNorth, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.velEast, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.velDown, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.latitudeError_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.longitudeError_m, &buffer[index]);
      index += 4;
            mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.ellipsoidHeightError_m, &buffer[index]);
            index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.rollError_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.pitchError_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.headingError_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.heaveError_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.northAcceleration, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.eastAcceleration, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].KMdefault.downAcceleration, &buffer[index]);
      index += 4;

      /* KMdelayedHeave */
      mb_put_binary_int(MB_YES, skm->sample[i].delayedHeave.time_sec, &buffer[index]);
      index += 4;
      mb_put_binary_int(MB_YES, skm->sample[i].delayedHeave.time_nanosec, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, skm->sample[i].delayedHeave.delayedHeave_m, &buffer[index]);
      index += 4;
    }

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, skm->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_svp(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_svp";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_svp *svp = NULL;
  struct mbsys_kmbes_header *header = NULL;
  char *buffer = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  svp = &(store->svp);
  header = &store->svp.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, " dbg5       numBytesDgm:     %u\n", svp->header.numBytesDgm);
    fprintf(stderr, " dbg5       dgmType:         %s\n", svp->header.dgmType);
    fprintf(stderr, " dbg5       dgmVersion:      %u\n", svp->header.dgmVersion);
    fprintf(stderr, " dbg5       systemID:        %u\n", svp->header.systemID);
    fprintf(stderr, " dbg5       echoSounderID:   %u\n", svp->header.echoSounderID);
    fprintf(stderr, " dbg5       time_sec:        %u\n", svp->header.time_sec);
    fprintf(stderr, " dbg5       time_nanosec:    %u\n", svp->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", svp->numBytesCmnPart);
    fprintf(stderr, "dbg5       numSamples:       %u\n", svp->numSamples);
    fprintf(stderr, "dbg5       sensorFormat:     %s\n", svp->sensorFormat);
    fprintf(stderr, "dbg5       time_sec:         %u\n", svp->time_sec);
    fprintf(stderr, "dbg5       latitude_deg:     %f\n", svp->latitude_deg);
    fprintf(stderr, "dbg5       longitude_deg:    %f\n", svp->longitude_deg);

    for (i = 0; i < (svp->numSamples); i++) {
      fprintf(stderr, "dbg5       sensorData[%3d].depth_m:                %f\n", i, svp->sensorData[i].depth_m);
      fprintf(stderr, "dbg5       sensorData[%3d].soundVelocity_mPerSec:  %f\n", i, svp->sensorData[i].soundVelocity_mPerSec);
      fprintf(stderr, "dbg5       sensorData[%3d].padding:                %d\n", i, svp->sensorData[i].padding);
      fprintf(stderr, "dbg5       sensorData[%3d].temp_C:                 %f\n", i, svp->sensorData[i].temp_C);
      fprintf(stderr, "dbg5       sensorData[%3d].salinity:               %f\n", i, svp->sensorData[i].salinity);
    }
  }

  /* size of output record */
  *size = (size_t) svp->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
        mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&svp->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* svp common part */
    mb_put_binary_short(MB_YES, svp->numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, svp->numSamples, &buffer[index]);
    index += 2;
    memcpy(&buffer[index], &svp->sensorFormat, 4);
    index += 4;
    mb_put_binary_int(MB_YES, svp->time_sec, &buffer[index]);
    index += 4;
    mb_put_binary_double(MB_YES, svp->latitude_deg, &buffer[index]);
    index += 8;
    mb_put_binary_double(MB_YES, svp->longitude_deg, &buffer[index]);
    index += 8;

    /* svp data block */
    for (i = 0; i < (svp->numSamples); i++) {
      mb_put_binary_float(MB_YES, svp->sensorData[i].depth_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, svp->sensorData[i].soundVelocity_mPerSec, &buffer[index]);
      index += 4;
      mb_put_binary_int(MB_YES, svp->sensorData[i].padding, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, svp->sensorData[i].temp_C, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, svp->sensorData[i].salinity, &buffer[index]);
      index += 4;
    }

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, svp->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_svt(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_svt";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_svt *svt = NULL;
  struct mbsys_kmbes_header *header = NULL;
  char *buffer = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  svt = &(store->svt);
  header = &store->svt.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:              %u\n", svt->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                  %s\n", svt->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:               %u\n", svt->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                 %u\n", svt->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:            %u\n", svt->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                 %u\n", svt->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:             %u\n", svt->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesInfoPart:         %u\n", svt->infoPart.numBytesInfoPart);
    fprintf(stderr, "dbg5       sensorStatus:             %u\n", svt->infoPart.sensorStatus);
    fprintf(stderr, "dbg5       sensorInputFormat:        %u\n", svt->infoPart.sensorInputFormat);
    fprintf(stderr, "dbg5       numSamplesArray:          %u\n", svt->infoPart.numSamplesArray);
    fprintf(stderr, "dbg5       sensorDataContents:       %u\n", svt->infoPart.sensorDataContents);
    fprintf(stderr, "dbg5       filterTime_sec:           %f\n", svt->infoPart.filterTime_sec);
    fprintf(stderr, "dbg5       soundVelocity_mPerSec_offset: %f\n", svt->infoPart.soundVelocity_mPerSec_offset);

    for (i = 0; i < (svt->infoPart.numSamplesArray); i++) {
      fprintf(stderr, "dbg5       sensorData[%3d].time_sec:               %u\n", i, svt->sensorData[i].time_sec);
      fprintf(stderr, "dbg5       sensorData[%3d].time_nanosec:           %u\n", i, svt->sensorData[i].time_nanosec);
      fprintf(stderr, "dbg5       sensorData[%3d].soundVelocity_mPerSec:  %f\n", i, svt->sensorData[i].soundVelocity_mPerSec);
      fprintf(stderr, "dbg5       sensorData[%3d].temp_C:                 %f\n", i, svt->sensorData[i].temp_C);
      fprintf(stderr, "dbg5       sensorData[%3d].pressure_Pa:            %f\n", i, svt->sensorData[i].pressure_Pa);
      fprintf(stderr, "dbg5       sensorData[%3d].salinity:               %f\n", i, svt->sensorData[i].salinity);
    }
  }

  /* size of output record */
  *size = (size_t) svt->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&svt->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* svt common part */
    mb_put_binary_short(MB_YES, svt->infoPart.numBytesInfoPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, svt->infoPart.sensorStatus, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, svt->infoPart.sensorInputFormat, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, svt->infoPart.numSamplesArray, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, svt->infoPart.sensorDataContents, &buffer[index]);
    index += 2;
    mb_put_binary_float(MB_YES, svt->infoPart.filterTime_sec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, svt->infoPart.soundVelocity_mPerSec_offset, &buffer[index]);
    index += 4;

    /* svt data block */
    for( i=0; i<svt->infoPart.numSamplesArray; i++ )
    {
      mb_put_binary_int(MB_YES, svt->sensorData[i].time_sec, &buffer[index]);
      index += 4;
      mb_put_binary_int(MB_YES, svt->sensorData[i].time_nanosec, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, svt->sensorData[i].soundVelocity_mPerSec, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, svt->sensorData[i].temp_C, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, svt->sensorData[i].pressure_Pa, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, svt->sensorData[i].salinity, &buffer[index]);
      index += 4;
    }

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, svt->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_scl(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_scl";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_scl *scl;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }


  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  scl = &(store->scl);
  header = &store->scl.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:         %u\n", scl->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:             %s\n", scl->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:          %u\n", scl->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:            %u\n", scl->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:       %u\n", scl->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:            %u\n", scl->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:        %u\n", scl->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:     %u\n", scl->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:        %u\n", scl->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:        %u\n", scl->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:             %u\n", scl->cmnPart.padding);

    fprintf(stderr, "dbg5       offset_sec:          %f\n", scl->sensorData.offset_sec);
    fprintf(stderr, "dbg5       clockDevPU_nanosec:  %d\n", scl->sensorData.clockDevPU_nanosec);
    fprintf(stderr, "dbg5       dataFromSensor:      %s\n", scl->sensorData.dataFromSensor);
  }

  /* size of output record */
  *size = (size_t) scl->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&scl->header, error);

    /* calc number of bytes for raw sensor data */
    numBytesRawSensorData = scl->header.numBytesDgm - MBSYS_KMBES_SCL_VAR_OFFSET;

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* common part */
    mb_put_binary_short(MB_YES, scl->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, scl->cmnPart.sensorSystem, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, scl->cmnPart.sensorStatus, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, scl->cmnPart.padding, &buffer[index]);
    index += 2;

    /* sensor data block */
    mb_put_binary_float(MB_YES, scl->sensorData.offset_sec, &buffer[index]);
    index += 4;
    mb_put_binary_int(MB_YES, scl->sensorData.clockDevPU_nanosec, &buffer[index]);
    index += 4;
    memcpy(&buffer[index], &(scl->sensorData.dataFromSensor), numBytesRawSensorData);
    index += numBytesRawSensorData;

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, scl->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_sde(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error){
  char *function_name = "mbr_kemkmall_wr_sde";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_sde *sde = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  sde = &(store->sde);
  header = &store->sde.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:      %u\n", sde->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:          %s\n", sde->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:       %u\n", sde->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:         %u\n", sde->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:    %u\n", sde->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:         %u\n", sde->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:     %u\n", sde->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", sde->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:     %u\n", sde->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:     %u\n", sde->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:          %u\n", sde->cmnPart.padding);

    fprintf(stderr, "dbg5       depthUsed_m:      %f\n", sde->sensorData.depthUsed_m);
    fprintf(stderr, "dbg5       offset:           %f\n", sde->sensorData.offset);
    fprintf(stderr, "dbg5       scale:            %f\n", sde->sensorData.scale);
    fprintf(stderr, "dbg5       latitude_deg:     %f\n", sde->sensorData.latitude_deg);
    fprintf(stderr, "dbg5       longitude_deg:    %f\n", sde->sensorData.longitude_deg);
    fprintf(stderr, "dbg5       dataFromSensor:   %s\n", sde->sensorData.dataFromSensor);
  }

  /* size of output record */
  *size = (size_t) sde->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&sde->header, error);

    /* calc number of bytes for raw sensor data */
    numBytesRawSensorData = sde->header.numBytesDgm - MBSYS_KMBES_SDE_VAR_OFFSET;

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* common part */
    mb_put_binary_short(MB_YES, sde->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sde->cmnPart.sensorSystem, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sde->cmnPart.sensorStatus, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sde->cmnPart.padding, &buffer[index]);
    index += 2;

    /* sensor data block */
    mb_put_binary_float(MB_YES, sde->sensorData.depthUsed_m, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, sde->sensorData.offset, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, sde->sensorData.scale, &buffer[index]);
    index += 4;
    mb_put_binary_double(MB_YES, sde->sensorData.latitude_deg, &buffer[index]);
    index += 8;
    mb_put_binary_double(MB_YES, sde->sensorData.longitude_deg, &buffer[index]);
    index += 8;
    memcpy(&(sde->sensorData.dataFromSensor), &buffer[index], numBytesRawSensorData);
    index += numBytesRawSensorData;

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, sde->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_shi(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error){
  char *function_name = "mbr_kemkmall_wr_shi";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_shi *shi = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  shi = &(store->shi);
  header = &store->shi.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:      %u\n", shi->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:          %s\n", shi->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:       %u\n", shi->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:         %u\n", shi->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:    %u\n", shi->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:         %u\n", shi->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:     %u\n", shi->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", shi->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:     %u\n", shi->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:     %u\n", shi->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:          %u\n", shi->cmnPart.padding);

    fprintf(stderr, "dbg5       sensorType:       %u\n", shi->sensorData.sensorType);
    fprintf(stderr, "dbg5       heigthUsed_m:     %f\n", shi->sensorData.heigthUsed_m);
    fprintf(stderr, "dbg5       dataFromSensor:   %s\n", shi->sensorData.dataFromSensor);
  }

  /* size of output record */
  *size = (size_t) shi->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&shi->header, error);

    /* calc number of bytes for raw sensor data */
    numBytesRawSensorData = shi->header.numBytesDgm - MBSYS_KMBES_SHI_VAR_OFFSET;

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* common part */
    mb_put_binary_short(MB_YES, shi->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, shi->cmnPart.sensorSystem, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, shi->cmnPart.sensorStatus, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, shi->cmnPart.padding, &buffer[index]);
    index += 2;

    /* sensor data block */
    mb_put_binary_short(MB_YES, shi->sensorData.sensorType, &buffer[index]);
    index += 2;
    mb_put_binary_float(MB_YES, shi->sensorData.heigthUsed_m, &buffer[index]);
    index += 4;
    memcpy(&buffer[index], &(shi->sensorData.dataFromSensor), numBytesRawSensorData);
    index += numBytesRawSensorData;

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, shi->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_sha(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_sha";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_sha *sha = NULL;
  struct mbsys_kmbes_header *header = NULL;
  char *buffer = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  sha = &(store->sha);
  header = &store->sha.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:            %u\n", sha->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                %s\n", sha->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:             %u\n", sha->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:               %u\n", sha->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:          %u\n", sha->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:               %u\n", sha->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:           %u\n", sha->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:        %u\n", sha->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:           %u\n", sha->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:           %u\n", sha->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:                %u\n", sha->cmnPart.padding);

    fprintf(stderr, "dbg5       numBytesInfoPart:       %u\n", sha->dataInfo.numBytesInfoPart);
    fprintf(stderr, "dbg5       numSamplesArray:        %u\n", sha->dataInfo.numSamplesArray);
    fprintf(stderr, "dbg5       numBytesPerSample:      %u\n", sha->dataInfo.numBytesPerSample);
    fprintf(stderr, "dbg5       numBytesRawSensorData:  %u\n", sha->dataInfo.numBytesRawSensorData);

    for (i = 0; i < (sha->dataInfo.numSamplesArray); i++) {
      fprintf(stderr, "dbg5       sensorData[%3d].timeSinceRecStart_nanosec: %u\n", i, sha->sensorData[i].timeSinceRecStart_nanosec);
      fprintf(stderr, "dbg5       sensorData[%3d].headingCorrected_deg:      %f\n", i, sha->sensorData[i].headingCorrected_deg);
      fprintf(stderr, "dbg5       sensorData[%3d].dataFromSensor:            %s\n", i, sha->sensorData[i].dataFromSensor);
    }
  }

  /* size of output record */
  *size = (size_t) sha->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&sha->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* common part */
    mb_put_binary_short(MB_YES, sha->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sha->cmnPart.sensorSystem, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sha->cmnPart.sensorStatus, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sha->cmnPart.padding, &buffer[index]);
    index += 2;

    /* sensor info */
    mb_put_binary_short(MB_YES, sha->dataInfo.numBytesInfoPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sha->dataInfo.numSamplesArray, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sha->dataInfo.numBytesPerSample, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, sha->dataInfo.numBytesRawSensorData, &buffer[index]);
    index += 2;

    /* sensor data blocks */
    for (i = 0; i<(sha->dataInfo.numSamplesArray); i++) {
      mb_put_binary_int(MB_YES, sha->sensorData[i].timeSinceRecStart_nanosec, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, sha->sensorData[i].headingCorrected_deg, &buffer[index]);
      index += 4;
      memcpy(&buffer[index], &(sha->sensorData[i].dataFromSensor), sha->dataInfo.numBytesRawSensorData);
      index += sha->dataInfo.numBytesRawSensorData;
    }

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, sha->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s read - time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_mrz(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, int imrz, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_mrz";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_mrz *mrz = NULL;
  struct mbsys_kmbes_header *header = NULL;
  char *buffer = NULL;
  int numSoundings = 0;
  int numSidescanSamples = 0;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
    fprintf(stderr, "dbg2       imrz:       %d\n", imrz);
  }

  /* get pointer to the data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  mrz = (struct mbsys_kmbes_mrz *)&store->mrz[imrz];
  header = &store->mrz[imrz].header;

  /* size of output record and components thereof - set the size according to what
      we know about, as anything added by Kongsberg that we don't know about will
      have been skipped while reading */
  mrz->cmnPart.numBytesCmnPart = 12;
  mrz->pingInfo.numBytesInfoData = 144;
  mrz->pingInfo.numBytesPerTxSector = 36;
  mrz->rxInfo.numBytesRxInfo = 32;
  mrz->rxInfo.numBytesPerClass = 4;
  mrz->rxInfo.numBytesPerSounding = 120;
  numSoundings = mrz->rxInfo.numSoundingsMaxMain + mrz->rxInfo.numExtraDetections;
  numSidescanSamples = 0;
  for (int i = 0; i<numSoundings; i++) {
    numSidescanSamples += mrz->sounding[i].SInumSamples;
  }
  mrz->header.numBytesDgm = MBSYS_KMBES_HEADER_SIZE
                            + mrz->cmnPart.numBytesCmnPart
                            + MBSYS_KMBES_PARITION_SIZE
                            + mrz->pingInfo.numBytesInfoData
                            + mrz->pingInfo.numTxSectors * mrz->pingInfo.numBytesPerTxSector
                            + mrz->rxInfo.numBytesRxInfo
                            + mrz->rxInfo.numExtraDetectionClasses * mrz->rxInfo.numBytesPerClass
                            + numSoundings * mrz->rxInfo.numBytesPerSounding
                            + numSidescanSamples * sizeof(short)
                            + MBSYS_KMBES_END_SIZE;

  *size = (size_t) mrz->header.numBytesDgm;
//fprintf(stderr, "************>%s:%d WRITE mbr_kemkmall_wr_mrz mrz->header.numBytesDgm:%d\n",
//__FILE__, __LINE__, mrz->header.numBytesDgm);

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&mrz->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* EMdgmMpartition - data partition information */
    mb_put_binary_short(MB_YES, mrz->partition.numOfDgms, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->partition.dgmNum, &buffer[index]);
    index += 2;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numOfDgms:  %d\n", mrz->partition.numOfDgms);
      fprintf(stderr, "dbg5       dgmNum:     %d\n", mrz->partition.dgmNum);
    }

    /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
    mb_put_binary_short(MB_YES, mrz->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->cmnPart.pingCnt, &buffer[index]);
    index += 2;
    buffer[index] = mrz->cmnPart.rxFansPerPing;
    index++;
    buffer[index] = mrz->cmnPart.rxFanIndex;
    index++;
    buffer[index] = mrz->cmnPart.swathsPerPing;
    index++;
    buffer[index] = mrz->cmnPart.swathAlongPosition;
    index++;
    buffer[index] = mrz->cmnPart.txTransducerInd;
    index++;
    buffer[index] = mrz->cmnPart.rxTransducerInd;
    index++;
    buffer[index] = mrz->cmnPart.numRxTransducers;
    index++;
    buffer[index] = mrz->cmnPart.algorithmType;
    index++;

    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesCmnPart:     %d\n", mrz->cmnPart.numBytesCmnPart);
      fprintf(stderr, "dbg5       pingCnt:             %d\n", mrz->cmnPart.pingCnt);
      fprintf(stderr, "dbg5       rxFansPerPing:       %d\n", mrz->cmnPart.rxFansPerPing);
      fprintf(stderr, "dbg5       rxFanIndex:          %d\n", mrz->cmnPart.rxFanIndex);
      fprintf(stderr, "dbg5       swathsPerPing:       %d\n", mrz->cmnPart.swathsPerPing);
      fprintf(stderr, "dbg5       swathAlongPosition:  %d\n", mrz->cmnPart.swathAlongPosition);
      fprintf(stderr, "dbg5       txTransducerInd:     %d\n", mrz->cmnPart.txTransducerInd);
      fprintf(stderr, "dbg5       rxTransducerInd:     %d\n", mrz->cmnPart.rxTransducerInd);
      fprintf(stderr, "dbg5       numRxTransducers:    %d\n", mrz->cmnPart.numRxTransducers);
      fprintf(stderr, "dbg5       algorithmType:       %d\n", mrz->cmnPart.algorithmType);
    }

    /* EMdgmMRZ_pingInfo - ping info */
    mb_put_binary_short(MB_YES, mrz->pingInfo.numBytesInfoData, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->pingInfo.padding0, &buffer[index]);
    index += 2;

    /* ping info */
    mb_put_binary_float(MB_YES, mrz->pingInfo.pingRate_Hz, &buffer[index]);
    index += 4;

    buffer[index] = mrz->pingInfo.beamSpacing;
    index++;
    buffer[index] = mrz->pingInfo.depthMode;
    index++;
    buffer[index] = mrz->pingInfo.subDepthMode;
    index++;
    buffer[index] = mrz->pingInfo.distanceBtwSwath;
    index++;
    buffer[index] = mrz->pingInfo.detectionMode;
    index++;
    buffer[index] = mrz->pingInfo.pulseForm;
    index++;

    mb_put_binary_short(MB_YES, mrz->pingInfo.padding1, &buffer[index]);
    index += 2;
    mb_put_binary_float(MB_YES, mrz->pingInfo.frequencyMode_Hz, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.freqRangeLowLim_Hz, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.freqRangeHighLim_Hz, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.maxTotalTxPulseLength_sec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.maxEffTxPulseLength_sec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.maxEffTxBandWidth_Hz, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.absCoeff_dBPerkm, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.portSectorEdge_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.starbSectorEdge_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.portMeanCov_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.starbMeanCov_deg, &buffer[index]);
    index += 4;
    mb_put_binary_short(MB_YES, mrz->pingInfo.portMeanCov_m, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->pingInfo.starbMeanCov_m, &buffer[index]);
    index += 2;

    buffer[index] = mrz->pingInfo.modeAndStabilisation;
    index++;
    buffer[index] = mrz->pingInfo.runtimeFilter1;
    index++;

    mb_put_binary_short(MB_YES, mrz->pingInfo.runtimeFilter2, &buffer[index]);
    index += 2;
    mb_put_binary_int(MB_YES, mrz->pingInfo.pipeTrackingStatus, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.transmitArraySizeUsed_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.receiveArraySizeUsed_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.transmitPower_dB, &buffer[index]);
    index += 4;
    mb_put_binary_short(MB_YES, mrz->pingInfo.SLrampUpTimeRemaining, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->pingInfo.padding2, &buffer[index]);
    index += 2;
    mb_put_binary_float(MB_YES, mrz->pingInfo.yawAngle_deg, &buffer[index]);
    index += 4;

    // Info of tx sector data block, EMdgmMRZ_txSectorInfo
    mb_put_binary_short(MB_YES, mrz->pingInfo.numTxSectors, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->pingInfo.numBytesPerTxSector, &buffer[index]);
    index += 2;

    // Info at time of midpoint of first tx pulse
    mb_put_binary_float(MB_YES, mrz->pingInfo.headingVessel_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.soundSpeedAtTxDepth_mPerSec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.txTransducerDepth_m, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.z_waterLevelReRefPoint_m, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.x_kmallToall_m, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->pingInfo.y_kmallToall_m, &buffer[index]);
    index += 4;

    buffer[index] = mrz->pingInfo.latLongInfo;
    index++;
    buffer[index] = mrz->pingInfo.posSensorStatus;
    index++;
    buffer[index] = mrz->pingInfo.attitudeSensorStatus;
    index++;
    buffer[index] = mrz->pingInfo.padding3;
    index++;

    mb_put_binary_double(MB_YES, mrz->pingInfo.latitude_deg, &buffer[index]);
    index += 8;
    mb_put_binary_double(MB_YES, mrz->pingInfo.longitude_deg, &buffer[index]);
    index += 8;
    mb_put_binary_float(MB_YES, mrz->pingInfo.ellipsoidHeightReRefPoint_m, &buffer[index]);
    index += 4;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesInfoData:            %d\n", mrz->pingInfo.numBytesInfoData);
      fprintf(stderr, "dbg5       padding0:                    %d\n", mrz->pingInfo.padding0);
      fprintf(stderr, "dbg5       pingRate_Hz:                 %f\n", mrz->pingInfo.pingRate_Hz);
      fprintf(stderr, "dbg5       beamSpacing:                 %d\n", mrz->pingInfo.beamSpacing);
      fprintf(stderr, "dbg5       depthMode:                   %d\n", mrz->pingInfo.depthMode);
      fprintf(stderr, "dbg5       subDepthMode:                %d\n", mrz->pingInfo.subDepthMode);
      fprintf(stderr, "dbg5       distanceBtwSwath:            %d\n", mrz->pingInfo.distanceBtwSwath);
      fprintf(stderr, "dbg5       detectionMode:               %d\n", mrz->pingInfo.detectionMode);
      fprintf(stderr, "dbg5       pulseForm:                   %d\n", mrz->pingInfo.pulseForm);
      fprintf(stderr, "dbg5       padding1:                    %d\n", mrz->pingInfo.padding1);
      fprintf(stderr, "dbg5       frequencyMode_Hz:            %f\n", mrz->pingInfo.frequencyMode_Hz);
      fprintf(stderr, "dbg5       freqRangeLowLim_Hz:          %f\n", mrz->pingInfo.freqRangeLowLim_Hz);
      fprintf(stderr, "dbg5       freqRangeHighLim_Hz:         %f\n", mrz->pingInfo.freqRangeHighLim_Hz);
      fprintf(stderr, "dbg5       maxEffTxPulseLength_sec:     %f\n", mrz->pingInfo.maxEffTxPulseLength_sec);
      fprintf(stderr, "dbg5       maxTotalTxPulseLength_sec:   %f\n", mrz->pingInfo.maxTotalTxPulseLength_sec);
      fprintf(stderr, "dbg5       maxEffTxBandWidth_Hz:        %f\n", mrz->pingInfo.maxEffTxBandWidth_Hz);
      fprintf(stderr, "dbg5       absCoeff_dBPerkm:            %f\n", mrz->pingInfo.absCoeff_dBPerkm);
      fprintf(stderr, "dbg5       portSectorEdge_deg:          %f\n", mrz->pingInfo.portSectorEdge_deg);
      fprintf(stderr, "dbg5       starbSectorEdge_deg:         %f\n", mrz->pingInfo.starbSectorEdge_deg);
      fprintf(stderr, "dbg5       portMeanCov_m:               %d\n", mrz->pingInfo.portMeanCov_m);
      fprintf(stderr, "dbg5       starbMeanCov_m:              %d\n", mrz->pingInfo.starbMeanCov_m);
      fprintf(stderr, "dbg5       modeAndStabilisation:        %d\n", mrz->pingInfo.modeAndStabilisation);
      fprintf(stderr, "dbg5       runtimeFilter1:              %d\n", mrz->pingInfo.runtimeFilter1);
      fprintf(stderr, "dbg5       runtimeFilter2:              %d\n", mrz->pingInfo.runtimeFilter2);
      fprintf(stderr, "dbg5       pipeTrackingStatus:          %d\n", mrz->pingInfo.pipeTrackingStatus);
      fprintf(stderr, "dbg5       transmitArraySizeUsed_deg:   %f\n", mrz->pingInfo.transmitArraySizeUsed_deg);
      fprintf(stderr, "dbg5       receiveArraySizeUsed_deg:    %f\n", mrz->pingInfo.receiveArraySizeUsed_deg);
      fprintf(stderr, "dbg5       transmitPower_dB:            %f\n", mrz->pingInfo.transmitPower_dB);
      fprintf(stderr, "dbg5       SLrampUpTimeRemaining:       %d\n", mrz->pingInfo.SLrampUpTimeRemaining);
      fprintf(stderr, "dbg5       padding2:                    %d\n", mrz->pingInfo.padding2);
      fprintf(stderr, "dbg5       yawAngle_deg:                %f\n", mrz->pingInfo.yawAngle_deg);
      fprintf(stderr, "dbg5       numTxSectors:                %d\n", mrz->pingInfo.numTxSectors);
      fprintf(stderr, "dbg5       numBytesPerTxSector:         %d\n", mrz->pingInfo.numBytesPerTxSector);
      fprintf(stderr, "dbg5       headingVessel_deg:           %f\n", mrz->pingInfo.headingVessel_deg);
      fprintf(stderr, "dbg5       soundSpeedAtTxDepth_mPerSec: %f\n", mrz->pingInfo.soundSpeedAtTxDepth_mPerSec);
      fprintf(stderr, "dbg5       txTransducerDepth_m:         %f\n", mrz->pingInfo.txTransducerDepth_m);
      fprintf(stderr, "dbg5       z_waterLevelReRefPoint_m:    %f\n", mrz->pingInfo.z_waterLevelReRefPoint_m);
      fprintf(stderr, "dbg5       x_kmallToall_m:              %f\n", mrz->pingInfo.x_kmallToall_m);
      fprintf(stderr, "dbg5       y_kmallToall_m:              %f\n", mrz->pingInfo.y_kmallToall_m);
      fprintf(stderr, "dbg5       latLongInfo:                 %d\n", mrz->pingInfo.latLongInfo);
      fprintf(stderr, "dbg5       posSensorStatus:             %d\n", mrz->pingInfo.posSensorStatus);
      fprintf(stderr, "dbg5       attitudeSensorStatus:        %d\n", mrz->pingInfo.attitudeSensorStatus);
      fprintf(stderr, "dbg5       padding3:                    %d\n", mrz->pingInfo.padding3);
      fprintf(stderr, "dbg5       latitude_deg:                %f\n", mrz->pingInfo.latitude_deg);
      fprintf(stderr, "dbg5       longitude_deg:               %f\n", mrz->pingInfo.longitude_deg);
      fprintf(stderr, "dbg5       ellipsoidHeightReRefPoint_m: %f\n", mrz->pingInfo.ellipsoidHeightReRefPoint_m);
    }

    /* EMdgmMRZ_txSectorInfo - sector information */
    for (i = 0; i < (mrz->pingInfo.numTxSectors); i++) {
      buffer[index] = mrz->sectorInfo[i].txSectorNumb;
      index++;
      buffer[index] = mrz->sectorInfo[i].txArrNumber;
      index++;
      buffer[index] = mrz->sectorInfo[i].txSubArray;
      index++;
      buffer[index] = mrz->sectorInfo[i].padding0;
      index++;
      mb_put_binary_float(MB_YES, mrz->sectorInfo[i].sectorTransmitDelay_sec, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sectorInfo[i].tiltAngleReTx_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sectorInfo[i].txNominalSourceLevel_dB, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sectorInfo[i].txFocusRange_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sectorInfo[i].centreFreq_Hz, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sectorInfo[i].signalBandWidth_Hz, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sectorInfo[i].totalSignalLength_sec, &buffer[index]);
      index += 4;
      buffer[index] = mrz->sectorInfo[i].pulseShading;
      index++;
      buffer[index] = mrz->sectorInfo[i].signalWaveForm;
      index++;
      mb_put_binary_short(MB_YES, mrz->sectorInfo[i].padding1, &buffer[index]);
      index += 2;

      /* print debug statements */
      if (verbose >= 5) {
        fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
        fprintf(stderr, "dbg5       #MWC transmit sector %d/%d:\n", i + 1, mrz->pingInfo.numTxSectors);
        fprintf(stderr, "dbg5       txSectorNumb:             %d\n", mrz->sectorInfo[i].txSectorNumb);
        fprintf(stderr, "dbg5       txArrNumber:              %d\n", mrz->sectorInfo[i].txArrNumber);
        fprintf(stderr, "dbg5       txSubArray:               %d\n", mrz->sectorInfo[i].txSubArray);
        fprintf(stderr, "dbg5       padding0:                 %d\n", mrz->sectorInfo[i].padding0);
        fprintf(stderr, "dbg5       sectorTransmitDelay_sec:  %f\n", mrz->sectorInfo[i].sectorTransmitDelay_sec);
        fprintf(stderr, "dbg5       tiltAngleReTx_deg:        %f\n", mrz->sectorInfo[i].tiltAngleReTx_deg);
        fprintf(stderr, "dbg5       txNominalSourceLevel_dB:  %f\n", mrz->sectorInfo[i].txNominalSourceLevel_dB);
        fprintf(stderr, "dbg5       txFocusRange_m:           %f\n", mrz->sectorInfo[i].txFocusRange_m);
        fprintf(stderr, "dbg5       centreFreq_Hz:            %f\n", mrz->sectorInfo[i].centreFreq_Hz);
        fprintf(stderr, "dbg5       signalBandWidth_Hz:       %f\n", mrz->sectorInfo[i].signalBandWidth_Hz);
        fprintf(stderr, "dbg5       totalSignalLength_sec:    %f\n", mrz->sectorInfo[i].totalSignalLength_sec);
        fprintf(stderr, "dbg5       pulseShading:             %d\n", mrz->sectorInfo[i].pulseShading);
        fprintf(stderr, "dbg5       signalWaveForm:           %d\n", mrz->sectorInfo[i].signalWaveForm);
        fprintf(stderr, "dbg5       padding1:                 %d\n", mrz->sectorInfo[i].padding1);
      }
    }

    /* EMdgmMRZ_rxInfo - receiver specific info */
    mb_put_binary_short(MB_YES, mrz->rxInfo.numBytesRxInfo, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->rxInfo.numSoundingsMaxMain, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->rxInfo.numSoundingsValidMain, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->rxInfo.numBytesPerSounding, &buffer[index]);
    index += 2;

    mb_put_binary_float(MB_YES, mrz->rxInfo.WCSampleRate, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->rxInfo.seabedImageSampleRate, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->rxInfo.BSnormal_dB, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mrz->rxInfo.BSoblique_dB, &buffer[index]);
    index += 4;

    mb_put_binary_short(MB_YES, mrz->rxInfo.extraDetectionAlarmFlag, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->rxInfo.numExtraDetections, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->rxInfo.numExtraDetectionClasses, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mrz->rxInfo.numBytesPerClass, &buffer[index]);
    index += 2;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesInfoData:          %d\n", mrz->rxInfo.numBytesRxInfo);
      fprintf(stderr, "dbg5       numSoundingsMaxMain:       %d\n", mrz->rxInfo.numSoundingsMaxMain);
      fprintf(stderr, "dbg5       numSoundingsValidMain:     %d\n", mrz->rxInfo.numSoundingsValidMain);
      fprintf(stderr, "dbg5       numBytesPerSounding:       %d\n", mrz->rxInfo.numBytesPerSounding);
      fprintf(stderr, "dbg5       WCSampleRate:              %f\n", mrz->rxInfo.WCSampleRate);
      fprintf(stderr, "dbg5       seabedImageSampleRate:     %f\n", mrz->rxInfo.seabedImageSampleRate);
      fprintf(stderr, "dbg5       BSnormal_dB:               %f\n", mrz->rxInfo.BSnormal_dB);
      fprintf(stderr, "dbg5       BSoblique_dB:              %f\n", mrz->rxInfo.BSoblique_dB);
      fprintf(stderr, "dbg5       extraDetectionAlarmFlag:   %d\n", mrz->rxInfo.extraDetectionAlarmFlag);
      fprintf(stderr, "dbg5       numExtraDetections:        %d\n", mrz->rxInfo.numExtraDetections);
      fprintf(stderr, "dbg5       numExtraDetectionClasses:  %d\n", mrz->rxInfo.numExtraDetectionClasses);
      fprintf(stderr, "dbg5       numBytesPerClass:          %d\n", mrz->rxInfo.numBytesPerClass);
    }

    /* EMdgmMRZ_extraDetClassInfo -  Extra detection class info */
    for (i = 0; i < (mrz->rxInfo.numExtraDetectionClasses); i++) {
      mb_put_binary_short(MB_YES, mrz->extraDetClassInfo[i].numExtraDetInClass, &buffer[index]);
      index += 2;
      buffer[index] = mrz->extraDetClassInfo[i].padding;
      index++;
      buffer[index] = mrz->extraDetClassInfo[i].alarmFlag;
      index++;

      /* print debug statements */
      if (verbose >= 5) {
        fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
        fprintf(stderr, "dbg5       numExtraDetInClass:  %d\n", mrz->extraDetClassInfo[i].numExtraDetInClass);
        fprintf(stderr, "dbg5       padding:             %d\n", mrz->extraDetClassInfo[i].padding);
        fprintf(stderr, "dbg5       alarmFlag:           %d\n", mrz->extraDetClassInfo[i].alarmFlag);
      }
    }

    /* EMdgmMRZ_sounding - Data for each sounding */
    //numSidescanSamples = 0;
    //numSoundings = mrz->rxInfo.numSoundingsMaxMain + mrz->rxInfo.numExtraDetections;
    for (i = 0; i < numSoundings; i++) {
      mb_put_binary_short(MB_YES, mrz->sounding[i].soundingIndex, &buffer[index]);
      index += 2;
      buffer[index] = mrz->sounding[i].txSectorNumb;
      index++;

      /* Detection info */
      buffer[index] = mrz->sounding[i].detectionType;
      index++;
      buffer[index] = mrz->sounding[i].detectionMethod;
      index++;
      buffer[index] = mrz->sounding[i].rejectionInfo1;
      index++;
      buffer[index] = mrz->sounding[i].rejectionInfo2;
      index++;
      buffer[index] = mrz->sounding[i].postProcessingInfo;
      index++;
      buffer[index] = mrz->sounding[i].detectionClass;
      index++;
      buffer[index] = mrz->sounding[i].detectionConfidenceLevel;
      index++;
    /* These two bytes specified as padding in the Kongsberg specification but are
       here used for the MB-System beam flag - if the first mb_u_char == 1 then the
       second byte is an MB-System beamflag */
      // mb_put_binary_short(MB_YES, mrz->sounding[i].padding, &buffer[index]);
      // index += 2;
      buffer[index] = mrz->sounding[i].beamflag_enabled;
      index++;
      buffer[index] = mrz->sounding[i].beamflag;
      index++;
      mb_put_binary_float(MB_YES, mrz->sounding[i].rangeFactor, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].qualityFactor, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].detectionUncertaintyVer_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].detectionUncertaintyHor_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].detectionWindowLength_sec, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].echoLength_sec, &buffer[index]);
      index += 4;

      /* Water column paramters */
      mb_put_binary_short(MB_YES, mrz->sounding[i].WCBeamNumb, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, mrz->sounding[i].WCrange_samples, &buffer[index]);
      index += 2;
      mb_put_binary_float(MB_YES, mrz->sounding[i].WCNomBeamAngleAcross_deg, &buffer[index]);
      index += 4;

      /* Reflectivity data (backscatter (BS) data) */
      mb_put_binary_float(MB_YES, mrz->sounding[i].meanAbsCoeff_dBPerkm, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].reflectivity1_dB, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].reflectivity2_dB, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].receiverSensitivityApplied_dB, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].sourceLevelApplied_dB, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].BScalibration_dB, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].TVG_dB, &buffer[index]);
      index += 4;

      /* Range and angle data */
      mb_put_binary_float(MB_YES, mrz->sounding[i].beamAngleReRx_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].beamAngleCorrection_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].twoWayTravelTime_sec, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].twoWayTravelTimeCorrection_sec, &buffer[index]);
      index += 4;

      /* Georeferenced depth points */
      mb_put_binary_float(MB_YES, mrz->sounding[i].deltaLatitude_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].deltaLongitude_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].z_reRefPoint_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].y_reRefPoint_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].x_reRefPoint_m, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mrz->sounding[i].beamIncAngleAdj_deg, &buffer[index]);
      index += 4;
      mb_put_binary_short(MB_YES, mrz->sounding[i].realTimeCleanInfo, &buffer[index]);
      index += 2;

      /* Seabed image */
      mb_put_binary_short(MB_YES, mrz->sounding[i].SIstartRange_samples, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, mrz->sounding[i].SIcentreSample, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, mrz->sounding[i].SInumSamples, &buffer[index]);
      index += 2;

      //numSidescanSamples += mrz->sounding[i].SInumSamples;

      /* print debug statements */
      if (verbose >= 5) {
        fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
        fprintf(stderr, "dbg5       soundingIndex:                  %d\n", mrz->sounding[i].soundingIndex);
        fprintf(stderr, "dbg5       txSectorNumb:                   %d\n", mrz->sounding[i].txSectorNumb);
        fprintf(stderr, "dbg5       detectionType:                  %d\n", mrz->sounding[i].detectionType);
        fprintf(stderr, "dbg5       detectionMethod:                %d\n", mrz->sounding[i].detectionMethod);
        fprintf(stderr, "dbg5       rejectionInfo1:                 %d\n", mrz->sounding[i].rejectionInfo1);
        fprintf(stderr, "dbg5       rejectionInfo2:                 %d\n", mrz->sounding[i].rejectionInfo2);
        fprintf(stderr, "dbg5       postProcessingInfo:             %d\n", mrz->sounding[i].postProcessingInfo);
        fprintf(stderr, "dbg5       detectionClass:                 %d\n", mrz->sounding[i].detectionClass);
        fprintf(stderr, "dbg5       detectionConfidenceLevel        %d\n", mrz->sounding[i].detectionConfidenceLevel);
        // fprintf(stderr, "dbg5       padding:                       %d\n", mrz->sounding[i].padding);
        fprintf(stderr, "dbg5       beamflag_enabled:               %d\n", mrz->sounding[i].beamflag_enabled);
        fprintf(stderr, "dbg5       beamflag:                       %d\n", mrz->sounding[i].beamflag);
        fprintf(stderr, "dbg5       rangeFactor:                    %f\n", mrz->sounding[i].rangeFactor);
        fprintf(stderr, "dbg5       qualityFactor:                  %f\n", mrz->sounding[i].qualityFactor);
        fprintf(stderr, "dbg5       detectionUncertaintyVer_m:      %f\n", mrz->sounding[i].detectionUncertaintyVer_m);
        fprintf(stderr, "dbg5       detectionUncertaintyHor_m:      %f\n", mrz->sounding[i].detectionUncertaintyHor_m);
        fprintf(stderr, "dbg5       detectionWindowLength_sec:      %f\n", mrz->sounding[i].detectionWindowLength_sec);
        fprintf(stderr, "dbg5       echoLength_sec:                 %f\n", mrz->sounding[i].echoLength_sec);
        fprintf(stderr, "dbg5       WCBeamNumb:                     %d\n", mrz->sounding[i].WCBeamNumb);
        fprintf(stderr, "dbg5       WCrange_samples:                %d\n", mrz->sounding[i].WCrange_samples);
        fprintf(stderr, "dbg5       WCNomBeamAngleAcross_deg:       %f\n", mrz->sounding[i].WCNomBeamAngleAcross_deg);
        fprintf(stderr, "dbg5       meanAbsCoeff_dBPerkm:           %f\n", mrz->sounding[i].meanAbsCoeff_dBPerkm);
        fprintf(stderr, "dbg5       reflectivity1_dB:               %f\n", mrz->sounding[i].reflectivity1_dB);
        fprintf(stderr, "dbg5       reflectivity2_dB:               %f\n", mrz->sounding[i].reflectivity2_dB);
        fprintf(stderr, "dbg5       receiverSensitivityApplied_dB:  %f\n", mrz->sounding[i].receiverSensitivityApplied_dB);
        fprintf(stderr, "dbg5       sourceLevelApplied_dB:          %f\n", mrz->sounding[i].sourceLevelApplied_dB);
        fprintf(stderr, "dbg5       BScalibration_dB:               %f\n", mrz->sounding[i].BScalibration_dB);
        fprintf(stderr, "dbg5       TVG_dB:                         %f\n", mrz->sounding[i].TVG_dB);
        fprintf(stderr, "dbg5       beamAngleReRx_deg:              %f\n", mrz->sounding[i].beamAngleReRx_deg);
        fprintf(stderr, "dbg5       beamAngleCorrection_deg:        %f\n", mrz->sounding[i].beamAngleCorrection_deg);
        fprintf(stderr, "dbg5       twoWayTravelTime_sec            %f\n", mrz->sounding[i].twoWayTravelTime_sec);
        fprintf(stderr, "dbg5       twoWayTravelTimeCorrection_sec  %f\n", mrz->sounding[i].twoWayTravelTimeCorrection_sec);
        fprintf(stderr, "dbg5       deltaLatitude_deg:              %f\n", mrz->sounding[i].deltaLatitude_deg);
        fprintf(stderr, "dbg5       deltaLongitude_deg:             %f\n", mrz->sounding[i].deltaLongitude_deg);
        fprintf(stderr, "dbg5       z_reRefPoint_m:                 %f\n", mrz->sounding[i].z_reRefPoint_m);
        fprintf(stderr, "dbg5       y_reRefPoint_m:                 %f\n", mrz->sounding[i].y_reRefPoint_m);
        fprintf(stderr, "dbg5       x_reRefPoint_m:                 %f\n", mrz->sounding[i].x_reRefPoint_m);
        fprintf(stderr, "dbg5       beamIncAngleAdj_deg:            %f\n", mrz->sounding[i].beamIncAngleAdj_deg);
        fprintf(stderr, "dbg5       realTimeCleanInfo:              %d\n", mrz->sounding[i].realTimeCleanInfo);
        fprintf(stderr, "dbg5       SIstartRange_samples:           %d\n", mrz->sounding[i].SIstartRange_samples);
        fprintf(stderr, "dbg5       SIcentreSample:                 %d\n", mrz->sounding[i].SIcentreSample);
        fprintf(stderr, "dbg5       SInumSamples:                   %d\n", mrz->sounding[i].SInumSamples);
      }
    }

    for (i = 0; i < numSidescanSamples; i++) {
      mb_put_binary_short(MB_YES, mrz->SIsample_desidB[i], &buffer[index]);
      index += 2;
    }

    /* Insert closing byte count */
    mb_put_binary_int(MB_YES, mrz->header.numBytesDgm, &buffer[index]);
    index += 4;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_mwc(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, int imwc, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_mwc";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_mwc *mwc = NULL;
  struct mbsys_kmbes_header *header = NULL;
  char *buffer = NULL;
  int index = 0;
  int i, k;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
    fprintf(stderr, "dbg2       imwcc:      %d\n", imwc);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  mwc = &(store->mwc[imwc]);
  header = &store->mwc[imwc].header;

  /* size of output record */
  *size = (size_t) mwc->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&mwc->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* EMdgmMpartition - data partition information */
    mb_put_binary_short(MB_YES, mwc->partition.numOfDgms, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mwc->partition.dgmNum, &buffer[index]);
    index += 2;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numOfDgms:  %d\n", mwc->partition.numOfDgms);
      fprintf(stderr, "dbg5       dgmNum:     %d\n", mwc->partition.dgmNum);
    }

    /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
    mb_put_binary_short(MB_YES, mwc->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mwc->cmnPart.pingCnt, &buffer[index]);
    index += 2;
    buffer[index] = mwc->cmnPart.rxFansPerPing;
    index++;
    buffer[index] = mwc->cmnPart.rxFanIndex;
    index++;
    buffer[index] = mwc->cmnPart.swathsPerPing;
    index++;
    buffer[index] = mwc->cmnPart.swathAlongPosition;
    index++;
    buffer[index] = mwc->cmnPart.txTransducerInd;
    index++;
    buffer[index] = mwc->cmnPart.rxTransducerInd;
    index++;
    buffer[index] = mwc->cmnPart.numRxTransducers;
    index++;
    buffer[index] = mwc->cmnPart.algorithmType;
    index++;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesCmnPart:     %d\n", mwc->cmnPart.numBytesCmnPart);
      fprintf(stderr, "dbg5       pingCnt:             %d\n", mwc->cmnPart.pingCnt);
      fprintf(stderr, "dbg5       rxFansPerPing:       %d\n", mwc->cmnPart.rxFansPerPing);
      fprintf(stderr, "dbg5       rxFanIndex:          %d\n", mwc->cmnPart.rxFanIndex);
      fprintf(stderr, "dbg5       swathsPerPing:       %d\n", mwc->cmnPart.swathsPerPing);
      fprintf(stderr, "dbg5       swathAlongPosition:  %d\n", mwc->cmnPart.swathAlongPosition);
      fprintf(stderr, "dbg5       txTransducerInd:     %d\n", mwc->cmnPart.txTransducerInd);
      fprintf(stderr, "dbg5       rxTransducerInd:     %d\n", mwc->cmnPart.rxTransducerInd);
      fprintf(stderr, "dbg5       numRxTransducers:    %d\n", mwc->cmnPart.numRxTransducers);
      fprintf(stderr, "dbg5       algorithmType:       %d\n", mwc->cmnPart.algorithmType);
    }

    /* EMdgmMWCtxInfo - transmit sectors, general info for all sectors */
    mb_put_binary_short(MB_YES, mwc->txInfo.numBytesTxInfo, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mwc->txInfo.numTxSectors, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mwc->txInfo.numBytesPerTxSector, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mwc->txInfo.padding, &buffer[index]);
    index += 2;
    mb_put_binary_float(MB_YES, mwc->txInfo.heave_m, &buffer[index]);
    index += 4;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesTxInfo:       %d\n", mwc->txInfo.numBytesTxInfo);
      fprintf(stderr, "dbg5       numTxSectors:         %d\n", mwc->txInfo.numTxSectors);
      fprintf(stderr, "dbg5       numBytesPerTxSector:  %d\n", mwc->txInfo.numBytesPerTxSector);
      fprintf(stderr, "dbg5       padding:              %d\n", mwc->txInfo.padding);
      fprintf(stderr, "dbg5       heave_m:              %f\n", mwc->txInfo.heave_m);
    }

    /* EMdgmMWCtxSectorData - transmit sector data, loop for all i = numTxSectors */
    for (i=0; i<(mwc->txInfo.numTxSectors); i++) {
      mb_put_binary_float(MB_YES, mwc->sectorData[i].tiltAngleReTx_deg, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mwc->sectorData[i].centreFreq_Hz, &buffer[index]);
      index += 4;
      mb_put_binary_float(MB_YES, mwc->sectorData[i].txBeamWidthAlong_deg, &buffer[index]);
      index += 4;
      mb_put_binary_short(MB_YES, mwc->sectorData[i].txSectorNum, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, mwc->sectorData[i].padding, &buffer[index]);
      index += 2;

      /* print debug statements */
      if (verbose >= 5) {
        fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
        fprintf(stderr, "dbg5       #MWC transmit sector %d/%d:\n", i + 1, mwc->txInfo.numTxSectors);
        fprintf(stderr, "dbg5       tiltAngleReTx_deg:     %f\n", mwc->sectorData[i].tiltAngleReTx_deg);
        fprintf(stderr, "dbg5       centreFreq_Hz:         %f\n", mwc->sectorData[i].centreFreq_Hz);
        fprintf(stderr, "dbg5       txBeamWidthAlong_deg:  %f\n", mwc->sectorData[i].txBeamWidthAlong_deg);
        fprintf(stderr, "dbg5       txSectorNum:           %d\n", mwc->sectorData[i].txSectorNum);
        fprintf(stderr, "dbg5       padding:               %d\n", mwc->sectorData[i].padding);
      }
    }

    /* EMdgmMWCrxInfo - receiver, general info */
    mb_put_binary_short(MB_YES, mwc->rxInfo.numBytesRxInfo, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, mwc->rxInfo.numBeams, &buffer[index]);
    index += 2;
    buffer[index] = mwc->rxInfo.numBytesPerBeamEntry;
    index ++;
    buffer[index] = mwc->rxInfo.phaseFlag;
    index ++;
    buffer[index] = mwc->rxInfo.TVGfunctionApplied;
    index ++;
    buffer[index] = mwc->rxInfo.TVGoffset_dB;
    index ++;
    mb_put_binary_float(MB_YES, mwc->rxInfo.sampleFreq_Hz, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, mwc->rxInfo.soundVelocity_mPerSec, &buffer[index]);
    index += 4;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesRxInfo:         %d\n", mwc->rxInfo.numBytesRxInfo);
      fprintf(stderr, "dbg5       numBeams:               %d\n", mwc->rxInfo.numBeams);
      fprintf(stderr, "dbg5       numBytesPerBeamEntry:   %d\n", mwc->rxInfo.numBytesPerBeamEntry);
      fprintf(stderr, "dbg5       phaseFlag               %d\n", mwc->rxInfo.phaseFlag);
      fprintf(stderr, "dbg5       TVGfunctionApplied:     %d\n", mwc->rxInfo.TVGfunctionApplied);
      fprintf(stderr, "dbg5       TVGoffset_dB:           %d\n", mwc->rxInfo.TVGoffset_dB);
      fprintf(stderr, "dbg5       sampleFreq_Hz:          %f\n", mwc->rxInfo.sampleFreq_Hz);
      fprintf(stderr, "dbg5       soundVelocity_mPerSec:  %f\n", mwc->rxInfo.soundVelocity_mPerSec);
    }

    /* EMdgmMWCrxBeamData - receiver, specific info for each beam */
    for (i=0; i<(mwc->rxInfo.numBeams); i++) {
      mb_put_binary_float(MB_YES, mwc->beamData_p[i].beamPointAngReVertical_deg, &buffer[index]);
      index += 4;
      mb_put_binary_short(MB_YES, mwc->beamData_p[i].startRangeSampleNum, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, mwc->beamData_p[i].detectedRangeInSamples, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, mwc->beamData_p[i].beamTxSectorNum, &buffer[index]);
      index += 2;
      mb_put_binary_short(MB_YES, mwc->beamData_p[i].numSampleData, &buffer[index]);
      index += 2;

      /* now insert the samples */
      memcpy(&buffer[index], &(mwc->beamData_p[i].sampleAmplitude05dB_p), mwc->beamData_p[i].numSampleData);
      index += mwc->beamData_p[i].numSampleData;

      switch (mwc->rxInfo.phaseFlag) {
        /* no phase data included */
        case 0:
          break;

        /* 8-bit phase data */
        case 1:
          /* Rx beam phase in 180/128 degree resolution. */
          memcpy(&buffer[index], mwc->beamData_p[i].samplePhase8bit, mwc->beamData_p[i].numSampleData);
          index += mwc->beamData_p[i].numSampleData;

        /* 16 bit phase data */
        case 2:
          /* Rx beam phase in 0.01 degree resolution */
          for (k=0;k<mwc->beamData_p[i].numSampleData;k++) {
            mb_put_binary_short(MB_YES, mwc->beamData_p[i].samplePhase16bit[k], &buffer[index]);
            index += 2;
          }
      }

      /* print debug statements */
      if (status == MB_SUCCESS && verbose >= 5) {
        fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
        fprintf(stderr, "dbg5       #MWC receiver beam data %d/%d:\n", i, mwc->rxInfo.numBeams);
        fprintf(stderr, "dbg5       tiltAngleReTx_deg:       %f\n", mwc->beamData_p[i].beamPointAngReVertical_deg);
        fprintf(stderr, "dbg5       startRangeSampleNum:     %d\n", mwc->beamData_p[i].startRangeSampleNum);
        fprintf(stderr, "dbg5       detectedRangeInSamples:  %d\n", mwc->beamData_p[i].detectedRangeInSamples);
        fprintf(stderr, "dbg5       beamTxSectorNum:         %d\n", mwc->beamData_p[i].beamTxSectorNum);
        fprintf(stderr, "dbg5       numSampleData:           %d\n", mwc->beamData_p[i].numSampleData);
        fprintf(stderr, "dbg5       (amplitude phase)       [\n");
        for (k = 0; k < (mwc->beamData_p[i].numSampleData); k++) {
          if (k % 10 == 0)
            fprintf(stderr, "dbg5             ");
          if (mwc->rxInfo.phaseFlag == 1)
            fprintf(stderr, " (%d %d),", mwc->beamData_p[i].sampleAmplitude05dB_p[k], mwc->beamData_p[i].samplePhase8bit[k]);
          else if (mwc->rxInfo.phaseFlag == 2)
            fprintf(stderr, " (%d %d),", mwc->beamData_p[i].sampleAmplitude05dB_p[k], mwc->beamData_p[i].samplePhase16bit[k]);
          else
            fprintf(stderr, " (%d),", mwc->beamData_p[i].sampleAmplitude05dB_p[k]);
          if ((k+1) % 10 == 0)
            fprintf(stderr, "\n");
        }
      }

    /* Insert closing byte count */
    mb_put_binary_int(MB_YES, mwc->header.numBytesDgm, &buffer[index]);
    // index += 4;
    }
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_cpo(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_cpo";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_cpo *cpo = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  cpo = &(store->cpo);
  header = &store->cpo.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:                  %u\n", cpo->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                      %s\n", cpo->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:                   %u\n", cpo->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                     %u\n", cpo->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:                %u\n", cpo->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                     %u\n", cpo->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:                 %u\n", cpo->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:              %u\n", cpo->cmnPart.numBytesCmnPart);
    fprintf(stderr, "dbg5       sensorSystem:                 %u\n", cpo->cmnPart.sensorSystem);
    fprintf(stderr, "dbg5       sensorStatus:                 %u\n", cpo->cmnPart.sensorStatus);
    fprintf(stderr, "dbg5       padding:                      %u\n", cpo->cmnPart.padding);

    fprintf(stderr, "dbg5       timeFromSensor_sec:           %u\n", cpo->sensorData.timeFromSensor_sec);
    fprintf(stderr, "dbg5       timeFromSensor_nanosec:       %u\n", cpo->sensorData.timeFromSensor_nanosec);
    fprintf(stderr, "dbg5       posFixQuality_m:              %f\n", cpo->sensorData.posFixQuality_m);
    fprintf(stderr, "dbg5       correctedLat_deg:             %f\n", cpo->sensorData.correctedLat_deg);
    fprintf(stderr, "dbg5       correctedLong_deg:            %f\n", cpo->sensorData.correctedLong_deg);
    fprintf(stderr, "dbg5       speedOverGround_mPerSec:      %f\n", cpo->sensorData.speedOverGround_mPerSec);
    fprintf(stderr, "dbg5       courseOverGround_deg:         %f\n", cpo->sensorData.courseOverGround_deg);
    fprintf(stderr, "dbg5       ellipsoidHeightReRefPoint_m:  %f\n", cpo->sensorData.ellipsoidHeightReRefPoint_m);
    fprintf(stderr, "dbg5       posDataFromSensor:            %s\n", cpo->sensorData.posDataFromSensor);
  }

  /* size of output record */
  *size = (size_t) cpo->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&cpo->header, error);

    /* calc number of bytes for raw sensor data */
    numBytesRawSensorData = cpo->header.numBytesDgm - MBSYS_KMBES_CPO_VAR_OFFSET;

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* common part */
    mb_put_binary_short(MB_YES, cpo->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, cpo->cmnPart.sensorSystem, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, cpo->cmnPart.sensorStatus, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, cpo->cmnPart.padding, &buffer[index]);
    index += 2;

    /* sensor data block */
    mb_put_binary_int(MB_YES, cpo->sensorData.timeFromSensor_sec, &buffer[index]);
    index += 4;
    mb_put_binary_int(MB_YES, cpo->sensorData.timeFromSensor_nanosec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, cpo->sensorData.posFixQuality_m, &buffer[index]);
    index += 4;
    mb_put_binary_double(MB_YES, cpo->sensorData.correctedLat_deg, &buffer[index]);
    index += 8;
    mb_put_binary_double(MB_YES, cpo->sensorData.correctedLong_deg, &buffer[index]);
    index += 8;
    mb_put_binary_float(MB_YES, cpo->sensorData.speedOverGround_mPerSec, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, cpo->sensorData.courseOverGround_deg, &buffer[index]);
    index += 4;
    mb_put_binary_float(MB_YES, cpo->sensorData.ellipsoidHeightReRefPoint_m, &buffer[index]);
    index += 4;

    /* raw data msg from sensor */
    memcpy(&buffer[index], &(cpo->sensorData.posDataFromSensor), numBytesRawSensorData);
    index += numBytesRawSensorData;

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, cpo->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_che(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_che";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_che *che = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  che = &(store->che);
  header = &store->che.header;

  /* size of output record */
  *size = (size_t) che->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&che->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    /* print debug statements */
    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesDgm:    %u\n", che->header.numBytesDgm);
      fprintf(stderr, "dbg5       dgmType:        %s\n", che->header.dgmType);
      fprintf(stderr, "dbg5       dgmVersion:     %u\n", che->header.dgmVersion);
      fprintf(stderr, "dbg5       systemID:       %u\n", che->header.systemID);
      fprintf(stderr, "dbg5       echoSounderID:  %u\n", che->header.echoSounderID);
      fprintf(stderr, "dbg5       time_sec:       %u\n", che->header.time_sec);
      fprintf(stderr, "dbg5       time_nanosec:   %u\n", che->header.time_nanosec);
    }

    /* EMdgmMbody - information of transmitter and receiver used to find data in datagram */
    mb_put_binary_short(MB_YES, che->cmnPart.numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, che->cmnPart.pingCnt, &buffer[index]);
    index += 2;
    buffer[index] = che->cmnPart.rxFansPerPing;
    index++;
    buffer[index] = che->cmnPart.rxFanIndex;
    index++;
    buffer[index] = che->cmnPart.swathsPerPing;
    index++;
    buffer[index] = che->cmnPart.swathAlongPosition;
    index++;
    buffer[index] = che->cmnPart.txTransducerInd;
    index++;
    buffer[index] = che->cmnPart.rxTransducerInd;
    index++;
    buffer[index] = che->cmnPart.numRxTransducers;
    index++;
    buffer[index] = che->cmnPart.algorithmType;
    index++;

    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       numBytesCmnPart:     %d\n", che->cmnPart.numBytesCmnPart);
      fprintf(stderr, "dbg5       pingCnt:             %d\n", che->cmnPart.pingCnt);
      fprintf(stderr, "dbg5       rxFansPerPing:       %d\n", che->cmnPart.rxFansPerPing);
      fprintf(stderr, "dbg5       rxFanIndex:          %d\n", che->cmnPart.rxFanIndex);
      fprintf(stderr, "dbg5       swathsPerPing:       %d\n", che->cmnPart.swathsPerPing);
      fprintf(stderr, "dbg5       swathAlongPosition:  %d\n", che->cmnPart.swathAlongPosition);
      fprintf(stderr, "dbg5       txTransducerInd:     %d\n", che->cmnPart.txTransducerInd);
      fprintf(stderr, "dbg5       rxTransducerInd:     %d\n", che->cmnPart.rxTransducerInd);
      fprintf(stderr, "dbg5       numRxTransducers:    %d\n", che->cmnPart.numRxTransducers);
      fprintf(stderr, "dbg5       algorithmType:       %d\n", che->cmnPart.algorithmType);
    }

    /* sensor data block */
    mb_put_binary_float(MB_YES, che->data.heave_m, &buffer[index]);
    index += 4;

    if (verbose >= 5) {
      fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
      fprintf(stderr, "dbg5       heave_m:             %f\n", che->data.heave_m);
    }

    /* insert closing byte count */
    mb_put_binary_int(MB_YES, che->header.numBytesDgm, &buffer[index]);
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_iip(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_iip";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_iip *iip = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  iip = &(store->iip);
  header = &store->iip.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:      %u\n", iip->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:          %s\n", iip->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:       %u\n", iip->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:         %u\n", iip->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:    %u\n", iip->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:         %u\n", iip->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:     %u\n", iip->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", iip->numBytesCmnPart);
    fprintf(stderr, "dbg5       info:             %u\n", iip->info);
    fprintf(stderr, "dbg5       status:           %u\n", iip->status);
    fprintf(stderr, "dbg5       install_txt:      %s\n", iip->install_txt);
  }

  /* size of output record */
  *size = (size_t) iip->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&iip->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    numBytesRawSensorData = iip->header.numBytesDgm - MBSYS_KMBES_IIP_VAR_OFFSET;

    mb_put_binary_short(MB_YES, iip->numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, iip->info, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, iip->status, &buffer[index]);
    index += 2;
    memcpy(&buffer[index], iip->install_txt, numBytesRawSensorData);
    index += numBytesRawSensorData;

    /* Insert closing byte count */
    mb_put_binary_int(MB_YES, iip->header.numBytesDgm, &buffer[index]);
    // index += 4;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       size:       %zu\n", *size);
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_iop(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_iop";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_iop *iop = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesRawSensorData = 0;
  char *buffer = NULL;
  int index = 0;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  iop = &(store->iop);
  header = &store->iop.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:      %u\n", iop->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:          %s\n", iop->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:       %u\n", iop->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:         %u\n", iop->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:    %u\n", iop->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:         %u\n", iop->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:     %u\n", iop->header.time_nanosec);

    fprintf(stderr, "dbg5       numBytesCmnPart:  %u\n", iop->numBytesCmnPart);
    fprintf(stderr, "dbg5       info:             %u\n", iop->info);
    fprintf(stderr, "dbg5       status:           %u\n", iop->status);
    fprintf(stderr, "dbg5       runtime_txt:      %s\n", iop->runtime_txt);
  }

  /* size of output record */
  *size = (size_t) iop->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&iop->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    numBytesRawSensorData = iop->header.numBytesDgm - MBSYS_KMBES_IOP_VAR_OFFSET;

    mb_put_binary_short(MB_YES, iop->numBytesCmnPart, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, iop->info, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, iop->status, &buffer[index]);
    index += 2;
    memcpy(&buffer[index], iop->runtime_txt, numBytesRawSensorData);
    index += numBytesRawSensorData;

    /* Insert closing byte count */
    mb_put_binary_int(MB_YES, iop->header.numBytesDgm, &buffer[index]);
    // index += 4;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_xmb(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_xmb";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_xmb *xmb = NULL;
  struct mbsys_kmbes_iip *iip = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesVersion = 0;
  char *buffer = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  xmb = &(store->xmb);
  iip = &(store->iip);
  header = &store->xmb.header;

  /* have to construct this record now */
  strncpy(xmb->version, MB_VERSION, MB_COMMENT_MAXLINE-1);
  numBytesVersion = strlen(xmb->version) + (strlen(xmb->version) % 2);
  xmb->header.numBytesDgm = MBSYS_KMBES_HEADER_SIZE + numBytesVersion + 36;
  strncpy((char *)xmb->header.dgmType, "#XMB", 4);
  xmb->header.dgmVersion = iip->header.dgmVersion;
  xmb->header.systemID = iip->header.systemID;
  xmb->header.echoSounderID = iip->header.echoSounderID;
  xmb->header.time_sec = iip->header.time_sec;
  xmb->header.time_nanosec = iip->header.time_nanosec;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:             %u\n", xmb->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:                 %s\n", xmb->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:              %u\n", xmb->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:                %u\n", xmb->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:           %u\n", xmb->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:                %u\n", xmb->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:            %u\n", xmb->header.time_nanosec);

    fprintf(stderr, "dbg5       pseudosidescan_enabled:  %d\n", xmb->pseudosidescan_enabled);
    for (i=0;i<28;i++)
      fprintf(stderr, "dbg5       unused[%2d]:              %u\n", i, xmb->unused[i]);
    fprintf(stderr, "dbg5       version:                   %s\n", xmb->version);
  }

  /* size of output record */
  *size = (size_t) xmb->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&xmb->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    mb_put_binary_int(MB_YES, (int)MB_YES, &buffer[index]);
    index += 4;
    for (i=0;i<28;i++) {
      buffer[index] = xmb->unused[i];
      index++;
    }
    memcpy(&buffer[index], xmb->version, numBytesVersion);
    index += numBytesVersion;

    /* Insert closing byte count */
    mb_put_binary_int(MB_YES, xmb->header.numBytesDgm, &buffer[index]);
    // index += 4;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       size:       %zu\n", *size);
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_xmc(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_xmc";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_xmc *xmc = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesComment = 0;
  char *buffer = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  xmc = &(store->xmc);
  header = &store->xmc.header;

  /* size of output record */
  numBytesComment = strlen(store->xmc.comment) + (strlen(store->xmc.comment) % 2);
  store->xmc.header.numBytesDgm = MBSYS_KMBES_HEADER_SIZE + numBytesComment + 36;
  *size = (size_t) xmc->header.numBytesDgm;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", xmc->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %s\n", xmc->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", xmc->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", xmc->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", xmc->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", xmc->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", xmc->header.time_nanosec);

    for (i=0;i<32;i++)
      fprintf(stderr, "dbg5       unused[%2d]:    %u\n", i, xmc->unused[i]);
    fprintf(stderr, "dbg5       comment:        %s\n", xmc->comment);
  }

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&xmc->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    for (i=0;i<32;i++) {
      buffer[index] = xmc->unused[i];
      index++;
    }
    memcpy(&buffer[index], xmc->comment, numBytesComment);
    index += numBytesComment;

    /* Insert closing byte count */
    mb_put_binary_int(MB_YES, xmc->header.numBytesDgm, &buffer[index]);
    // index += 4;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       size:       %zu\n", *size);
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_xms(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_xms";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;
  struct mbsys_kmbes_xms *xms = NULL;
  struct mbsys_kmbes_header *header = NULL;
  size_t numBytesComment = 0;
  char *buffer = NULL;
  int index = 0;
  int i;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;
  xms = &(store->xms);
  header = &store->xms.header;

  /* print debug statements */
  if (verbose >= 5) {
    fprintf(stderr, "\ndbg5  Values to be written in MBIO function <%s>\n", function_name);
    fprintf(stderr, "dbg5       numBytesDgm:    %u\n", xms->header.numBytesDgm);
    fprintf(stderr, "dbg5       dgmType:        %s\n", xms->header.dgmType);
    fprintf(stderr, "dbg5       dgmVersion:     %u\n", xms->header.dgmVersion);
    fprintf(stderr, "dbg5       systemID:       %u\n", xms->header.systemID);
    fprintf(stderr, "dbg5       echoSounderID:  %u\n", xms->header.echoSounderID);
    fprintf(stderr, "dbg5       time_sec:       %u\n", xms->header.time_sec);
    fprintf(stderr, "dbg5       time_nanosec:   %u\n", xms->header.time_nanosec);

    fprintf(stderr, "dbg5       pingCnt:        %u\n", xms->pingCnt);
    fprintf(stderr, "dbg5       spare:          %d\n", xms->spare);
    fprintf(stderr, "dbg5       pixel_size:     %f\n", xms->pixel_size);
    fprintf(stderr, "dbg5       pixels_ss:      %d\n", xms->pixels_ss);
    for (i=0;i<32;i++)
      fprintf(stderr, "dbg5       unused[%2d]:    %u\n", i, xms->unused[i]);
    for (i=0;i<xms->pixels_ss;i++)
      fprintf(stderr, "dbg5       ss[%2d]:        %f %f\n",
                      i, xms->ss[i], xms->ss_alongtrack[i]);
  }

  /* size of output record */
  *size = (size_t) xms->header.numBytesDgm;

  /* allocate memory to write rest of record if necessary */
  if (*bufferalloc < *size) {
    status = mb_reallocd(verbose, __FILE__, __LINE__, *size, (void **)bufferptr, error);
    if (status != MB_SUCCESS)
      *bufferalloc = 0;
    else
      *bufferalloc = *size;
  }

  /* proceed to write if buffer allocated */
  if (status == MB_SUCCESS) {
    /* get buffer for writing */
    buffer = (char *) *bufferptr;

    /* insert the header */
    mbr_kemkmall_wr_header(verbose, bufferptr, (void *)&xms->header, error);

    /* insert the data */
    index = MBSYS_KMBES_HEADER_SIZE;

    mb_put_binary_short(MB_YES, xms->pingCnt, &buffer[index]);
    index += 2;
    mb_put_binary_short(MB_YES, xms->spare, &buffer[index]);
    index += 2;
    mb_put_binary_float(MB_YES, xms->pixel_size, &buffer[index]);
    index += 4;
    mb_put_binary_int(MB_YES, xms->pixels_ss, &buffer[index]);
    index += 4;
    for (i=0;i<32;i++) {
      buffer[index] = xms->unused[i];
      index++;
    }
  for (i=0;i<xms->pixels_ss;i++) {
    mb_put_binary_float(MB_YES, xms->ss[i], &buffer[index]);
    index += 4;
  }
  for (i=0;i<xms->pixels_ss;i++) {
    mb_put_binary_float(MB_YES, xms->ss_alongtrack[i], &buffer[index]);
    index += 4;
  }

    /* Insert closing byte count */
    mb_put_binary_int(MB_YES, xms->header.numBytesDgm, &buffer[index]);
    // index += 4;
  }

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       size:       %zu\n", *size);
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type %.4s written - size: %lu %d time: %d.%9.9d status:%d error:%d\n",
          header->dgmType, *size, index, header->time_sec, header->time_nanosec, status, *error);
#endif

  /* return status */
  return (status);
};

/*--------------------------------------------------------------------*/

int mbr_kemkmall_wr_unknown(int verbose, int *bufferalloc, char **bufferptr, void *store_ptr, size_t *size, int *error) {
  char *function_name = "mbr_kemkmall_wr_unknown";
  int status = MB_SUCCESS;
  struct mbsys_kmbes_struct *store = NULL;

  /* print input debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> called\n", function_name);
    fprintf(stderr, "dbg2  Input arguments:\n");
    fprintf(stderr, "dbg2       verbose:    %d\n", verbose);
    fprintf(stderr, "dbg2       bufferalloc:%d\n", *bufferalloc);
    fprintf(stderr, "dbg2       bufferptr:  %p\n", (void *)bufferptr);
    fprintf(stderr, "dbg2       store_ptr:  %p\n", (void *)store_ptr);
  }

  /* get pointer to raw data structure */
  store = (struct mbsys_kmbes_struct *)store_ptr;

  /* print output debug statements */
  if (verbose >= 2) {
    fprintf(stderr, "\ndbg2  MBIO function <%s> completed\n", function_name);
    fprintf(stderr, "dbg2  Return values:\n");
    fprintf(stderr, "dbg2       error:      %d\n", *error);
    fprintf(stderr, "dbg2  Return status:\n");
    fprintf(stderr, "dbg2       status:  %d\n", status);
  }

#ifdef MBR_KEMKMALL_DEBUG
  fprintf(stderr, "KEMKMALL datagram type unknow written - status:%d error:%d\n",
  status, *error);
#endif

  /* return status */
  return (status);

};

/*--------------------------------------------------------------------*/
